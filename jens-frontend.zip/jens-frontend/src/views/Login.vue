<template>
  <div class="login-page">
    <div class="login-container">
      <div class="login-banner">
        <div class="banner-content">
          <h2>欢迎回来</h2>
          <p>登录您的账户，畅玩JENS游戏，挑战自我、创造记录！</p>
          <div class="game-icons">
            <div class="icon-item" v-for="(icon, index) in gameIcons" :key="index">
              <img :src="icon" alt="游戏图标" />
            </div>
          </div>
        </div>
      </div>
      
      <div class="login-form-container">
        <div class="form-header">
          <h2>用户登录</h2>
          <p>登录您的JENS账户</p>
        </div>
        
        <el-form :model="loginForm" :rules="rules" ref="loginFormRef" class="login-form">
          <el-form-item prop="username">
            <el-input 
              v-model="loginForm.username" 
              placeholder="用户名" 
              prefix-icon="el-icon-user"
              size="large">
            </el-input>
          </el-form-item>
          
          <el-form-item prop="password">
            <el-input 
              v-model="loginForm.password" 
              type="password" 
              placeholder="密码" 
              prefix-icon="el-icon-lock" 
              show-password
              size="large">
            </el-input>
          </el-form-item>
          
          <div class="form-options">
            <el-checkbox v-model="loginForm.remember">记住我</el-checkbox>
            <a href="#" class="forgot-link">忘记密码?</a>
          </div>
          
          <el-button 
            type="primary" 
            @click="handleLogin" 
            :loading="loading" 
            class="login-button">
            登录
          </el-button>
          
          <div class="login-footer">
            <p>还没有账号？<router-link to="/register" class="signup-link">立即注册</router-link></p>
          </div>
        </el-form>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, reactive } from 'vue'
import { useStore } from 'vuex'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import userApi from '../api/user'

export default {
  name: 'Login',
  setup() {
    const store = useStore()
    const router = useRouter()
    const loginFormRef = ref(null)
    const loading = ref(false)
    
    const loginForm = reactive({
      username: '',
      password: '',
      remember: false
    })

    const gameIcons = [
      '/images/game-icon-1.svg',
      '/images/game-icon-2.svg',
      '/images/game-icon-3.svg',
      '/images/game-icon-4.svg',
    ]
    
    const rules = {
      username: [
        { required: true, message: '请输入用户名', trigger: 'blur' },
        { min: 3, max: 20, message: '用户名长度应为3-20个字符', trigger: 'blur' }
      ],
      password: [
        { required: true, message: '请输入密码', trigger: 'blur' },
        { min: 6, max: 20, message: '密码长度应为6-20个字符', trigger: 'blur' }
      ]
    }
    
    const handleLogin = () => {
      loginFormRef.value.validate(async (valid) => {
        if (valid) {
          try {
            loading.value = true
            const response = await userApi.login(loginForm)
            
            console.log('登录响应:', response)
            
            // 保存token和用户信息
            store.dispatch('login', {
              token: response.access_token,
              user: response.user
            })
            
            ElMessage({
              type: 'success',
              message: '登录成功！'
            })
            
            // 登录成功后跳转到首页或上一页
            const redirectPath = router.currentRoute.value.query.redirect || '/'
            router.push(redirectPath)
          } catch (error) {
            ElMessage({
              type: 'error',
              message: error.response?.data?.message || '登录失败，请检查用户名和密码'
            })
          } finally {
            loading.value = false
          }
        }
      })
    }
    
    return {
      loginForm,
      loginFormRef,
      rules,
      loading,
      handleLogin,
      gameIcons
    }
  }
}
</script>

<style scoped>
.login-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #f5f7fa;
  padding: 20px;
}

.login-container {
  width: 100%;
  max-width: 900px;
  display: flex;
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  background-color: #fff;
  min-height: 500px;
}

.login-banner {
  flex: 1;
  background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
  color: white;
  padding: 40px;
  display: flex;
  align-items: center;
  position: relative;
  overflow: hidden;
}

.login-banner::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: url('../assets/pattern.svg') repeat;
  opacity: 0.1;
}

.banner-content {
  position: relative;
  z-index: 2;
}

.banner-content h2 {
  font-size: 2.2rem;
  margin-bottom: 20px;
  font-weight: 700;
}

.banner-content p {
  font-size: 1.1rem;
  margin-bottom: 30px;
  opacity: 0.9;
  line-height: 1.6;
}

.game-icons {
  display: flex;
  gap: 15px;
  margin-top: 40px;
}

.icon-item {
  width: 50px;
  height: 50px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 8px;
}

.icon-item img {
  max-width: 100%;
  max-height: 100%;
}

.login-form-container {
  flex: 1;
  padding: 50px 40px;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.form-header {
  text-align: center;
  margin-bottom: 30px;
}

.form-header h2 {
  font-size: 1.8rem;
  color: #303133;
  margin-bottom: 10px;
  font-weight: 600;
}

.form-header p {
  color: #909399;
  font-size: 1rem;
}

.login-form {
  max-width: 350px;
  margin: 0 auto;
  width: 100%;
}

:deep(.el-input__inner) {
  height: 50px;
  font-size: 1rem;
}

.form-options {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.forgot-link {
  color: #2575fc;
  text-decoration: none;
  font-size: 0.9rem;
}

.forgot-link:hover {
  text-decoration: underline;
}

.login-button {
  width: 100%;
  height: 50px;
  font-size: 1.1rem;
  font-weight: 500;
  border-radius: 8px;
  background: linear-gradient(90deg, #6a11cb, #2575fc);
  border: none;
  margin-bottom: 20px;
  transition: all 0.3s ease;
}

.login-button:hover {
  opacity: 0.9;
  transform: translateY(-2px);
  box-shadow: 0 7px 14px rgba(37, 117, 252, 0.2);
}

.login-footer {
  text-align: center;
  margin-top: 20px;
  font-size: 1rem;
  color: #606266;
}

.signup-link {
  color: #2575fc;
  font-weight: 600;
  text-decoration: none;
}

.signup-link:hover {
  text-decoration: underline;
}

@media (max-width: 768px) {
  .login-container {
    flex-direction: column;
  }
  
  .login-banner {
    padding: 30px 20px;
    text-align: center;
  }
  
  .game-icons {
    justify-content: center;
  }
  
  .login-form-container {
    padding: 30px 20px;
  }
}
</style> 