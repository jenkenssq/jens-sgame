<template>
  <div class="profile-container">
    <el-row :gutter="20">
      <el-col :xs="24" :sm="8" :md="6" :lg="5">
        <!-- 个人信息卡片 -->
        <el-card class="profile-card">
          <div class="avatar-container">
            <el-avatar :size="100" :src="userInfo.avatar || defaultAvatar"></el-avatar>
            <h3>{{ userInfo.username }}</h3>
            <p>{{ userInfo.email }}</p>
            <p v-if="userInfo.gender">性别: {{ getGenderLabel(userInfo.gender) }}</p>
          </div>
          <el-menu 
            class="profile-menu" 
            :default-active="activeMenu"
            @select="handleMenuSelect">
            <el-menu-item index="info">
              <el-icon><i class="el-icon-user"></i></el-icon>
              <span>个人信息</span>
            </el-menu-item>
            <el-menu-item index="records">
              <el-icon><i class="el-icon-data-line"></i></el-icon>
              <span>游戏记录</span>
            </el-menu-item>
            <el-menu-item index="settings">
              <el-icon><i class="el-icon-setting"></i></el-icon>
              <span>游戏设置</span>
            </el-menu-item>
            <el-menu-item index="password">
              <el-icon><i class="el-icon-lock"></i></el-icon>
              <span>修改密码</span>
            </el-menu-item>
          </el-menu>
        </el-card>
      </el-col>
      
      <el-col :xs="24" :sm="16" :md="18" :lg="19">
        <!-- 个人信息表单 -->
        <el-card v-if="activeMenu === 'info'" class="content-card">
          <template #header>
            <div class="card-header">
              <h2>个人信息</h2>
            </div>
          </template>
          
          <el-form :model="profileForm" :rules="profileRules" ref="profileFormRef" label-width="100px">
            <!-- 添加头像上传 -->
            <el-form-item label="头像">
              <div class="avatar-upload-container">
                <el-avatar 
                  :size="100" 
                  :src="avatarPreview || userInfo.avatar || defaultAvatar"
                  class="preview-avatar"
                ></el-avatar>
                <div class="upload-actions">
                  <el-upload
                    class="avatar-uploader"
                    action="#"
                    :http-request="uploadAvatar"
                    :show-file-list="false"
                    :before-upload="beforeAvatarUpload"
                    accept="image/jpeg,image/png,image/gif"
                  >
                    <el-button type="primary" size="small" class="upload-btn">选择图片</el-button>
                  </el-upload>
                  <div class="upload-tips">
                    支持JPG、PNG、GIF格式，文件大小不超过2MB
                  </div>
                </div>
              </div>
            </el-form-item>
            
            <el-form-item label="用户名" prop="username">
              <el-input v-model="profileForm.username"></el-input>
            </el-form-item>
            
            <el-form-item label="邮箱" prop="email">
              <el-input v-model="profileForm.email"></el-input>
            </el-form-item>
            
            <el-form-item label="性别" prop="gender">
              <el-radio-group v-model="profileForm.gender">
                <el-radio label="male">男</el-radio>
                <el-radio label="female">女</el-radio>
                <el-radio label="other">其他</el-radio>
              </el-radio-group>
            </el-form-item>
            
            <el-form-item>
              <el-button type="primary" @click="updateProfile" :loading="loading">保存修改</el-button>
            </el-form-item>
          </el-form>
        </el-card>
        
        <!-- 游戏记录 -->
        <el-card v-if="activeMenu === 'records'" class="content-card">
          <template #header>
            <div class="card-header">
              <h2>游戏记录</h2>
              <div class="header-controls">
                <el-button type="primary" @click="fetchGameRecords" size="default" class="refresh-btn">刷新记录</el-button>
              </div>
            </div>
          </template>
          
          <el-table 
            :data="gameRecords" 
            stripe 
            style="width: 100%" 
            v-loading="recordsLoading"
            :empty-text="recordsLoading ? '加载中...' : '暂无游戏记录'">
            <el-table-column prop="date" label="日期" min-width="120"></el-table-column>
            <el-table-column label="游戏类型" min-width="120">
              <template #default="scope">
                {{ getGameTypeName(scope.row.game_type) }}
              </template>
            </el-table-column>
            <el-table-column prop="score" label="分数" min-width="100" sortable></el-table-column>
            <el-table-column label="游戏时长" min-width="100">
              <template #default="scope">
                {{ formatTime(scope.row.duration || scope.row.time || 0) }}
              </template>
            </el-table-column>
            <el-table-column prop="level" label="关卡/难度" min-width="100"></el-table-column>
            
            <!-- 根据游戏类型显示特定数据 -->
            <el-table-column label="详细信息" min-width="200">
              <template #default="scope">
                <div v-if="scope.row.game_type === 'sokoban'">
                  步数: {{ scope.row.steps || 0 }}
                </div>
                <div v-else-if="scope.row.game_type === 'tetris'">
                  消除行数: {{ scope.row.lines || 0 }}
                </div>
                <div v-else-if="scope.row.game_type === 'snake'">
                  蛇长: {{ scope.row.length || 0 }}
                </div>
                <div v-else-if="scope.row.game_type === 'tank'">
                  击杀: {{ scope.row.kills || 0 }}
                  <span v-if="scope.row.mode">| 模式: {{ scope.row.mode === 'classic' ? '经典' : '生存' }}</span>
                </div>
              </template>
            </el-table-column>
            
            <el-table-column label="状态" min-width="100" align="center">
              <template #default="scope">
                <el-tag :type="scope.row.completed ? 'success' : 'info'">
                  {{ scope.row.completed ? '完成' : '进行中' }}
                </el-tag>
              </template>
            </el-table-column>
          </el-table>
          
          <div class="pagination-container">
            <el-pagination
              background
              layout="prev, pager, next"
              :total="totalRecords"
              :page-size="recordsPageSize"
              @current-change="handleRecordsPageChange">
            </el-pagination>
          </div>
        </el-card>
        
        <!-- 游戏设置 -->
        <el-card v-if="activeMenu === 'settings'" class="content-card">
          <template #header>
            <div class="card-header">
              <h2>游戏设置</h2>
              <el-select v-model="selectedGameSettings" placeholder="选择游戏" @change="fetchGameSettings">
                <el-option label="推箱子" value="sokoban"></el-option>
                <el-option label="俄罗斯方块" value="tetris"></el-option>
                <el-option label="贪吃蛇" value="snake"></el-option>
                <el-option label="坦克大战" value="tank"></el-option>
              </el-select>
            </div>
          </template>
          
          <div v-if="selectedGameSettings">
            <el-form :model="gameSettingsForm" label-width="120px">
              <!-- 通用设置 -->
              <h3>通用设置</h3>
              <el-form-item label="音效">
                <el-switch v-model="gameSettingsForm.sound"></el-switch>
              </el-form-item>
              <el-form-item label="背景音乐">
                <el-switch v-model="gameSettingsForm.music"></el-switch>
              </el-form-item>
              <el-form-item label="音量">
                <el-slider v-model="gameSettingsForm.volume" :max="100" :min="0"></el-slider>
              </el-form-item>
              
              <!-- 特定游戏设置，根据选择的游戏动态变化 -->
              <div v-if="selectedGameSettings === 'sokoban'">
                <h3>推箱子设置</h3>
                <el-form-item label="默认难度">
                  <el-select v-model="gameSettingsForm.difficulty">
                    <el-option label="简单" value="easy"></el-option>
                    <el-option label="中等" value="medium"></el-option>
                    <el-option label="困难" value="hard"></el-option>
                  </el-select>
                </el-form-item>
              </div>
              
              <div v-if="selectedGameSettings === 'tetris'">
                <h3>俄罗斯方块设置</h3>
                <el-form-item label="下落速度">
                  <el-select v-model="gameSettingsForm.speed">
                    <el-option label="慢速" value="slow"></el-option>
                    <el-option label="中速" value="medium"></el-option>
                    <el-option label="快速" value="fast"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="预览方块数">
                  <el-input-number v-model="gameSettingsForm.previewBlocks" :min="1" :max="5"></el-input-number>
                </el-form-item>
              </div>
              
              <div v-if="selectedGameSettings === 'snake'">
                <h3>贪吃蛇设置</h3>
                <el-form-item label="移动速度">
                  <el-select v-model="gameSettingsForm.speed">
                    <el-option label="慢速" value="slow"></el-option>
                    <el-option label="中速" value="medium"></el-option>
                    <el-option label="快速" value="fast"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="网格大小">
                  <el-select v-model="gameSettingsForm.gridSize">
                    <el-option label="小" value="small"></el-option>
                    <el-option label="中" value="medium"></el-option>
                    <el-option label="大" value="large"></el-option>
                  </el-select>
                </el-form-item>
              </div>
              
              <div v-if="selectedGameSettings === 'tank'">
                <h3>坦克大战设置</h3>
                <el-form-item label="敌人数量">
                  <el-input-number v-model="gameSettingsForm.enemyCount" :min="1" :max="10"></el-input-number>
                </el-form-item>
                <el-form-item label="游戏模式">
                  <el-radio-group v-model="gameSettingsForm.gameMode">
                    <el-radio label="classic">经典模式</el-radio>
                    <el-radio label="survival">生存模式</el-radio>
                  </el-radio-group>
                </el-form-item>
              </div>
              
              <el-form-item>
                <el-button type="primary" @click="saveGameSettings" :loading="settingsLoading">保存设置</el-button>
                <el-button @click="resetGameSettings">重置默认</el-button>
              </el-form-item>
            </el-form>
          </div>
          <div v-else class="empty-tip">
            请选择一个游戏以配置设置
          </div>
        </el-card>
        
        <!-- 修改密码 -->
        <el-card v-if="activeMenu === 'password'" class="content-card">
          <template #header>
            <div class="card-header">
              <h2>修改密码</h2>
            </div>
          </template>
          
          <el-form :model="passwordForm" :rules="passwordRules" ref="passwordFormRef" label-width="100px">
            <el-form-item label="当前密码" prop="oldPassword">
              <el-input v-model="passwordForm.oldPassword" type="password" show-password></el-input>
            </el-form-item>
            
            <el-form-item label="新密码" prop="newPassword">
              <el-input v-model="passwordForm.newPassword" type="password" show-password></el-input>
            </el-form-item>
            
            <el-form-item label="确认新密码" prop="confirmPassword">
              <el-input v-model="passwordForm.confirmPassword" type="password" show-password></el-input>
            </el-form-item>
            
            <el-form-item>
              <el-button type="primary" @click="changePassword" :loading="passwordLoading">修改密码</el-button>
            </el-form-item>
          </el-form>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { ref, reactive, onMounted, computed, nextTick } from 'vue'
import { useStore } from 'vuex'
import { ElMessage, ElMessageBox } from 'element-plus'
import userApi from '../api/user'
import gameApi from '../api/game'

export default {
  name: 'Profile',
  setup() {
    const store = useStore()
    const activeMenu = ref('info')
    const loading = ref(false)
    const settingsLoading = ref(false)
    const passwordLoading = ref(false)
    const recordsLoading = ref(false)
    const profileFormRef = ref(null)
    const passwordFormRef = ref(null)
    
    // 头像预览和上传相关
    const avatarPreview = ref('') // 头像预览URL
    const avatarFile = ref(null)  // 上传的头像文件
    
    // 默认头像
    const defaultAvatar = 'https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png'
    
    // 用户信息
    const userInfo = computed(() => {
      // 返回用户信息，确保每次都是新的引用以触发视图更新
      const user = store.state.user || {};
      return {...user};
    })
    
    // 用户统计
    const userStats = reactive({
      gamesPlayed: 0,
      highestScore: 0,
      achievements: 0
    })
    
    // 个人信息表单
    const profileForm = reactive({
      username: '',
      email: '',
      gender: ''
    })
    
    // 修改密码表单
    const passwordForm = reactive({
      oldPassword: '',
      newPassword: '',
      confirmPassword: ''
    })
    
    // 游戏记录相关
    const gameRecords = ref([])
    const totalRecords = ref(0)
    const recordsCurrentPage = ref(1)
    const recordsPageSize = ref(10)
    
    // 游戏设置相关
    const selectedGameSettings = ref('')
    const gameSettingsForm = reactive({
      sound: true,
      music: true,
      volume: 80,
      difficulty: 'medium',
      speed: 'medium',
      previewBlocks: 3,
      gridSize: 'medium',
      enemyCount: 5,
      gameMode: 'classic'
    })
    
    // 表单验证规则
    const profileRules = {
      username: [
        { required: true, message: '请输入用户名', trigger: 'blur' },
        { min: 3, max: 20, message: '用户名长度应为3-20个字符', trigger: 'blur' }
      ],
      email: [
        { required: true, message: '请输入邮箱', trigger: 'blur' },
        { type: 'email', message: '请输入正确的邮箱格式', trigger: 'blur' }
      ]
    }
    
    // 自定义密码确认验证
    const validatePass2 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请再次输入密码'))
      } else if (value !== passwordForm.newPassword) {
        callback(new Error('两次输入密码不一致'))
      } else {
        callback()
      }
    }
    
    const passwordRules = {
      oldPassword: [
        { required: true, message: '请输入当前密码', trigger: 'blur' }
      ],
      newPassword: [
        { required: true, message: '请输入新密码', trigger: 'blur' },
        { min: 6, max: 20, message: '密码长度应为6-20个字符', trigger: 'blur' }
      ],
      confirmPassword: [
        { required: true, message: '请再次输入新密码', trigger: 'blur' },
        { validator: validatePass2, trigger: 'blur' }
      ]
    }
    
    // 初始化数据
    onMounted(() => {
      // 获取用户信息
      fetchUserInfo()
      
      // 获取游戏记录
      fetchGameRecords()
    })
    
    // 获取用户信息
    const fetchUserInfo = async () => {
      try {
        loading.value = true
        const userData = await userApi.getUserInfo()
        
        // 更新store中的用户信息
        store.commit('SET_USER', userData)
        
        console.log('获取到用户信息:', userData)
        
        // 填充个人信息表单
        profileForm.username = userData.username || ''
        profileForm.email = userData.email || ''
        profileForm.gender = userData.gender || ''
        
        // 获取用户游戏统计
        userStats.gamesPlayed = userData.stats?.gamesPlayed || 0
        userStats.highestScore = userData.stats?.highestScore || 0
        userStats.achievements = userData.stats?.achievements || 0
      } catch (error) {
        console.error('获取用户信息失败:', error)
        ElMessage.error('获取用户信息失败')
      } finally {
        loading.value = false
      }
    }
    
    // 更新个人资料
    const updateProfile = () => {
      profileFormRef.value.validate(async (valid) => {
        if (valid) {
          try {
            loading.value = true
            
            // 创建更新数据对象
            const updateData = {
              username: profileForm.username,
              email: profileForm.email,
              gender: profileForm.gender
            }
            
            console.log('准备更新用户信息:', updateData)
            
            // 发送更新请求
            const response = await userApi.updateUserInfo(updateData)
            console.log('用户信息更新成功，响应数据:', response)
            
            // 更新本地存储的用户信息
            if (response && response.user) {
              // 确保用户名字段更新
              const updatedUser = {
                ...response.user,
                username: response.user.username || profileForm.username
              }
              
              // 直接替换整个用户对象来确保视图更新
              store.commit('SET_USER', updatedUser)
              console.log('用户信息已更新到Store:', store.state.user)
              
              // 强制刷新用户信息显示 - 修复eslint错误
              nextTick(() => {
                console.log('DOM已更新，当前用户名:', userInfo.value.username)
              });
            } else {
              // 如果响应中没有用户数据，则创建一个包含表单数据的用户对象
              const updatedUser = {
                ...userInfo.value,
                username: profileForm.username,
                email: profileForm.email,
                gender: profileForm.gender
              }
              
              store.commit('SET_USER', updatedUser)
              console.log('使用表单数据更新用户信息:', updatedUser)
            }
            
            ElMessage.success('个人信息更新成功')
            
          } catch (error) {
            console.error('更新个人信息失败:', error)
            const errorMsg = error.response?.data?.error || error.message || '服务器错误'
            ElMessage.error('更新个人信息失败: ' + errorMsg)
          } finally {
            loading.value = false
          }
        } else {
          console.warn('表单验证失败')
          ElMessage.warning('请正确填写表单信息')
        }
      })
    }
    
    // 修改密码
    const changePassword = () => {
      passwordFormRef.value.validate(async (valid) => {
        if (valid) {
          try {
            passwordLoading.value = true
            await userApi.changePassword(passwordForm)
            ElMessage.success('密码修改成功')
            // 清空表单
            passwordForm.oldPassword = ''
            passwordForm.newPassword = ''
            passwordForm.confirmPassword = ''
            passwordFormRef.value.resetFields()
          } catch (error) {
            ElMessage.error(error.response?.data?.message || '密码修改失败')
          } finally {
            passwordLoading.value = false
          }
        }
      })
    }
    
    // 菜单选择
    const handleMenuSelect = (key) => {
      activeMenu.value = key
    }
    
    // 获取游戏记录
    const fetchGameRecords = async () => {
      try {
        recordsLoading.value = true
        console.log('获取所有游戏记录')
        
        const response = await gameApi.getUserGameRecords('')
        console.log('获取到游戏记录:', response)
        
        // 检查返回的是数组（直接记录列表）还是带records字段的对象
        if (Array.isArray(response)) {
          // 后端返回了记录数组
          gameRecords.value = response.map(record => {
            // 确保所有记录都有基本字段
            return {
              ...record,
              // 确保日期字段存在
              date: record.date || formatDate(record.created_at || new Date()),
              // 确保duration字段存在
              duration: record.duration || record.time || 0
            }
          })
          
          totalRecords.value = response.length
        } else if (response && response.records) {
          // 处理记录数据（兼容老格式，以防万一）
          gameRecords.value = response.records.map(record => {
            // 确保所有记录都有基本字段
            return {
              ...record,
              // 确保日期字段存在
              date: record.date || formatDate(record.created_at || new Date()),
              // 确保duration字段存在
              duration: record.duration || record.time || 0
            }
          })
          
          totalRecords.value = response.total || gameRecords.value.length
        } else {
          gameRecords.value = []
          totalRecords.value = 0
        }
        
        // 添加调试信息
        console.log('处理后的游戏记录:', gameRecords.value)
        
        // 按时间倒序排序
        gameRecords.value.sort((a, b) => {
          return new Date(b.date || b.created_at) - new Date(a.date || a.created_at)
        })
      } catch (error) {
        console.error('获取游戏记录失败:', error)
        ElMessage.error('获取游戏记录失败')
        gameRecords.value = []
        totalRecords.value = 0
      } finally {
        recordsLoading.value = false
      }
    }
    
    // 记录分页切换
    const handleRecordsPageChange = (page) => {
      recordsCurrentPage.value = page
      fetchGameRecords()
    }
    
    // 格式化日期
    const formatDate = (dateStr) => {
      const date = new Date(dateStr)
      return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`
    }
    
    // 格式化时间（秒）为 分:秒 格式
    const formatTime = (seconds) => {
      if (!seconds && seconds !== 0) return '--'
      
      const mins = Math.floor(seconds / 60)
      const secs = Math.round(seconds % 60)
      return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
    }
    
    // 获取游戏类型名称
    const getGameTypeName = (gameType) => {
      const gameTypes = {
        'sokoban': '推箱子',
        'tetris': '俄罗斯方块',
        'snake': '贪吃蛇',
        'tank': '坦克大战'
      }
      return gameTypes[gameType] || gameType
    }
    
    // 获取游戏设置
    const fetchGameSettings = async () => {
      if (!selectedGameSettings.value) return
      
      try {
        settingsLoading.value = true
        const response = await gameApi.getGameSettings(selectedGameSettings.value)
        
        // 更新设置表单
        Object.assign(gameSettingsForm, response)
      } catch (error) {
        ElMessage.error('获取游戏设置失败')
      } finally {
        settingsLoading.value = false
      }
    }
    
    // 保存游戏设置
    const saveGameSettings = async () => {
      if (!selectedGameSettings.value) return
      
      try {
        settingsLoading.value = true
        await gameApi.saveGameSettings(selectedGameSettings.value, gameSettingsForm)
        
        // 更新Vuex中的游戏设置
        store.dispatch('saveGameSettings', {
          gameType: selectedGameSettings.value,
          settings: gameSettingsForm
        })
        
        ElMessage.success('游戏设置保存成功')
      } catch (error) {
        ElMessage.error('保存游戏设置失败')
      } finally {
        settingsLoading.value = false
      }
    }
    
    // 重置游戏设置
    const resetGameSettings = () => {
      // 重置为默认值
      gameSettingsForm.sound = true
      gameSettingsForm.music = true
      gameSettingsForm.volume = 80
      gameSettingsForm.difficulty = 'medium'
      gameSettingsForm.speed = 'medium'
      gameSettingsForm.previewBlocks = 3
      gameSettingsForm.gridSize = 'medium'
      gameSettingsForm.enemyCount = 5
      gameSettingsForm.gameMode = 'classic'
      
      ElMessage({
        type: 'info',
        message: '已重置为默认设置，请点击保存以应用更改'
      })
    }
    
    // 获取性别显示文本
    const getGenderLabel = (gender) => {
      const genderMap = {
        'male': '男',
        'female': '女',
        'other': '其他'
      }
      return genderMap[gender] || gender
    }
    
    // 头像上传前验证
    const beforeAvatarUpload = (file) => {
      const isImage = ['image/jpeg', 'image/png', 'image/gif'].includes(file.type)
      const isLt2M = file.size / 1024 / 1024 < 2
      
      if (!isImage) {
        ElMessage.error('头像必须是JPG、PNG或GIF格式!')
        return false
      }
      
      if (!isLt2M) {
        ElMessage.error('头像大小不能超过2MB!')
        return false
      }
      
      // 保存文件引用
      avatarFile.value = file
      
      // 创建本地预览URL
      const reader = new FileReader()
      reader.onload = (e) => {
        avatarPreview.value = e.target.result
      }
      reader.readAsDataURL(file)
      
      return true
    }
    
    // 自定义上传实现
    const uploadAvatar = async (options) => {
      try {
        loading.value = true
        
        // 创建FormData对象
        const formData = new FormData()
        formData.append('avatar', options.file)
        
        // 调用上传API
        const response = await userApi.uploadAvatar(formData)
        
        if (response && response.avatarUrl) {
          // 更新用户信息中的头像URL
          const updatedUser = {
            ...userInfo.value,
            avatar: response.avatarUrl
          }
          
          // 更新Store中的用户信息
          store.commit('SET_USER', updatedUser)
          
          // 清除本地预览，因为已经成功上传到服务器
          avatarPreview.value = ''
          
          ElMessage.success('头像上传成功')
        } else {
          ElMessage.warning('头像上传成功，但未返回有效URL')
        }
      } catch (error) {
        console.error('头像上传失败:', error)
        ElMessage.error('头像上传失败: ' + (error.response?.data?.message || error.message))
      } finally {
        loading.value = false
      }
    }
    
    return {
      activeMenu,
      userInfo,
      userStats,
      defaultAvatar,
      profileForm,
      profileFormRef,
      profileRules,
      loading,
      updateProfile,
      getGenderLabel,
      
      // 添加头像上传相关
      avatarPreview,
      beforeAvatarUpload,
      uploadAvatar,
      
      passwordForm,
      passwordFormRef,
      passwordRules,
      passwordLoading,
      changePassword,
      
      gameRecords,
      totalRecords,
      recordsLoading,
      recordsPageSize,
      fetchGameRecords,
      handleRecordsPageChange,
      formatTime,
      getGameTypeName,
      
      selectedGameSettings,
      gameSettingsForm,
      settingsLoading,
      fetchGameSettings,
      saveGameSettings,
      resetGameSettings,
      
      handleMenuSelect
    }
  }
}
</script>

<style scoped>
.profile-container {
  padding: 20px;
}

.profile-card {
  margin-bottom: 20px;
}

.content-card {
  min-height: 500px;
}

.avatar-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 20px;
  padding: 20px 0;
}

/* 头像上传样式 */
.avatar-upload-container {
  display: flex;
  align-items: center;
  gap: 20px;
}

.preview-avatar {
  border: 2px solid #eee;
  flex-shrink: 0;
}

.upload-actions {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.upload-btn {
  display: block;
}

.upload-tips {
  font-size: 12px;
  color: #909399;
  line-height: 1.4;
}

.avatar-container h3 {
  margin: 10px 0 5px;
}

.avatar-container p {
  margin: 0;
  color: #909399;
}

.user-stats {
  display: flex;
  justify-content: space-between;
  padding: 15px 0;
  border-top: 1px solid #EBEEF5;
  border-bottom: 1px solid #EBEEF5;
  margin-bottom: 15px;
}

.stat-item {
  text-align: center;
  flex: 1;
}

.stat-item h4 {
  margin: 0;
  font-size: 18px;
  color: #409EFF;
}

.stat-item p {
  margin: 5px 0 0;
  font-size: 12px;
  color: #909399;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-controls {
  display: flex;
  align-items: center;
}

.pagination-container {
  margin-top: 20px;
  text-align: center;
}

.empty-tip {
  text-align: center;
  color: #909399;
  padding: 40px 0;
}

.empty-data {
  text-align: center;
  padding: 40px 0;
}

@media (max-width: 768px) {
  .profile-container {
    padding: 10px;
  }
}

/* 自定义表格样式 */
:deep(.el-table) {
  border-radius: 8px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

:deep(.el-table__header th) {
  background-color: #f5f7fa !important;
  color: #606266;
  font-weight: bold;
  padding: 12px 0;
}

:deep(.el-table__row:hover) {
  background-color: #ecf5ff !important;
}

/* 刷新按钮样式 */
.refresh-btn {
  padding: 10px 20px;
  font-size: 16px;
  font-weight: bold;
}

.field-tip {
  color: #909399;
  font-size: 12px;
  margin-top: 5px;
}
</style> 