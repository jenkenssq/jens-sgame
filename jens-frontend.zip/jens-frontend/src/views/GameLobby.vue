<template>
  <div class="game-lobby">
    <div class="lobby-header">
      <h1>游戏大厅</h1>
      <p>选择你想体验的精彩游戏</p>
    </div>

    <div class="game-grid">
      <el-row :gutter="30">
        <el-col :xs="24" :sm="12" :md="6" v-for="game in games" :key="game.id">
          <el-card shadow="hover" class="game-card" v-loading="loading">
            <div class="game-image" :style="{ backgroundImage: `url(${game.image})` }">
              <div class="game-badge" v-if="game.id === 'tetris'">热门</div>
            </div>
            
            <div class="game-content">
              <h3>{{ game.name }}</h3>
              <p>{{ game.description }}</p>
              
              <div class="game-stats" v-if="isLoggedIn">
                <div class="stat">
                  <i class="el-icon-trophy"></i>
                  <div class="stat-info">
                    <span>最高分</span>
                    <strong>{{ game.highScore || 0 }}</strong>
                  </div>
                </div>
                <div class="stat">
                  <i class="el-icon-timer"></i>
                  <div class="stat-info">
                    <span>游戏次数</span>
                    <strong>{{ game.playCount || 0 }}</strong>
                  </div>
                </div>
              </div>
              
              <el-button type="primary" class="play-button" @click="playGame(game.route)">
                <i class="el-icon-video-play"></i> 开始游戏
              </el-button>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script>
import { ref, computed, onMounted } from 'vue'
import { useStore } from 'vuex'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import gameApi from '../api/game'

export default {
  name: 'GameLobby',
  setup() {
    const store = useStore()
    const router = useRouter()
    const loading = ref(false)
    
    const isLoggedIn = computed(() => store.getters.isLoggedIn)
    const currentUser = computed(() => store.getters.currentUser)
    
    // 游戏数据
    const games = ref([
      {
        id: 'sokoban',
        name: '推箱子',
        description: '经典益智游戏，考验你的空间思维能力',
        image: '/images/sokoban.svg',
        route: '/games/sokoban',
        highScore: 0,
        playCount: 0
      },
      {
        id: 'tetris',
        name: '俄罗斯方块',
        description: '风靡全球的俄罗斯方块，挑战你的反应能力',
        image: '/images/tetris.svg',
        route: '/games/tetris',
        highScore: 0,
        playCount: 0
      },
      {
        id: 'snake',
        name: '贪吃蛇',
        description: '控制小蛇吃食物，不断成长',
        image: '/images/snake.svg',
        route: '/games/snake',
        highScore: 0,
        playCount: 0
      },
      {
        id: 'tank',
        name: '坦克大战',
        description: '经典坦克射击游戏，保卫基地',
        image: '/images/tank.svg',
        route: '/games/tank',
        highScore: 0,
        playCount: 0
      }
    ])
    
    // 跳转到游戏页面
    const playGame = (route) => {
      router.push(route)
    }
    
    // 加载用户游戏统计数据
    const loadUserGameStats = async () => {
      if (!isLoggedIn.value) return
      
      try {
        loading.value = true
        
        // 为每种游戏获取用户数据
        const promises = games.value.map(async (game) => {
          try {
            const response = await gameApi.getUserGameRecords(game.id)
            
            if (response && response.records && response.records.length > 0) {
              // 计算最高分
              const highScore = Math.max(...response.records.map(record => record.score || 0))
              // 游戏次数
              const playCount = response.total || response.records.length
              
              // 更新游戏数据
              game.highScore = highScore
              game.playCount = playCount
            }
          } catch (error) {
            console.error(`获取游戏 ${game.id} 的数据失败:`, error)
          }
        })
        
        await Promise.all(promises)
      } catch (error) {
        ElMessage.error('获取游戏数据失败')
      } finally {
        loading.value = false
      }
    }
    
    // 加载游戏列表数据
    const loadGameList = async () => {
      try {
        loading.value = true
        const response = await gameApi.getGameList()
        
        if (response && response.games && response.games.length > 0) {
          // 更新游戏列表的额外信息
          response.games.forEach(apiGame => {
            const existingGame = games.value.find(g => g.id === apiGame.id)
            if (existingGame) {
              // 更新游戏描述等信息
              existingGame.description = apiGame.description || existingGame.description
              existingGame.image = apiGame.image || existingGame.image
            }
          })
        }
        
        // 加载用户游戏统计数据
        await loadUserGameStats()
      } catch (error) {
        ElMessage.error('获取游戏列表失败')
      } finally {
        loading.value = false
      }
    }
    
    onMounted(() => {
      loadGameList()
    })
    
    return {
      games,
      loading,
      isLoggedIn,
      currentUser,
      playGame
    }
  }
}
</script>

<style scoped>
.game-lobby {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.lobby-header {
  text-align: center;
  margin-bottom: 50px;
  position: relative;
  padding-bottom: 20px;
}

.lobby-header:after {
  content: '';
  position: absolute;
  width: 80px;
  height: 4px;
  background: linear-gradient(90deg, #6a11cb, #2575fc);
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  border-radius: 2px;
}

.lobby-header h1 {
  font-size: 2.5rem;
  margin-bottom: 10px;
  color: #303133;
  font-weight: 600;
}

.lobby-header p {
  font-size: 1.2rem;
  color: #606266;
  max-width: 600px;
  margin: 0 auto;
}

.game-grid {
  margin-bottom: 40px;
}

.game-card {
  margin-bottom: 30px;
  transition: all 0.3s ease;
  height: 100%;
  border: none;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 6px 16px rgba(0, 0, 0, 0.05);
}

.game-card:hover {
  transform: translateY(-8px);
  box-shadow: 0 12px 24px rgba(0, 0, 0, 0.1);
}

.game-image {
  height: 180px;
  background-size: cover;
  background-position: center;
  position: relative;
  border-radius: 12px 12px 0 0;
}

.game-badge {
  position: absolute;
  top: 12px;
  right: 12px;
  background: #ff4d4f;
  color: white;
  padding: 4px 10px;
  border-radius: 20px;
  font-size: 0.8rem;
  font-weight: 600;
}

.game-content {
  padding: 20px;
}

.game-card h3 {
  font-size: 1.4rem;
  margin-bottom: 10px;
  color: #303133;
  font-weight: 600;
}

.game-card p {
  margin-bottom: 20px;
  color: #606266;
  height: 40px;
  line-height: 1.5;
}

.game-stats {
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px;
  padding: 15px 0;
  border-top: 1px solid #f2f2f2;
  border-bottom: 1px solid #f2f2f2;
}

.stat {
  display: flex;
  align-items: center;
}

.stat i {
  font-size: 1.8rem;
  margin-right: 12px;
  color: #6a11cb;
}

.stat-info {
  display: flex;
  flex-direction: column;
}

.stat span {
  font-size: 0.9rem;
  color: #909399;
  margin-bottom: 5px;
}

.stat strong {
  font-size: 1.2rem;
  color: #303133;
}

.play-button {
  width: 100%;
  border-radius: 30px;
  padding: 12px;
  font-weight: 600;
  font-size: 1.1rem;
  background: linear-gradient(90deg, #6a11cb, #2575fc);
  border: none;
  transition: all 0.3s ease;
}

.play-button:hover {
  opacity: 0.9;
  transform: translateY(-2px);
  box-shadow: 0 7px 14px rgba(37, 117, 252, 0.2);
}

.play-button i {
  margin-right: 6px;
}
</style> 