<template>
  <div class="leaderboard-container">
    <h1>游戏排行榜</h1>
    
    <div class="game-selector">
      <el-tabs v-model="activeTab" @tab-click="handleTabClick">
        <!-- 推箱子排行榜 -->
        <el-tab-pane label="推箱子" name="sokoban">
          <div class="tab-content">
            <el-radio-group v-model="sokobanFilter" @change="handleFilterChange" class="filter-group">
              <el-radio label="level">按关卡</el-radio>
              <el-radio label="steps">最少步数</el-radio>
              <el-radio label="time">最短时间</el-radio>
            </el-radio-group>
            
            <div class="leaderboard-table-container">
              <el-table
                :data="leaderboardData"
                style="width: 100%"
                :empty-text="loading ? '加载中...' : '暂无数据'"
                v-loading="loading">
                <el-table-column type="index" label="排名" width="80" />
                <el-table-column prop="username" label="用户名" min-width="150" />
                <el-table-column prop="level" label="关卡" min-width="100" sortable />
                <el-table-column prop="steps" label="步数" min-width="100" sortable />
                <el-table-column prop="duration" label="用时" min-width="120" sortable>
                  <template #default="scope">{{ formatTime(scope.row.duration) }}</template>
                </el-table-column>
                <el-table-column prop="score" label="得分" min-width="100" sortable />
                <el-table-column prop="date" label="日期" min-width="120" align="right" fixed="right" />
              </el-table>
            </div>
          </div>
        </el-tab-pane>
        
        <!-- 俄罗斯方块排行榜 -->
        <el-tab-pane label="俄罗斯方块" name="tetris">
          <div class="tab-content">
            <el-radio-group v-model="tetrisFilter" @change="handleFilterChange" class="filter-group">
              <el-radio label="score">最高分</el-radio>
              <el-radio label="lines">消除行数</el-radio>
              <el-radio label="level">最高等级</el-radio>
            </el-radio-group>
            
            <div class="leaderboard-table-container">
              <el-table
                :data="leaderboardData"
                style="width: 100%"
                :empty-text="loading ? '加载中...' : '暂无数据'"
                v-loading="loading">
                <el-table-column type="index" label="排名" width="80" />
                <el-table-column prop="username" label="用户名" min-width="150" />
                <el-table-column prop="score" label="分数" min-width="120" sortable />
                <el-table-column prop="lines" label="消除行数" min-width="120" sortable />
                <el-table-column prop="level" label="等级" min-width="100" sortable />
                <el-table-column prop="duration" label="游戏时长" min-width="120" sortable>
                  <template #default="scope">{{ formatTime(scope.row.duration) }}</template>
                </el-table-column>
                <el-table-column prop="date" label="日期" min-width="120" align="right" fixed="right" />
              </el-table>
            </div>
          </div>
        </el-tab-pane>
        
        <!-- 贪吃蛇排行榜 -->
        <el-tab-pane label="贪吃蛇" name="snake">
          <div class="tab-content">
            <el-radio-group v-model="snakeFilter" @change="handleFilterChange" class="filter-group">
              <el-radio label="score">最高分</el-radio>
              <el-radio label="length">最长长度</el-radio>
              <el-radio label="time">最长生存</el-radio>
            </el-radio-group>
            
            <div class="leaderboard-table-container">
              <el-table
                :data="leaderboardData"
                style="width: 100%"
                :empty-text="loading ? '加载中...' : '暂无数据'"
                v-loading="loading">
                <el-table-column type="index" label="排名" width="80" />
                <el-table-column prop="username" label="用户名" min-width="150" />
                <el-table-column prop="score" label="分数" min-width="120" sortable />
                <el-table-column prop="length" label="蛇长" min-width="120" sortable />
                <el-table-column prop="duration" label="生存时间" min-width="120" sortable>
                  <template #default="scope">{{ formatTime(scope.row.duration) }}</template>
                </el-table-column>
                <el-table-column prop="date" label="日期" min-width="120" align="right" fixed="right" />
              </el-table>
            </div>
          </div>
        </el-tab-pane>
        
        <!-- 坦克大战排行榜 -->
        <el-tab-pane label="坦克大战" name="tank">
          <div class="tab-content">
            <el-radio-group v-model="tankFilter" @change="handleFilterChange" class="filter-group">
              <el-radio label="score">最高分</el-radio>
              <el-radio label="kills">击杀数</el-radio>
              <el-radio label="level">最高关卡</el-radio>
            </el-radio-group>
            
            <div class="leaderboard-table-container">
              <el-table
                :data="leaderboardData"
                style="width: 100%"
                :empty-text="loading ? '加载中...' : '暂无数据'"
                v-loading="loading">
                <el-table-column type="index" label="排名" width="80" />
                <el-table-column prop="username" label="用户名" min-width="150" />
                <el-table-column prop="score" label="分数" min-width="120" sortable />
                <el-table-column prop="kills" label="击杀数" min-width="120" sortable />
                <el-table-column prop="level" label="关卡" min-width="100" sortable />
                <el-table-column prop="duration" label="游戏时长" min-width="120" sortable>
                  <template #default="scope">{{ formatTime(scope.row.duration) }}</template>
                </el-table-column>
                <el-table-column prop="mode" label="模式" min-width="100">
                  <template #default="scope">
                    {{ scope.row.mode === 'classic' ? '经典模式' : '生存模式' }}
                  </template>
                </el-table-column>
                <el-table-column prop="date" label="日期" min-width="120" align="right" fixed="right" />
              </el-table>
            </div>
          </div>
        </el-tab-pane>
      </el-tabs>
    </div>
    
    <div class="pagination-container">
      <el-pagination
        background
        layout="prev, pager, next"
        :total="total"
        :page-size="pageSize"
        @current-change="handleCurrentChange">
      </el-pagination>
    </div>
  </div>
</template>

<script>
import { ref, onMounted, watch } from 'vue'
import { ElMessage } from 'element-plus'
import gameApi from '../api/game'

export default {
  name: 'Leaderboard',
  setup() {
    const activeTab = ref('sokoban')
    const loading = ref(false)
    const leaderboardData = ref([])
    const total = ref(0)
    const pageSize = ref(10)
    const currentPage = ref(1)
    
    // 保存API响应的信息
    const lastResponseGameType = ref('');
    const lastResponseFilterType = ref('');
    
    // 各游戏的排序过滤条件
    const sokobanFilter = ref('level')
    const tetrisFilter = ref('score')
    const snakeFilter = ref('score')
    const tankFilter = ref('score')
    
    const fetchLeaderboard = async () => {
      loading.value = true
      try {
        // 确定当前使用的过滤条件
        let filterType = 'score' // 默认值
        
        switch (activeTab.value) {
          case 'sokoban':
            filterType = sokobanFilter.value
            break
          case 'tetris':
            filterType = tetrisFilter.value
            break
          case 'snake':
            filterType = snakeFilter.value
            break
          case 'tank':
            filterType = tankFilter.value
            break
        }
        
        console.log(`正在获取排行榜数据 - 游戏: ${activeTab.value}, 过滤条件: ${filterType}`);
        
        // 调用API获取排行榜数据
        const response = await gameApi.getLeaderboard(activeTab.value, 20, filterType)
        
        // 保存API响应的游戏类型和过滤方式
        lastResponseGameType.value = response.game_type || activeTab.value;
        lastResponseFilterType.value = response.filter_type || filterType;
        
        // 处理获取到的数据，确保字段格式一致
        const records = response.records || []
        
        // 格式化记录数据
        const formattedRecords = records
          .filter(record => record.game_type === activeTab.value)
          .map(record => {
            // 处理字段，确保所有游戏类型都有相同的基础字段
            const formattedRecord = {
              ...record,
              // 确保每个记录都有duration字段
              duration: record.duration || record.time || 0
            }
            
            // 根据游戏类型处理特殊字段
            switch (activeTab.value) {
              case 'sokoban':
                // 确保步数字段存在
                formattedRecord.steps = record.steps || 0;
                break;
              case 'tetris':
                // 确保消除行数字段存在
                formattedRecord.lines = record.lines || 0;
                break;
              case 'snake':
                // 确保蛇长字段存在，并且time映射到duration
                formattedRecord.length = record.length || 0;
                if (record.time && !record.duration) {
                  formattedRecord.duration = record.time;
                }
                break;
              case 'tank':
                // 确保击杀数和模式字段存在
                formattedRecord.kills = record.kills || 0;
                formattedRecord.mode = record.mode || 'classic';
                break;
            }
            
            return formattedRecord;
          })
        
        // 按用户分组，只保留每个用户的最佳记录
        const userBestRecords = {};
        
        formattedRecords.forEach(record => {
          const userId = record.user_id;
          const username = record.username;
          
          // 如果用户不存在于记录中，或者当前记录更优，则更新记录
          if (!userBestRecords[userId] || isBetterRecord(record, userBestRecords[userId])) {
            userBestRecords[userId] = record;
          }
        });
        
        // 将对象转换回数组并排序
        leaderboardData.value = Object.values(userBestRecords).sort((a, b) => {
          // 根据游戏类型和过滤条件排序
          switch (activeTab.value) {
            case 'sokoban':
              if (filterType === 'level') return b.level - a.level;
              if (filterType === 'steps') return a.steps - b.steps;
              if (filterType === 'time') return a.duration - b.duration;
              return b.score - a.score;
            
            case 'tetris':
              if (filterType === 'lines') return b.lines - a.lines;
              if (filterType === 'level') return b.level - a.level;
              return b.score - a.score;
            
            case 'snake':
              if (filterType === 'length') return b.length - a.length;
              if (filterType === 'time') return b.duration - a.duration;
              return b.score - a.score;
            
            case 'tank':
              if (filterType === 'kills') return b.kills - a.kills;
              if (filterType === 'level') return b.level - a.level;
              return b.score - a.score;
            
            default:
              return b.score - a.score;
          }
        });
        
        total.value = leaderboardData.value.length
        
        // 调试输出
        console.log('获取到排行榜数据:', response);
        console.log('处理后的最佳记录数据:', leaderboardData.value);
      } catch (error) {
        console.error('获取排行榜数据失败:', error)
        ElMessage.error('获取排行榜数据失败')
      } finally {
        loading.value = false
      }
    }
    
    // 获取当前使用的过滤条件
    const getCurrentFilter = () => {
      switch (activeTab.value) {
        case 'sokoban': return sokobanFilter.value
        case 'tetris': return tetrisFilter.value
        case 'snake': return snakeFilter.value
        case 'tank': return tankFilter.value
        default: return 'score'
      }
    }
    
    // 格式化时间（秒）为 分:秒 格式
    const formatTime = (seconds) => {
      if (!seconds && seconds !== 0) return '--'
      
      const mins = Math.floor(seconds / 60)
      const secs = Math.round(seconds % 60)
      return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
    }
    
    // Tab切换处理
    const handleTabClick = (tab) => {
      console.log(`切换到游戏类型: ${tab.props.name}`);
      // 直接使用tab.props.name，避免activeTab响应式更新延迟
      activeTab.value = tab.props.name;
      currentPage.value = 1;
      fetchLeaderboard();
    }
    
    // 监听activeTab变化，确保数据加载
    watch(activeTab, (newValue, oldValue) => {
      if (newValue !== oldValue) {
        console.log(`activeTab变化: ${oldValue} -> ${newValue}`);
        currentPage.value = 1;
        fetchLeaderboard();
      }
    });
    
    // 过滤条件变更
    const handleFilterChange = () => {
      currentPage.value = 1
      fetchLeaderboard()
    }
    
    // 页码变更
    const handleCurrentChange = (page) => {
      currentPage.value = page
      fetchLeaderboard()
    }
    
    // 判断是否为更好的记录
    const isBetterRecord = (newRecord, oldRecord) => {
      if (!oldRecord) return true;
      
      switch (activeTab.value) {
        case 'sokoban':
          // 推箱子：优先选择关卡等级更高的记录
          if (newRecord.level > oldRecord.level) return true;
          if (newRecord.level < oldRecord.level) return false;
          
          // 如果关卡相同，优先选择分数更高的
          return newRecord.score > oldRecord.score;
        
        case 'tetris':
          // 俄罗斯方块：优先选择分数更高的记录
          return newRecord.score > oldRecord.score;
        
        case 'snake':
          // 贪吃蛇：优先选择分数更高的记录
          return newRecord.score > oldRecord.score;
        
        case 'tank':
          // 坦克大战：优先选择分数更高的记录
          return newRecord.score > oldRecord.score;
        
        default:
          return newRecord.score > oldRecord.score;
      }
    };
    
    // 初始化时获取数据
    onMounted(() => {
      fetchLeaderboard()
    })
    
    return {
      activeTab,
      loading,
      leaderboardData,
      total,
      pageSize,
      currentPage,
      sokobanFilter,
      tetrisFilter,
      snakeFilter,
      tankFilter,
      handleTabClick,
      handleFilterChange,
      handleCurrentChange,
      formatTime,
      getCurrentFilter,
      fetchLeaderboard,
      lastResponseGameType,
      lastResponseFilterType
    }
  }
}
</script>

<style scoped>
.leaderboard-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

h1 {
  text-align: center;
  margin-bottom: 30px;
  color: #303133;
}

.game-selector {
  margin-bottom: 20px;
}

.tab-content {
  padding: 20px 0;
}

.filter-group {
  margin-bottom: 20px;
  display: flex;
  justify-content: center;
}

.leaderboard-table-container {
  margin-top: 20px;
  overflow-x: auto; /* 确保在小屏幕上可以水平滚动 */
}

/* 自定义表格样式 */
:deep(.el-table) {
  font-size: 16px;
  border-radius: 8px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
  table-layout: auto; /* 自适应列宽 */
}

:deep(.el-table__header-wrapper) {
  background-color: #f5f7fa;
}

:deep(.el-table__header th) {
  background-color: #f5f7fa !important;
  color: #606266;
  font-weight: bold;
  padding: 16px 0;
  height: 60px;
}

/* 确保固定列的表头样式一致 */
:deep(.el-table .is-right.is-fixed .cell),
:deep(.el-table .is-right.is-fixed),
:deep(.el-table .is-fixed) {
  background-color: #f5f7fa !important;
}

:deep(.el-table__fixed-right) {
  height: auto !important;
  box-shadow: -2px 0 8px rgba(0, 0, 0, 0.1);
}

:deep(.el-table__fixed-right .el-table__header th) {
  background-color: #f5f7fa !important;
}

:deep(.el-table__body td) {
  padding: 14px 0;
  height: 55px;
}

/* 改进日期列样式 */
:deep(.el-table .is-right) {
  text-align: right;
}

:deep(.el-table .is-right .cell) {
  padding-right: 20px;
}

/* 表格行样式 */
:deep(.el-table__row) {
  transition: background-color 0.3s;
}

:deep(.el-table__row:hover) {
  background-color: #ecf5ff !important;
}

/* 奇数行和偶数行样式 */
:deep(.el-table__row--striped) {
  background-color: #fafafa;
}

/* 强调第一名的样式 */
:deep(.el-table__row:first-child) {
  font-weight: bold;
  color: #303133;
}

/* 排名列样式 */
:deep(.el-table__row:first-child .el-table_1_column_1 .cell) {
  color: #f56c6c;
  font-size: 18px;
}

:deep(.el-table__row:nth-child(2) .el-table_1_column_1 .cell) {
  color: #e6a23c;
  font-size: 16px;
}

:deep(.el-table__row:nth-child(3) .el-table_1_column_1 .cell) {
  color: #67c23a;
  font-size: 16px;
}

.pagination-container {
  margin-top: 30px;
  text-align: center;
}

@media (max-width: 768px) {
  .leaderboard-container {
    padding: 10px;
  }
  
  .filter-group {
    flex-direction: column;
    align-items: center;
  }
  
  /* 移动端表格样式调整 */
  :deep(.el-table) {
    font-size: 14px;
  }
  
  :deep(.el-table__header th) {
    padding: 12px 0;
    height: 50px;
  }
  
  :deep(.el-table__body td) {
    padding: 10px 0;
    height: 45px;
  }
}
</style> 