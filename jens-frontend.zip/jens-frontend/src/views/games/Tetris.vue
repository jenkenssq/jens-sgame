<template>
  <div class="tetris-container">
    <div class="tetris-info">
      <div class="score-board">
        <div class="score">分数: {{ score }}</div>
        <div class="level">级别: {{ level }}</div>
        <div class="lines">消除行数: {{ lines }}</div>
      </div>
      <div class="next-block">
        <h3>下一个方块</h3>
        <div class="next-block-preview">
          <div v-for="(row, y) in nextBlockMatrix" :key="`next-${y}`" class="row">
            <div v-for="(cell, x) in row" :key="`next-${y}-${x}`" :class="['cell', cell ? `color-${nextBlock.type}` : '']"></div>
          </div>
        </div>
      </div>
      <div class="controls">
        <button @click="startGame" v-if="gameStatus === 'ready' || gameStatus === 'over'">开始游戏</button>
        <button @click="pauseGame" v-if="gameStatus === 'playing'">暂停</button>
        <button @click="resumeGame" v-if="gameStatus === 'paused'">继续</button>
        <button @click="resetGame" v-if="gameStatus === 'over'">重新开始</button>
        <button @click="returnToGameHall" class="return-btn">返回游戏大厅</button>
      </div>
      <div class="instructions">
        <h3>操作说明</h3>
        <p>← → : 左右移动</p>
        <p>↑ : 旋转</p>
        <p>↓ : 加速下落</p>
        <p>空格 : 直接落下</p>
        <p>P : 暂停/继续</p>
      </div>
    </div>
    <div class="tetris-board" tabindex="0" @keydown="handleKeydown" ref="tetrisBoard">
      <div v-for="(row, y) in drawMatrix" :key="`game-${y}`" class="row">
        <div 
          v-for="(cell, x) in row" 
          :key="`game-${y}-${x}`" 
          :class="['cell', cell ? `color-${cell}` : '', (ghostPosition && containsPosition(ghostPosition, x, y)) ? 'ghost' : '']"
        ></div>
      </div>
    </div>
  </div>
</template>

<script>
import gameApi from '../../api/game'

// 定义7种俄罗斯方块的形状和旋转状态
const TETROMINOES = {
  I: {
    shape: [
      [0, 0, 0, 0],
      [1, 1, 1, 1],
      [0, 0, 0, 0],
      [0, 0, 0, 0]
    ],
    rotations: 2
  },
  J: {
    shape: [
      [1, 0, 0],
      [1, 1, 1],
      [0, 0, 0]
    ],
    rotations: 4
  },
  L: {
    shape: [
      [0, 0, 1],
      [1, 1, 1],
      [0, 0, 0]
    ],
    rotations: 4
  },
  O: {
    shape: [
      [1, 1],
      [1, 1]
    ],
    rotations: 1
  },
  S: {
    shape: [
      [0, 1, 1],
      [1, 1, 0],
      [0, 0, 0]
    ],
    rotations: 2
  },
  T: {
    shape: [
      [0, 1, 0],
      [1, 1, 1],
      [0, 0, 0]
    ],
    rotations: 4
  },
  Z: {
    shape: [
      [1, 1, 0],
      [0, 1, 1],
      [0, 0, 0]
    ],
    rotations: 2
  }
};

export default {
  name: 'TetrisGame',
  data() {
    return {
      // 游戏状态
      gameStatus: 'ready', // ready, playing, paused, over
      
      // 游戏区域大小
      boardWidth: 10,
      boardHeight: 20,
      
      // 游戏矩阵 - 0 表示空白，数字 1-7 表示不同颜色的方块
      gameMatrix: [],
      
      // 当前方块信息
      currentBlock: null,
      
      // 下一个方块信息
      nextBlock: null,
      nextBlockMatrix: [],
      
      // 方块下落位置和旋转状态
      blockPosition: { x: 0, y: 0 },
      currentRotation: 0,
      
      // 游戏统计数据
      score: 0,
      level: 1,
      lines: 0,
      
      // 游戏速度 (毫秒)
      speed: 1000,
      
      // 下落定时器
      fallTimer: null,
      
      // 幽灵方块位置（显示方块将落在哪里）
      ghostPosition: null,
      
      // 游戏开始时间
      gameStartTime: null,
    };
  },
  
  mounted() {
    this.initGame();
    window.addEventListener('keydown', this.handleKeydown);
  },
  
  beforeUnmount() {
    window.removeEventListener('keydown', this.handleKeydown);
    this.clearTimers();
  },
  
  methods: {
    // 初始化游戏
    initGame() {
      this.gameMatrix = Array(this.boardHeight).fill().map(() => Array(this.boardWidth).fill(0));
      this.currentBlock = null;
      this.nextBlock = this.generateRandomBlock();
      this.score = 0;
      this.level = 1;
      this.lines = 0;
      this.speed = 1000;
      this.gameStatus = 'ready';
      this.updateNextBlockMatrix();
      this.gameStartTime = new Date();
    },
    
    // 开始游戏
    startGame() {
      if (this.gameStatus !== 'ready') return;
      
      this.resetGame();
      this.gameStatus = 'playing';
      this.gameStartTime = new Date(); // 添加游戏开始时间记录
      this.startFallTimer();
    },
    
    // 暂停游戏
    pauseGame() {
      if (this.gameStatus === 'playing') {
        this.gameStatus = 'paused';
        this.clearTimers();
      }
    },
    
    // 继续游戏
    resumeGame() {
      if (this.gameStatus === 'paused') {
        this.gameStatus = 'playing';
        this.startFallTimer();
      }
    },
    
    // 重置游戏
    resetGame() {
      this.clearTimers();
      this.initGame();
    },
    
    // 生成随机方块
    generateRandomBlock() {
      const types = Object.keys(TETROMINOES);
      const type = types[Math.floor(Math.random() * types.length)];
      return {
        type,
        shape: TETROMINOES[type].shape,
        rotations: TETROMINOES[type].rotations
      };
    },
    
    // 生成新方块
    generateNewBlock() {
      this.currentBlock = this.nextBlock;
      this.nextBlock = this.generateRandomBlock();
      this.updateNextBlockMatrix();
      
      // 设置初始位置在顶部中间
      this.blockPosition = {
        x: Math.floor((this.boardWidth - this.currentBlock.shape[0].length) / 2),
        y: 0
      };
      this.currentRotation = 0;
      
      // 计算幽灵方块位置
      this.calculateGhostPosition();
      
      // 检查是否游戏结束（新方块与已有方块重叠）
      if (this.checkCollision(this.blockPosition.x, this.blockPosition.y, this.currentBlock.shape)) {
        this.gameOver();
      }
    },
    
    // 更新下一个方块的预览矩阵
    updateNextBlockMatrix() {
      if (!this.nextBlock) return;
      
      const shape = this.nextBlock.shape;
      this.nextBlockMatrix = Array(4).fill().map(() => Array(4).fill(0));
      
      // 居中显示下一个方块
      const offsetX = Math.floor((4 - shape[0].length) / 2);
      const offsetY = Math.floor((4 - shape.length) / 2);
      
      for (let y = 0; y < shape.length; y++) {
        for (let x = 0; x < shape[y].length; x++) {
          if (shape[y][x]) {
            this.nextBlockMatrix[y + offsetY][x + offsetX] = 1;
          }
        }
      }
    },
    
    // 开始方块下落定时器
    startFallTimer() {
      this.clearTimers();
      this.fallTimer = setInterval(() => {
        this.moveDown();
      }, this.speed);
    },
    
    // 清除所有定时器
    clearTimers() {
      if (this.fallTimer) {
        clearInterval(this.fallTimer);
        this.fallTimer = null;
      }
    },
    
    // 计算幽灵方块位置
    calculateGhostPosition() {
      if (!this.currentBlock) return null;
      
      const pos = { ...this.blockPosition };
      while (!this.checkCollision(pos.x, pos.y + 1, this.currentBlock.shape)) {
        pos.y++;
      }
      
      this.ghostPosition = this.getBlockPositions(pos.x, pos.y, this.currentBlock.shape);
    },
    
    // 获取方块所有方格的位置
    getBlockPositions(x, y, shape) {
      const positions = [];
      for (let row = 0; row < shape.length; row++) {
        for (let col = 0; col < shape[row].length; col++) {
          if (shape[row][col]) {
            positions.push({ x: x + col, y: y + row });
          }
        }
      }
      return positions;
    },
    
    // 检查位置是否在幽灵方块中
    containsPosition(positions, x, y) {
      return positions.some(pos => pos.x === x && pos.y === y);
    },
    
    // 检查碰撞
    checkCollision(x, y, shape) {
      for (let row = 0; row < shape.length; row++) {
        for (let col = 0; col < shape[row].length; col++) {
          if (shape[row][col]) {
            const newX = x + col;
            const newY = y + row;
            
            // 检查边界
            if (newX < 0 || newX >= this.boardWidth || newY >= this.boardHeight) {
              return true;
            }
            
            // 检查与其他方块碰撞
            if (newY >= 0 && this.gameMatrix[newY][newX]) {
              return true;
            }
          }
        }
      }
      return false;
    },
    
    // 旋转方块
    rotateBlock() {
      if (!this.currentBlock || this.currentBlock.rotations === 1) return;
      
      const rotated = this.rotateMatrix(this.currentBlock.shape);
      
      // 检查旋转后是否发生碰撞，如果是，尝试进行墙踢
      if (!this.checkCollision(this.blockPosition.x, this.blockPosition.y, rotated)) {
        this.currentBlock.shape = rotated;
        this.calculateGhostPosition();
      } else {
        // 尝试墙踢 (左右移动一格尝试旋转)
        const kicks = [1, -1, 2, -2];
        for (const kick of kicks) {
          if (!this.checkCollision(this.blockPosition.x + kick, this.blockPosition.y, rotated)) {
            this.blockPosition.x += kick;
            this.currentBlock.shape = rotated;
            this.calculateGhostPosition();
            break;
          }
        }
      }
    },
    
    // 旋转矩阵 (顺时针旋转90度)
    rotateMatrix(matrix) {
      const N = matrix.length;
      const result = Array(N).fill().map(() => Array(N).fill(0));
      
      for (let i = 0; i < N; i++) {
        for (let j = 0; j < N; j++) {
          result[j][N - 1 - i] = matrix[i][j];
        }
      }
      
      return result;
    },
    
    // 左移方块
    moveLeft() {
      if (this.gameStatus !== 'playing') return;
      
      if (!this.checkCollision(this.blockPosition.x - 1, this.blockPosition.y, this.currentBlock.shape)) {
        this.blockPosition.x--;
        this.calculateGhostPosition();
      }
    },
    
    // 右移方块
    moveRight() {
      if (this.gameStatus !== 'playing') return;
      
      if (!this.checkCollision(this.blockPosition.x + 1, this.blockPosition.y, this.currentBlock.shape)) {
        this.blockPosition.x++;
        this.calculateGhostPosition();
      }
    },
    
    // 下移方块
    moveDown() {
      if (this.gameStatus !== 'playing') return;
      
      if (!this.checkCollision(this.blockPosition.x, this.blockPosition.y + 1, this.currentBlock.shape)) {
        this.blockPosition.y++;
        // 增加得分
        this.score += 1 * this.level;
      } else {
        this.lockBlock();
      }
    },
    
    // 直接落下方块
    hardDrop() {
      if (this.gameStatus !== 'playing') return;
      
      while (!this.checkCollision(this.blockPosition.x, this.blockPosition.y + 1, this.currentBlock.shape)) {
        this.blockPosition.y++;
        // 增加得分
        this.score += 2 * this.level;
      }
      
      this.lockBlock();
    },
    
    // 锁定方块
    lockBlock() {
      // 将当前方块添加到游戏矩阵中
      for (let row = 0; row < this.currentBlock.shape.length; row++) {
        for (let col = 0; col < this.currentBlock.shape[row].length; col++) {
          if (this.currentBlock.shape[row][col]) {
            const matrixY = this.blockPosition.y + row;
            const matrixX = this.blockPosition.x + col;
            
            if (matrixY >= 0 && matrixY < this.boardHeight && matrixX >= 0 && matrixX < this.boardWidth) {
              // 使用方块类型作为颜色索引 (1-7)
              const typeIndex = Object.keys(TETROMINOES).indexOf(this.currentBlock.type) + 1;
              this.gameMatrix[matrixY][matrixX] = typeIndex;
            }
          }
        }
      }
      
      // 检查并清除完整行
      this.clearLines();
      
      // 生成新方块
      this.generateNewBlock();
      
      // 重置下落定时器
      this.startFallTimer();
    },
    
    // 清除完整行
    clearLines() {
      let linesCleared = 0;
      
      for (let row = this.boardHeight - 1; row >= 0; row--) {
        // 检查行是否已填满
        if (this.gameMatrix[row].every(cell => cell !== 0)) {
          // 移除该行
          this.gameMatrix.splice(row, 1);
          // 在顶部添加新空行
          this.gameMatrix.unshift(Array(this.boardWidth).fill(0));
          linesCleared++;
          row++; // 再次检查当前行，因为行已下移
        }
      }
      
      if (linesCleared > 0) {
        // 增加统计
        this.lines += linesCleared;
        
        // 计算得分 (2的行数次方 * 级别 * 10)
        const lineScore = Math.pow(2, linesCleared) * this.level * 10;
        this.score += lineScore;
        
        // 每清除10行升一级
        const newLevel = Math.floor(this.lines / 10) + 1;
        if (newLevel > this.level) {
          this.level = newLevel;
          // 调整下落速度
          this.speed = Math.max(100, 1000 - (this.level - 1) * 100);
          this.startFallTimer();
        }
      }
    },
    
    // 游戏结束
    gameOver() {
      this.gameStatus = 'over';
      this.clearTimers();
      
      // 保存游戏记录到排行榜
      this.saveGameRecord();
    },
    
    // 保存游戏记录
    async saveGameRecord() {
      try {
        const gameEndTime = new Date();
        const gameStartTime = this.gameStartTime || new Date(gameEndTime - this.score * 10); // 估算游戏开始时间
        const duration = Math.floor((gameEndTime - gameStartTime) / 1000);
        
        await gameApi.saveGameRecord('tetris', {
          score: this.score,
          lines: this.lines,
          level: this.level,
          duration: duration,
          completed: this.gameStatus === 'over', // 游戏结束认为已完成
          date: new Date().toISOString().split('T')[0]
        });
        console.log('俄罗斯方块游戏记录保存成功');
      } catch (error) {
        console.error('保存游戏记录失败:', error);
      }
    },
    
    // 处理键盘事件
    handleKeydown(event) {
      if (this.gameStatus !== 'playing') {
        // 如果游戏暂停，只响应继续键
        if (event.key === 'p' || event.key === 'P') {
          if (this.gameStatus === 'paused') {
            this.resumeGame();
          } else if (this.gameStatus === 'playing') {
            this.pauseGame();
          }
        }
        return;
      }
      
      switch (event.key) {
        case 'ArrowLeft':
          event.preventDefault();
          this.moveLeft();
          break;
        case 'ArrowRight':
          event.preventDefault();
          this.moveRight();
          break;
        case 'ArrowDown':
          event.preventDefault();
          this.moveDown();
          break;
        case 'ArrowUp':
          event.preventDefault();
          this.rotateBlock();
          break;
        case ' ': // 空格键
          event.preventDefault();
          this.hardDrop();
          break;
        case 'p':
        case 'P':
          this.pauseGame();
          break;
      }
    },
    
    // 返回游戏大厅
    returnToGameHall() {
      this.clearTimers();
      this.$router.push('/games');
    },
  },
  
  computed: {
    // 计算绘制游戏矩阵
    drawMatrix() {
      // 创建游戏矩阵的深拷贝
      const matrix = this.gameMatrix.map(row => [...row]);
      
      // 添加当前方块到矩阵
      if (this.currentBlock) {
        for (let row = 0; row < this.currentBlock.shape.length; row++) {
          for (let col = 0; col < this.currentBlock.shape[row].length; col++) {
            if (this.currentBlock.shape[row][col]) {
              const matrixY = this.blockPosition.y + row;
              const matrixX = this.blockPosition.x + col;
              
              if (matrixY >= 0 && matrixY < this.boardHeight && matrixX >= 0 && matrixX < this.boardWidth) {
                const typeIndex = Object.keys(TETROMINOES).indexOf(this.currentBlock.type) + 1;
                matrix[matrixY][matrixX] = typeIndex;
              }
            }
          }
        }
      }
      
      return matrix;
    }
  }
};
</script>

<style scoped>
.tetris-container {
  display: flex;
  justify-content: center;
  padding: 20px;
  font-family: Arial, sans-serif;
}

.tetris-board {
  border: 2px solid #333;
  background-color: #f0f0f0;
  width: 300px;
  height: 600px;
  display: flex;
  flex-direction: column;
  outline: none;
}

.tetris-info {
  margin-right: 20px;
  width: 200px;
}

.score-board {
  background-color: #333;
  color: white;
  padding: 10px;
  margin-bottom: 20px;
  border-radius: 5px;
}

.score, .level, .lines {
  margin: 5px 0;
  font-size: 18px;
}

.next-block {
  background-color: #f0f0f0;
  padding: 10px;
  border: 2px solid #333;
  margin-bottom: 20px;
}

.next-block h3 {
  margin-top: 0;
  text-align: center;
}

.next-block-preview {
  width: 100px;
  height: 100px;
  margin: 0 auto;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.controls {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-bottom: 20px;
}

.controls button {
  padding: 10px;
  background-color: #333;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 16px;
}

.controls .return-btn {
  background-color: #f44336;
  margin-top: 20px;
  width: 100%;
}

.controls button:hover {
  background-color: #555;
}

.controls .return-btn:hover {
  background-color: #d32f2f;
}

.instructions {
  background-color: #f0f0f0;
  padding: 10px;
  border: 2px solid #333;
  margin-bottom: 20px;
}

.instructions h3 {
  margin-top: 0;
  text-align: center;
}

.instructions p {
  margin: 5px 0;
}

.row {
  display: flex;
  height: 30px;
}

.cell {
  width: 30px;
  height: 30px;
  box-sizing: border-box;
  border: 1px solid #ddd;
}

/* 方块颜色 */
.color-1 {
  background-color: #00f0f0; /* I - 青色 */
}

.color-2 {
  background-color: #0000f0; /* J - 蓝色 */
}

.color-3 {
  background-color: #f0a000; /* L - 橙色 */
}

.color-4 {
  background-color: #f0f000; /* O - 黄色 */
}

.color-5 {
  background-color: #00f000; /* S - 绿色 */
}

.color-6 {
  background-color: #a000f0; /* T - 紫色 */
}

.color-7 {
  background-color: #f00000; /* Z - 红色 */
}

.ghost {
  background-color: rgba(255, 255, 255, 0.3);
  border: 1px dashed #999;
}

@media (max-width: 768px) {
  .tetris-container {
    flex-direction: column;
    align-items: center;
  }
  
  .tetris-info {
    margin-right: 0;
    margin-bottom: 20px;
    width: 300px;
  }
}
</style>
