<template>
  <div class="snake-game">
    <div class="game-info">
      <h1>贪吃蛇游戏</h1>
      <div class="score">分数: {{ score }}</div>
      <div class="control-buttons">
        <button @click="startGame" v-if="!gameStarted" class="main-btn">开始游戏</button>
        <button @click="pauseGame" v-if="gameStarted && !gamePaused" class="main-btn">暂停</button>
        <button @click="resumeGame" v-if="gameStarted && gamePaused" class="main-btn">继续</button>
        <button @click="restartGame" v-if="gameOver" class="main-btn">重新开始</button>
        <button @click="returnToGameHall" class="return-btn">返回游戏大厅</button>
      </div>
      <div class="game-over" v-if="gameOver">游戏结束!</div>
    </div>

    <div 
      class="game-board" 
      ref="gameBoard"
      tabindex="0" 
      @keydown="handleKeydown"
    >
      <div class="grid" :style="gridStyle">
        <!-- 蛇的身体 -->
        <div 
          v-for="(segment, index) in snake" 
          :key="`snake-${index}`" 
          class="snake-segment"
          :style="getPositionStyle(segment.x, segment.y)"
        ></div>
        
        <!-- 食物 -->
        <div 
          v-if="food" 
          class="food"
          :style="getPositionStyle(food.x, food.y)"
        ></div>
      </div>
    </div>
    
    <div class="instructions">
      <h3>操作说明</h3>
      <p>使用方向键 (↑ ↓ ← →) 或 (W A S D) 控制蛇的移动方向</p>
    </div>
  </div>
</template>

<script>
import gameApi from '../../api/game'

export default {
  name: 'SnakeGame',
  data() {
    return {
      // 游戏板尺寸
      boardSize: 20,
      // 蛇的身体（每个部分的x,y坐标）
      snake: [
        { x: 10, y: 10 },
        { x: 9, y: 10 },
        { x: 8, y: 10 }
      ],
      // 蛇的移动方向
      direction: 'right',
      // 下一个方向（防止在一个更新周期内多次改变方向）
      nextDirection: 'right',
      // 食物位置
      food: null,
      // 游戏循环计时器
      gameInterval: null,
      // 游戏速度（毫秒）
      gameSpeed: 150,
      // 游戏状态
      gameStarted: false,
      gamePaused: false, 
      gameOver: false,
      // 分数
      score: 0,
      startTime: Date.now()
    }
  },
  computed: {
    gridStyle() {
      return {
        gridTemplateColumns: `repeat(${this.boardSize}, 20px)`,
        gridTemplateRows: `repeat(${this.boardSize}, 20px)`
      }
    }
  },
  methods: {
    // 开始游戏
    startGame() {
      this.gameStarted = true;
      this.gamePaused = false;
      this.gameOver = false;
      this.score = 0;
      this.startTime = Date.now();
      
      // 重置蛇的位置
      this.snake = [
        { x: 10, y: 10 },
        { x: 9, y: 10 },
        { x: 8, y: 10 }
      ];
      
      this.direction = 'right';
      this.nextDirection = 'right';
      
      // 生成第一个食物
      this.generateFood();
      
      // 启动游戏循环
      this.gameInterval = setInterval(this.gameLoop, this.gameSpeed);
      
      // 设置焦点到游戏板以便接收键盘事件
      this.$nextTick(() => {
        this.$refs.gameBoard.focus();
      });
    },
    
    // 暂停游戏
    pauseGame() {
      if (this.gameStarted && !this.gamePaused) {
        this.gamePaused = true;
        clearInterval(this.gameInterval);
      }
    },
    
    // 继续游戏
    resumeGame() {
      if (this.gameStarted && this.gamePaused) {
        this.gamePaused = false;
        this.gameInterval = setInterval(this.gameLoop, this.gameSpeed);
        this.$refs.gameBoard.focus();
      }
    },
    
    // 重新开始游戏
    restartGame() {
      this.startGame();
    },
    
    // 返回游戏大厅
    returnToGameHall() {
      // 清除游戏循环
      if (this.gameInterval) {
        clearInterval(this.gameInterval);
      }
      this.$router.push('/games');
    },
    
    // 游戏主循环
    gameLoop() {
      // 更新方向
      this.direction = this.nextDirection;
      
      // 移动蛇
      const head = { ...this.snake[0] };
      
      // 根据方向更新蛇头位置
      switch (this.direction) {
        case 'up':
          head.y -= 1;
          break;
        case 'down':
          head.y += 1;
          break;
        case 'left':
          head.x -= 1;
          break;
        case 'right':
          head.x += 1;
          break;
      }
      
      // 检查碰撞
      if (this.checkCollision(head)) {
        this.endGame();
        return;
      }
      
      // 将新的头部添加到蛇身
      this.snake.unshift(head);
      
      // 检查是否吃到食物
      if (head.x === this.food.x && head.y === this.food.y) {
        // 增加分数
        this.score += 10;
        // 生成新的食物
        this.generateFood();
        
        // 每得50分加快游戏速度
        if (this.score % 50 === 0 && this.gameSpeed > 50) {
          clearInterval(this.gameInterval);
          this.gameSpeed -= 10;
          this.gameInterval = setInterval(this.gameLoop, this.gameSpeed);
        }
      } else {
        // 如果没吃到食物，移除蛇尾（保持蛇的长度）
        this.snake.pop();
      }
    },
    
    // 生成食物
    generateFood() {
      let newFood;
      
      // 确保食物不会生成在蛇身上
      do {
        newFood = {
          x: Math.floor(Math.random() * this.boardSize),
          y: Math.floor(Math.random() * this.boardSize)
        };
      } while (this.snake.some(segment => segment.x === newFood.x && segment.y === newFood.y));
      
      this.food = newFood;
    },
    
    // 检查碰撞（与墙壁或自身）
    checkCollision(head) {
      // 检查是否撞墙
      if (head.x < 0 || head.x >= this.boardSize || head.y < 0 || head.y >= this.boardSize) {
        return true;
      }
      
      // 检查是否撞到自己（从第1个开始，因为第0个就是头部自己）
      return this.snake.slice(1).some(segment => segment.x === head.x && segment.y === head.y);
    },
    
    // 结束游戏
    endGame() {
      this.gameOver = true;
      this.gameStarted = false;
      clearInterval(this.gameInterval);
      
      // 保存游戏记录到排行榜
      this.saveGameRecord();
    },
    
    // 保存游戏记录
    async saveGameRecord() {
      try {
        const duration = Math.floor((Date.now() - this.startTime) / 1000);
        
        await gameApi.saveGameRecord('snake', {
          score: this.score,
          length: this.snake.length,
          time: duration,
          duration: duration, // API要求的字段名
          completed: this.gameOver && this.score > 0,
          date: new Date().toISOString().split('T')[0]
        });
        console.log('贪吃蛇游戏记录保存成功');
      } catch (error) {
        console.error('保存游戏记录失败:', error);
      }
    },
    
    // 处理键盘输入
    handleKeydown(e) {
      // 如果游戏未开始或已暂停，忽略键盘输入
      if (!this.gameStarted || this.gamePaused) return;
      
      switch (e.key) {
        // 上方向
        case 'ArrowUp':
        case 'w':
        case 'W':
          if (this.direction !== 'down') this.nextDirection = 'up';
          break;
        // 下方向
        case 'ArrowDown':
        case 's':
        case 'S':
          if (this.direction !== 'up') this.nextDirection = 'down';
          break;
        // 左方向
        case 'ArrowLeft':
        case 'a':
        case 'A':
          if (this.direction !== 'right') this.nextDirection = 'left';
          break;
        // 右方向
        case 'ArrowRight':
        case 'd':
        case 'D':
          if (this.direction !== 'left') this.nextDirection = 'right';
          break;
        // 空格暂停/继续
        case ' ':
          if (this.gamePaused) {
            this.resumeGame();
          } else {
            this.pauseGame();
          }
          break;
      }
      
      // 防止方向键滚动页面
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', ' '].includes(e.key)) {
        e.preventDefault();
      }
    },
    
    // 获取元素的定位样式
    getPositionStyle(x, y) {
      return {
        gridRowStart: y + 1,
        gridColumnStart: x + 1
      }
    }
  },
  // 组件卸载时清除计时器
  beforeUnmount() {
    if (this.gameInterval) {
      clearInterval(this.gameInterval);
    }
  }
}
</script>

<style scoped>
.snake-game {
  display: flex;
  flex-direction: column;
  align-items: center;
  font-family: Arial, sans-serif;
  margin: 20px auto;
  max-width: 600px;
}

.game-info {
  text-align: center;
  margin-bottom: 20px;
  width: 100%;
  max-width: 400px;
}

.score {
  font-size: 1.5rem;
  font-weight: bold;
  margin: 10px 0;
}

.control-buttons {
  margin: 15px 0;
  display: flex;
  flex-direction: column;
  gap: 10px;
  width: 100%;
}

button {
  padding: 10px 16px;
  text-align: center;
  text-decoration: none;
  font-size: 16px;
  cursor: pointer;
  border-radius: 4px;
  transition: background-color 0.3s;
  border: none;
  height: 40px;
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
}

.main-btn {
  background-color: #4caf50;
  color: white;
}

.main-btn:hover {
  background-color: #45a049;
}

.return-btn {
  background-color: #f44336;
  color: white;
  margin-top: 5px;
}

.return-btn:hover {
  background-color: #d32f2f;
}

.game-over {
  color: red;
  font-size: 1.5rem;
  font-weight: bold;
  margin: 10px 0;
}

.game-board {
  border: 2px solid #333;
  outline: none;
  background-color: #f5f5f5;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
}

.grid {
  display: grid;
  gap: 1px;
  background-color: #e0e0e0;
}

.snake-segment {
  background-color: #388e3c;
  border-radius: 2px;
}

.snake-segment:first-child {
  background-color: #2e7d32;
  border-radius: 3px;
}

.food {
  background-color: #f44336;
  border-radius: 50%;
}

.instructions {
  margin-top: 20px;
  text-align: center;
}

.instructions h3 {
  margin-bottom: 5px;
}

.instructions p {
  color: #666;
}
</style>
