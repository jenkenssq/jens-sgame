<template>
  <div class="sokoban-game">
    <h1>推箱子</h1>
    
    <div class="game-container">
      <div class="game-info">
        <div class="info-item">
          <span>关卡</span>
          <strong>{{ currentLevel }}</strong>
        </div>
        <div class="info-item">
          <span>步数</span>
          <strong>{{ steps }}</strong>
        </div>
        <div class="info-item">
          <span>时间</span>
          <strong>{{ formatTime(gameTime) }}</strong>
        </div>
      </div>
      
      <div class="game-board" ref="gameBoard">
        <canvas ref="gameCanvas" width="400" height="400"></canvas>
      </div>
      
      <div class="game-controls">
        <div class="button-group">
          <el-button @click="resetLevel" class="control-btn">重置关卡</el-button>
          <el-button @click="undoMove" :disabled="!canUndo" class="control-btn">撤销</el-button>
          <el-button @click="showLevelSelect" class="control-btn">选择关卡</el-button>
          <el-button @click="showHelp" class="control-btn">帮助</el-button>
          <el-button @click="returnToGameHall" type="danger" class="return-btn">返回游戏大厅</el-button>
        </div>
      </div>
    </div>
    
    <!-- 游戏帮助对话框 -->
    <el-dialog
      title="游戏帮助"
      v-model="helpDialogVisible"
      width="30%">
      <div class="help-content">
        <h3>游戏规则</h3>
        <p>将所有箱子推到目标点上即可通关。</p>
        <h3>操作方法</h3>
        <p>使用键盘方向键或WASD控制角色移动。</p>
        <ul>
          <li>↑ / W: 向上移动</li>
          <li>↓ / S: 向下移动</li>
          <li>← / A: 向左移动</li>
          <li>→ / D: 向右移动</li>
          <li>R: 重置关卡</li>
          <li>Z: 撤销上一步</li>
        </ul>
      </div>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="helpDialogVisible = false">关闭</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 关卡选择对话框 -->
    <el-dialog
      title="选择关卡"
      v-model="levelSelectDialogVisible"
      width="50%">
      <div class="level-select-content">
        <div class="level-grid">
          <div 
            v-for="(level, index) in availableLevels" 
            :key="index"
            class="level-item"
            :class="{ 'level-completed': isLevelCompleted(index + 1), 'current-level': currentLevel === index + 1 }"
            @click="selectLevel(index + 1)">
            <span>{{ index + 1 }}</span>
            <el-tag size="small" v-if="isLevelCompleted(index + 1)" type="success">已通关</el-tag>
          </div>
        </div>
      </div>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="levelSelectDialogVisible = false">关闭</el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 关卡完成对话框 -->
    <el-dialog
      title="恭喜通关！"
      v-model="levelCompletedDialogVisible"
      width="30%">
      <div class="level-completed-content">
        <h3>关卡 {{ currentLevel }} 完成！</h3>
        <div class="level-stats">
          <p>步数: {{ steps }}</p>
          <p>用时: {{ formatTime(gameTime) }}</p>
          <p>得分: {{ steps < 20 ? 15 : 10 }}
            <span v-if="steps < 20" class="bonus-text">(步数少于20，额外奖励5分)</span>
          </p>
        </div>
        <div class="actions">
          <el-button type="primary" @click="nextLevel">下一关</el-button>
          <el-button @click="retryLevel">重新挑战</el-button>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { ref, onMounted, onUnmounted } from 'vue'
import { useRouter } from 'vue-router'
import { useStore } from 'vuex'
import { ElMessage } from 'element-plus'
import gameApi from '../../api/game'

export default {
  name: 'Sokoban',
  setup() {
    const router = useRouter();
    const store = useStore();
    
    // 基础状态
    const currentLevel = ref(1);
    const steps = ref(0);
    const gameTime = ref(0);
    const gameStarted = ref(false);
    const gameInterval = ref(null);
    const canUndo = ref(false);
    
    // 对话框状态
    const helpDialogVisible = ref(false);
    const levelSelectDialogVisible = ref(false);
    const levelCompletedDialogVisible = ref(false);

    // DOM 引用
    const gameBoard = ref(null);
    const gameCanvas = ref(null);
    
    // 游戏数据
    const gameState = ref({
      level: 1,
      map: [],
      player: { x: 0, y: 0 },
      boxes: [],
      targets: [],
      history: [],
      completedLevels: []
    });

    // 存储用户已完成的关卡信息
    const completedLevels = ref(JSON.parse(localStorage.getItem('sokoban_completed_levels') || '[]'));

    // 游戏素材
    const assets = {
      wall: '/images/games/sokoban/wall.png',
      floor: '/images/games/sokoban/floor.png',
      box: '/images/games/sokoban/box.png',
      boxOnTarget: '/images/games/sokoban/box_on_target.png',
      target: '/images/games/sokoban/target.png',
      player: '/images/games/sokoban/player.png',
      playerOnTarget: '/images/games/sokoban/player_on_target.png'
    };

    // 游戏关卡数据 
    const gameLevels = [
      // 关卡 1
      {
        map: [
          [1, 1, 1, 1, 1, 1, 1],
          [1, 0, 0, 0, 0, 0, 1],
          [1, 0, 0, 2, 0, 0, 1],
          [1, 0, 2, 0, 3, 0, 1],
          [1, 0, 3, 0, 0, 0, 1],
          [1, 0, 0, 0, 0, 0, 1],
          [1, 1, 1, 1, 1, 1, 1]
        ],
        player: { x: 3, y: 3 },
        boxes: [
          { x: 3, y: 2 },
          { x: 2, y: 3 },
        ],
        targets: [
          { x: 4, y: 3 },
          { x: 3, y: 4 },
        ]
      },
      // 关卡 2
      {
        map: [
          [1, 1, 1, 1, 1, 1, 1, 1],
          [1, 0, 0, 0, 0, 0, 0, 1],
          [1, 0, 3, 0, 2, 0, 0, 1],
          [1, 0, 0, 0, 0, 3, 0, 1],
          [1, 0, 2, 0, 0, 0, 0, 1],
          [1, 0, 0, 0, 0, 0, 0, 1],
          [1, 1, 1, 1, 1, 1, 1, 1],
        ],
        player: { x: 1, y: 1 },
        boxes: [
          { x: 4, y: 2 },
          { x: 2, y: 4 },
        ],
        targets: [
          { x: 2, y: 2 },
          { x: 5, y: 3 },
        ]
      },
      // 关卡 3
      {
        map: [
          [1, 1, 1, 1, 1, 1, 1],
          [1, 0, 0, 0, 0, 0, 1],
          [1, 0, 1, 1, 1, 0, 1],
          [1, 0, 0, 2, 0, 0, 1],
          [1, 0, 3, 0, 3, 0, 1],
          [1, 0, 0, 2, 0, 0, 1],
          [1, 1, 1, 1, 1, 1, 1]
        ],
        player: { x: 1, y: 1 },
        boxes: [
          { x: 3, y: 3 },
          { x: 3, y: 5 },
        ],
        targets: [
          { x: 2, y: 4 },
          { x: 4, y: 4 },
        ]
      },
      // 关卡 4
      {
        map: [
          [1, 1, 1, 1, 1, 1, 1, 1],
          [1, 0, 0, 0, 1, 0, 0, 1],
          [1, 0, 1, 0, 2, 0, 0, 1],
          [1, 0, 3, 0, 0, 2, 0, 1],
          [1, 0, 0, 0, 0, 3, 0, 1],
          [1, 0, 0, 1, 0, 0, 0, 1],
          [1, 1, 1, 1, 1, 1, 1, 1],
        ],
        player: { x: 1, y: 1 },
        boxes: [
          { x: 4, y: 2 },
          { x: 5, y: 3 },
        ],
        targets: [
          { x: 2, y: 3 },
          { x: 5, y: 4 },
        ]
      },
      // 关卡 5 - 更复杂的关卡
      {
        map: [
          [1, 1, 1, 1, 1, 1, 1, 1, 1],
          [1, 0, 0, 0, 1, 0, 0, 0, 1],
          [1, 0, 0, 0, 1, 0, 0, 0, 1],
          [1, 0, 1, 0, 0, 0, 1, 0, 1],
          [1, 0, 0, 0, 2, 0, 0, 0, 1],
          [1, 1, 0, 2, 0, 3, 0, 1, 1],
          [1, 0, 0, 0, 3, 0, 0, 0, 1],
          [1, 0, 0, 0, 1, 0, 0, 0, 1],
          [1, 1, 1, 1, 1, 1, 1, 1, 1],
        ],
        player: { x: 4, y: 4 },
        boxes: [
          { x: 3, y: 5 },
          { x: 4, y: 6 },
        ],
        targets: [
          { x: 5, y: 5 },
          { x: 4, y: 5 },
        ]
      }
    ];

    const availableLevels = ref(gameLevels);

    // 初始化游戏
    const initGame = () => {
      loadLevel(currentLevel.value);
      
      // 预加载游戏资源
      preloadAssets();
      
      // 检查是否有保存的游戏设置
      loadGameSettings();
      
      // 启动游戏循环
      startGameLoop();
    };
    
    // 预加载资源
    const preloadAssets = () => {
      // 这里可以添加预加载图片等资源的代码
      Object.values(assets).forEach(src => {
        const img = new Image();
        img.src = src;
      });
    };

    // 加载游戏设置
    const loadGameSettings = async () => {
      if (!store.getters.isLoggedIn) return;
      
      try {
        const settings = await gameApi.getGameSettings('sokoban');
        if (settings && settings.currentLevel) {
          currentLevel.value = settings.currentLevel;
          loadLevel(currentLevel.value);
        }
      } catch (error) {
        console.error('加载游戏设置失败:', error);
      }
    };

    // 保存游戏设置
    const saveGameSettings = async () => {
      if (!store.getters.isLoggedIn) return;
      
      try {
        await gameApi.saveGameSettings('sokoban', {
          currentLevel: currentLevel.value,
          completedLevels: completedLevels.value
        });
      } catch (error) {
        console.error('保存游戏设置失败:', error);
      }
    };

    // 加载关卡
    const loadLevel = (levelNumber) => {
      // 确保关卡号在有效范围内
      if (levelNumber < 1 || levelNumber > availableLevels.value.length) {
        levelNumber = 1;
      }
      
      currentLevel.value = levelNumber;
      const levelData = availableLevels.value[levelNumber - 1];
      
      // 复制关卡数据以避免修改原始数据
      gameState.value = {
        level: levelNumber,
        map: JSON.parse(JSON.stringify(levelData.map)),
        player: { ...levelData.player },
        boxes: levelData.boxes.map(box => ({ ...box })),
        targets: levelData.targets.map(target => ({ ...target })),
        history: [],
        completedLevels: [...completedLevels.value]
      };
      
      steps.value = 0;
      canUndo.value = false;
      
      renderGame();
    };
    
    // 游戏循环
    const startGameLoop = () => {
      // 清除之前的定时器
      if (gameInterval.value) {
        clearInterval(gameInterval.value);
      }
      
      gameTime.value = 0;
      gameStarted.value = true;
      
      gameInterval.value = setInterval(() => {
        gameTime.value++;
        // 实时渲染游戏
        renderGame();
      }, 1000);
    };
    
    // 键盘事件处理
    const handleKeyDown = (event) => {
      if (!gameStarted.value) return;
      
      const key = event.key.toLowerCase();
      
      switch (key) {
        case 'arrowup':
        case 'w':
          movePlayer(0, -1);
          break;
        case 'arrowdown':
        case 's':
          movePlayer(0, 1);
          break;
        case 'arrowleft':
        case 'a':
          movePlayer(-1, 0);
          break;
        case 'arrowright':
        case 'd':
          movePlayer(1, 0);
          break;
        case 'r':
          resetLevel();
          break;
        case 'z':
          undoMove();
          break;
      }
    };
    
    // 移动玩家
    const movePlayer = (dx, dy) => {
      const player = gameState.value.player;
      const newX = player.x + dx;
      const newY = player.y + dy;
      
      // 检查是否可以移动
      if (isWall(newX, newY)) return;
      
      // 检查是否有箱子
      const boxIndex = getBoxAt(newX, newY);
      if (boxIndex !== -1) {
        // 有箱子，检查箱子是否可以移动
        const newBoxX = newX + dx;
        const newBoxY = newY + dy;
        
        if (isWall(newBoxX, newBoxY) || getBoxAt(newBoxX, newBoxY) !== -1) {
          return; // 箱子无法移动
        }
        
        // 保存当前状态用于撤销
        saveHistory();
        
        // 移动箱子
        gameState.value.boxes[boxIndex].x = newBoxX;
        gameState.value.boxes[boxIndex].y = newBoxY;
        
        // 移动玩家
        gameState.value.player.x = newX;
        gameState.value.player.y = newY;
        
        steps.value++;
        canUndo.value = true;
        
        // 播放推箱子音效
        playSound('push');
        
        // 检查是否完成
        checkCompletion();
      } else {
        // 没有箱子，直接移动玩家
        saveHistory();
        gameState.value.player.x = newX;
        gameState.value.player.y = newY;
        steps.value++;
        canUndo.value = true;
        
        // 播放移动音效
        playSound('move');
      }
      
      // 重新渲染游戏
      renderGame();
    };
    
    // 播放音效
    const playSound = (type) => {
      // 根据需要添加音效播放逻辑
      // 此处仅为示例，实际项目中可以通过HTML5 Audio API或其他音频库实现
      // const sound = new Audio(`/sounds/sokoban/${type}.mp3`);
      // sound.play();
    };
    
    // 检查是否墙壁
    const isWall = (x, y) => {
      return gameState.value.map[y][x] === 1;
    };
    
    // 获取指定位置的箱子索引
    const getBoxAt = (x, y) => {
      return gameState.value.boxes.findIndex(box => box.x === x && box.y === y);
    };
    
    // 检查指定位置是否为目标
    const isTarget = (x, y) => {
      return gameState.value.targets.some(target => target.x === x && target.y === y);
    };
    
    // 保存历史状态（用于撤销）
    const saveHistory = () => {
      const history = {
        player: { ...gameState.value.player },
        boxes: gameState.value.boxes.map(box => ({ ...box })),
        steps: steps.value
      };
      gameState.value.history.push(history);
      
      // 限制历史记录长度，避免内存过度占用
      if (gameState.value.history.length > 100) {
        gameState.value.history.shift();
      }
    };
    
    // 撤销移动
    const undoMove = () => {
      if (!canUndo.value || gameState.value.history.length === 0) return;
      
      const lastState = gameState.value.history.pop();
      gameState.value.player = lastState.player;
      gameState.value.boxes = lastState.boxes;
      steps.value = lastState.steps;
      
      if (gameState.value.history.length === 0) {
        canUndo.value = false;
      }
      
      // 播放撤销音效
      playSound('undo');
      
      renderGame();
    };
    
    // 检查是否完成关卡
    const checkCompletion = () => {
      // 检查所有箱子是否都在目标点上
      const allCompleted = gameState.value.boxes.every(box => {
        return gameState.value.targets.some(target => 
          target.x === box.x && target.y === box.y
        );
      });
      
      if (allCompleted) {
        levelCompleted();
      }
    };
    
    // 关卡完成
    const levelCompleted = () => {
      clearInterval(gameInterval.value);
      gameStarted.value = false;
      
      // 记录已完成的关卡
      if (!completedLevels.value.includes(currentLevel.value)) {
        completedLevels.value.push(currentLevel.value);
        localStorage.setItem('sokoban_completed_levels', JSON.stringify(completedLevels.value));
      }
      
      // 计算本关得分
      let levelScore = 10; // 基础分10分
      if (steps.value < 20) {
        levelScore += 5; // 步数小于20步额外加5分
      }
      
      // 显示通关信息
      ElMessage({
        message: `恭喜通关！得分：${levelScore}分 ${steps.value < 20 ? '(步数少于20步，获得额外5分)' : ''}`,
        type: 'success',
        duration: 3000
      });
      
      // 保存到服务器（如果用户已登录）
      saveGameRecord();
      
      // 显示通关对话框
      levelCompletedDialogVisible.value = true;
      
      // 播放通关音效
      playSound('complete');
    };
    
    // 保存游戏记录
    const saveGameRecord = async (isCompleted = true) => {
      if (!store.getters.isLoggedIn) return;
      
      try {
        // 计算得分：每完成一关10分，步数小于20额外加5分
        let score = 0;
        if (isCompleted) {
          score = 10; // 完成关卡基础分10分
          if (steps.value < 20) {
            score += 5; // 步数小于20加5分
          }
        }
        
        const result = await gameApi.saveGameRecord('sokoban', {
          level: currentLevel.value,
          score: score,
          steps: steps.value,
          time: gameTime.value,
          duration: gameTime.value, // API要求的字段名
          completed: isCompleted, // 是否完成关卡
          date: new Date().toISOString().split('T')[0]
        });
        console.log('推箱子游戏记录保存成功', result);
        
        // 保存当前游戏设置
        saveGameSettings();
      } catch (error) {
        console.error('保存游戏记录失败:', error);
      }
    };
    
    // 下一关
    const nextLevel = () => {
      levelCompletedDialogVisible.value = false;
      
      if (currentLevel.value < availableLevels.value.length) {
        currentLevel.value++;
        loadLevel(currentLevel.value);
        startGameLoop();
      } else {
        // 所有关卡都完成了
        ElMessage({
          message: '恭喜！您已经完成了所有关卡！',
          type: 'success'
        });
        
        // 返回游戏大厅
        setTimeout(() => {
          router.push('/games');
        }, 2000);
      }
    };
    
    // 重新挑战当前关卡
    const retryLevel = () => {
      levelCompletedDialogVisible.value = false;
      resetLevel();
    };
    
    // 重置关卡
    const resetLevel = () => {
      loadLevel(currentLevel.value);
      startGameLoop();
      
      // 播放重置音效
      playSound('reset');
    };
    
    // 显示帮助
    const showHelp = () => {
      helpDialogVisible.value = true;
    };
    
    // 显示关卡选择
    const showLevelSelect = () => {
      levelSelectDialogVisible.value = true;
    };
    
    // 选择关卡
    const selectLevel = (level) => {
      if (level === currentLevel.value) {
        levelSelectDialogVisible.value = false;
        return;
      }
      
      // 只允许选择已完成关卡的下一关
      const maxAllowedLevel = Math.max(...completedLevels.value, 1) + 1;
      if (level > maxAllowedLevel && level > 1) {
        ElMessage({
          message: '请先通过前面的关卡',
          type: 'warning'
        });
        return;
      }
      
      currentLevel.value = level;
      loadLevel(level);
      startGameLoop();
      levelSelectDialogVisible.value = false;
    };
    
    // 检查关卡是否已完成
    const isLevelCompleted = (level) => {
      return completedLevels.value.includes(level);
    };
    
    // 渲染游戏
    const renderGame = () => {
      const canvas = gameCanvas.value;
      if (!canvas) return;
      
      const ctx = canvas.getContext('2d');
      const tileSize = 40; // 每个格子的大小
      
      // 调整画布大小以适应地图
      const mapHeight = gameState.value.map.length;
      const mapWidth = gameState.value.map[0].length;
      canvas.width = mapWidth * tileSize;
      canvas.height = mapHeight * tileSize;
      
      // 清空画布
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // 创建离屏画布进行绘制（优化性能）
      const offscreenCanvas = document.createElement('canvas');
      offscreenCanvas.width = canvas.width;
      offscreenCanvas.height = canvas.height;
      const offCtx = offscreenCanvas.getContext('2d');
      
      // 绘制地图
      for (let y = 0; y < mapHeight; y++) {
        for (let x = 0; x < mapWidth; x++) {
          const tile = gameState.value.map[y][x];
          
          // 绘制地板
          offCtx.fillStyle = '#F5F5DC';
          offCtx.fillRect(x * tileSize, y * tileSize, tileSize, tileSize);
          
          // 绘制墙壁
          if (tile === 1) {
            offCtx.fillStyle = '#8B4513';
            offCtx.fillRect(x * tileSize, y * tileSize, tileSize, tileSize);
            // 添加墙壁纹理
            offCtx.strokeStyle = '#6B2D00';
            offCtx.lineWidth = 1;
            offCtx.strokeRect(x * tileSize + 2, y * tileSize + 2, tileSize - 4, tileSize - 4);
          }
        }
      }
      
      // 绘制目标点
      for (const target of gameState.value.targets) {
        offCtx.fillStyle = '#FF6347';
        offCtx.beginPath();
        offCtx.arc(
          target.x * tileSize + tileSize / 2,
          target.y * tileSize + tileSize / 2,
          tileSize / 6,
          0,
          Math.PI * 2
        );
        offCtx.fill();
      }
      
      // 绘制箱子
      for (const box of gameState.value.boxes) {
        // 检查箱子是否在目标点上
        const onTarget = gameState.value.targets.some(
          target => target.x === box.x && target.y === box.y
        );
        
        offCtx.fillStyle = onTarget ? '#32CD32' : '#CD853F';
        offCtx.fillRect(
          box.x * tileSize + 5,
          box.y * tileSize + 5,
          tileSize - 10,
          tileSize - 10
        );
        
        // 箱子边框
        offCtx.strokeStyle = onTarget ? '#228B22' : '#8B4513';
        offCtx.lineWidth = 2;
        offCtx.strokeRect(
          box.x * tileSize + 5,
          box.y * tileSize + 5,
          tileSize - 10,
          tileSize - 10
        );
        
        // 箱子纹理
        offCtx.beginPath();
        offCtx.moveTo(box.x * tileSize + 5, box.y * tileSize + 5);
        offCtx.lineTo(box.x * tileSize + tileSize - 5, box.y * tileSize + tileSize - 5);
        offCtx.moveTo(box.x * tileSize + tileSize - 5, box.y * tileSize + 5);
        offCtx.lineTo(box.x * tileSize + 5, box.y * tileSize + tileSize - 5);
        offCtx.stroke();
      }
      
      // 绘制玩家
      const player = gameState.value.player;
      // 检查玩家是否站在目标点上
      const playerOnTarget = isTarget(player.x, player.y);
      
      // 玩家外圈
      offCtx.fillStyle = playerOnTarget ? '#4682B4' : '#4169E1';
      offCtx.beginPath();
      offCtx.arc(
        player.x * tileSize + tileSize / 2,
        player.y * tileSize + tileSize / 2,
        tileSize / 3,
        0,
        Math.PI * 2
      );
      offCtx.fill();
      
      // 玩家内圈
      offCtx.fillStyle = playerOnTarget ? '#B0E0E6' : '#ADD8E6';
      offCtx.beginPath();
      offCtx.arc(
        player.x * tileSize + tileSize / 2,
        player.y * tileSize + tileSize / 2,
        tileSize / 5,
        0,
        Math.PI * 2
      );
      offCtx.fill();
      
      // 将离屏画布内容复制到主画布
      ctx.drawImage(offscreenCanvas, 0, 0);
    };
    
    // 格式化时间显示
    const formatTime = (seconds) => {
      const mins = Math.floor(seconds / 60);
      const secs = seconds % 60;
      return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    };

    // 在setup函数中添加returnToGameHall方法
    const returnToGameHall = () => {
      // 停止游戏计时
      if (gameInterval.value) {
        clearInterval(gameInterval.value);
      }
      
      // 保存当前游戏进度，但标记为未完成
      if (steps.value > 0) {
        saveGameRecord(false);
      }
      
      router.push('/games');
    };

    // 组件挂载
    onMounted(() => {
      // 初始化游戏
      initGame();
      
      // 添加键盘事件监听
      window.addEventListener('keydown', handleKeyDown);
    });
    
    // 组件卸载
    onUnmounted(() => {
      // 清理
      if (gameInterval.value) {
        clearInterval(gameInterval.value);
      }
      window.removeEventListener('keydown', handleKeyDown);
    });

    return {
      currentLevel,
      steps,
      gameTime,
      canUndo,
      helpDialogVisible,
      levelSelectDialogVisible,
      levelCompletedDialogVisible,
      gameBoard,
      gameCanvas,
      availableLevels,
      
      movePlayer,
      resetLevel,
      undoMove,
      showHelp,
      showLevelSelect,
      selectLevel,
      isLevelCompleted,
      nextLevel,
      retryLevel,
      formatTime,
      returnToGameHall
    };
  }
}
</script>

<style scoped>
.sokoban-game {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.sokoban-game h1 {
  text-align: center;
  margin-bottom: 20px;
}

.game-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
}

.game-info {
  display: flex;
  justify-content: space-around;
  width: 100%;
  margin-bottom: 20px;
  background-color: #f5f7fa;
  padding: 10px;
  border-radius: 4px;
}

.info-item {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.info-item span {
  font-size: 14px;
  color: #909399;
}

.info-item strong {
  font-size: 20px;
  color: #409EFF;
}

.game-board {
  margin-bottom: 20px;
  border: 2px solid #dcdfe6;
  border-radius: 4px;
}

.game-controls {
  width: 100%;
  max-width: 400px;
  margin: 20px auto;
}

.button-group {
  display: flex;
  flex-direction: column;
  gap: 10px;
  width: 100%;
}

/* 统一所有按钮样式 */
:deep(.el-button) {
  width: 100% !important;
  height: 40px !important;
  font-size: 16px !important;
  display: flex !important;
  justify-content: center !important;
  align-items: center !important;
  border-radius: 4px !important;
  margin: 0 !important;
}

:deep(.el-button.el-button--primary) {
  background-color: #409EFF !important;
}

:deep(.el-button.el-button--danger) {
  background-color: #F56C6C !important;
}

.control-btn,
.return-btn {
  width: 100%;
}

.help-content {
  line-height: 1.6;
}

.help-content h3 {
  margin-top: 15px;
  margin-bottom: 5px;
}

.help-content ul {
  padding-left: 20px;
}

.level-grid {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 10px;
}

.level-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background-color: #f5f7fa;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  padding: 15px;
  cursor: pointer;
  position: relative;
}

.level-item span {
  font-size: 18px;
  font-weight: bold;
}

.level-completed {
  background-color: #f0f9eb;
  border-color: #67c23a;
}

.current-level {
  background-color: #ecf5ff;
  border-color: #409eff;
}

.level-item:hover {
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

.level-select-content {
  padding: 20px;
}

.level-completed-content {
  text-align: center;
}

.level-stats {
  margin: 20px 0;
}

.bonus-text {
  color: #67C23A;
  font-size: 0.9em;
  margin-left: 5px;
}

/* 调整对话框中的按钮布局 */
.level-completed-content .actions {
  display: flex;
  flex-direction: column;
  width: 100%;
  gap: 10px;
}

:deep(.dialog-footer) {
  width: 100%;
  display: flex;
  justify-content: center;
}

:deep(.dialog-footer .el-button) {
  width: 100% !important;
}

/* 调整对话框样式 */
:deep(.el-dialog__body) {
  padding: 20px;
}

:deep(.el-dialog__footer) {
  padding: 10px 20px 20px;
}
</style> 