<template>
  <div class="tank-game">
    <div class="game-info">
      <h1>坦克大战</h1>
      <div class="score">得分: {{ score }}</div>
      <div class="lives">生命: {{ playerLives }}</div>
      <div class="control-buttons">
        <button @click="startGame" v-if="!gameStarted" class="main-btn">开始游戏</button>
        <button @click="pauseGame" v-if="gameStarted && !gamePaused" class="main-btn">暂停</button>
        <button @click="resumeGame" v-if="gameStarted && gamePaused" class="main-btn">继续</button>
        <button @click="restartGame" v-if="gameOver" class="main-btn">重新开始</button>
        <button @click="returnToGameHall" class="return-btn">返回游戏大厅</button>
      </div>
      <div class="game-over" v-if="gameOver">游戏结束!</div>
    </div>

    <div 
      class="game-board" 
      ref="gameBoard"
      tabindex="0" 
      @keydown="handleKeydown"
      @keyup="handleKeyup"
    >
      <!-- 玩家坦克 -->
      <div 
        v-if="playerTank" 
        class="tank player-tank"
        :style="getPositionStyle(playerTank.x, playerTank.y, playerTank.direction)"
      ></div>
      
      <!-- 敌方坦克 -->
      <div 
        v-for="(tank, index) in enemyTanks" 
        :key="`enemy-${index}`" 
        class="tank enemy-tank"
        :style="getPositionStyle(tank.x, tank.y, tank.direction)"
      ></div>
      
      <!-- 子弹 -->
      <div 
        v-for="(bullet, index) in bullets" 
        :key="`bullet-${index}`" 
        class="bullet"
        :style="getPositionStyle(bullet.x, bullet.y, bullet.direction)"
      ></div>
      
      <!-- 障碍物 -->
      <div 
        v-for="(wall, index) in walls" 
        :key="`wall-${index}`" 
        class="wall"
        :style="{
          left: wall.x * gridSize + 'px',
          top: wall.y * gridSize + 'px',
          width: gridSize + 'px',
          height: gridSize + 'px'
        }"
      ></div>
    </div>
    
    <div class="instructions">
      <h3>操作说明</h3>
      <p>使用方向键 (↑ ↓ ← →) 或 (W A S D) 控制坦克移动，空格键发射子弹</p>
    </div>
  </div>
</template>

<script>
import gameApi from '../../api/game'

export default {
  name: 'TankGame',
  data() {
    return {
      // 游戏状态
      gameStarted: false,
      gamePaused: false,
      gameOver: false,
      
      // 游戏参数
      gridSize: 30, // 每个网格的大小（像素）
      boardWidth: 20, // 游戏板宽度（网格数）
      boardHeight: 15, // 游戏板高度（网格数）
      
      // 玩家信息
      playerTank: null,
      playerSpeed: 3, // 每秒移动的网格数
      playerLives: 3,
      score: 0,
      level: 1, // 添加关卡字段
      killCount: 0, // 添加击杀计数
      
      // 游戏时间
      gameStartTime: null,
      
      // 敌方坦克
      enemyTanks: [],
      maxEnemies: 4,
      enemySpeed: 1.5, // 每秒移动的网格数
      
      // 障碍物
      walls: [],
      
      // 子弹
      bullets: [],
      bulletSpeed: 6, // 每秒移动的网格数
      
      // 按键状态
      keys: {
        up: false,
        down: false,
        left: false,
        right: false,
        fire: false
      },
      
      // 上次发射子弹的时间
      lastFireTime: 0,
      
      // 游戏循环
      gameLoop: null,
      lastTimestamp: 0
    }
  },
  methods: {
    // 开始游戏
    startGame() {
      this.gameStarted = true;
      this.gamePaused = false;
      this.gameOver = false;
      this.score = 0;
      this.playerLives = 3;
      this.bullets = [];
      
      // 初始化玩家坦克
      this.playerTank = {
        x: Math.floor(this.boardWidth / 2),
        y: this.boardHeight - 2,
        direction: 'up',
        width: 1,
        height: 1,
        lastMove: 0,
        canFire: true
      };
      
      // 初始化障碍物
      this.initWalls();
      
      // 初始化敌方坦克
      this.enemyTanks = [];
      this.spawnEnemies();
      
      // 开始游戏循环
      this.lastTimestamp = performance.now();
      this.gameLoop = requestAnimationFrame(this.update);
      
      // 设置焦点到游戏板以便接收键盘事件
      this.$nextTick(() => {
        this.$refs.gameBoard.focus();
      });
      
      // 初始化游戏时间
      this.gameStartTime = performance.now();
    },
    
    // 暂停游戏
    pauseGame() {
      if (this.gameStarted && !this.gamePaused) {
        this.gamePaused = true;
        cancelAnimationFrame(this.gameLoop);
      }
    },
    
    // 继续游戏
    resumeGame() {
      if (this.gameStarted && this.gamePaused) {
        this.gamePaused = false;
        this.lastTimestamp = performance.now();
        this.gameLoop = requestAnimationFrame(this.update);
        this.$refs.gameBoard.focus();
      }
    },
    
    // 重新开始游戏
    restartGame() {
      this.startGame();
    },
    
    // 返回游戏大厅
    returnToGameHall() {
      // 取消游戏循环
      if (this.gameLoop) {
        cancelAnimationFrame(this.gameLoop);
      }
      this.$router.push('/games');
    },
    
    // 游戏主循环
    update(timestamp) {
      const deltaTime = (timestamp - this.lastTimestamp) / 1000; // 转换为秒
      this.lastTimestamp = timestamp;
      
      // 移动玩家坦克
      this.movePlayerTank(deltaTime);
      
      // 移动敌方坦克
      this.moveEnemyTanks(deltaTime);
      
      // 移动子弹
      this.moveBullets(deltaTime);
      
      // 检测碰撞
      this.checkCollisions();
      
      // 敌方坦克AI
      this.updateEnemyAI(deltaTime);
      
      // 如果敌方坦克数量不足，生成新的敌方坦克
      if (this.enemyTanks.length < this.maxEnemies && Math.random() < 0.01) {
        this.spawnEnemies(1);
      }
      
      // 如果游戏未结束且未暂停，继续游戏循环
      if (!this.gameOver && !this.gamePaused) {
        this.gameLoop = requestAnimationFrame(this.update);
      }
    },
    
    // 移动玩家坦克
    movePlayerTank(deltaTime) {
      if (!this.playerTank) return;
      
      const moveDistance = this.playerSpeed * deltaTime;
      
      // 根据按键状态移动坦克
      if (this.keys.up) {
        this.playerTank.direction = 'up';
        const newY = this.playerTank.y - moveDistance;
        if (!this.checkWallCollision(this.playerTank.x, newY)) {
          this.playerTank.y = newY;
        }
      } else if (this.keys.down) {
        this.playerTank.direction = 'down';
        const newY = this.playerTank.y + moveDistance;
        if (!this.checkWallCollision(this.playerTank.x, newY)) {
          this.playerTank.y = newY;
        }
      } else if (this.keys.left) {
        this.playerTank.direction = 'left';
        const newX = this.playerTank.x - moveDistance;
        if (!this.checkWallCollision(newX, this.playerTank.y)) {
          this.playerTank.x = newX;
        }
      } else if (this.keys.right) {
        this.playerTank.direction = 'right';
        const newX = this.playerTank.x + moveDistance;
        if (!this.checkWallCollision(newX, this.playerTank.y)) {
          this.playerTank.x = newX;
        }
      }
      
      // 确保坦克不会超出边界
      this.playerTank.x = Math.max(0, Math.min(this.boardWidth - 1, this.playerTank.x));
      this.playerTank.y = Math.max(0, Math.min(this.boardHeight - 1, this.playerTank.y));
      
      // 发射子弹
      if (this.keys.fire && this.playerTank.canFire) {
        this.playerTank.canFire = false;
        this.fireBullet(this.playerTank, 'player');
        setTimeout(() => {
          if (this.playerTank) this.playerTank.canFire = true;
        }, 500); // 冷却时间
      }
    },
    
    // 移动敌方坦克
    moveEnemyTanks(deltaTime) {
      this.enemyTanks.forEach(tank => {
        const moveDistance = this.enemySpeed * deltaTime;
        
        // 根据方向移动坦克
        switch (tank.direction) {
          case 'up':
            tank.y -= moveDistance;
            break;
          case 'down':
            tank.y += moveDistance;
            break;
          case 'left':
            tank.x -= moveDistance;
            break;
          case 'right':
            tank.x += moveDistance;
            break;
        }
        
        // 确保坦克不会超出边界或穿过墙壁
        if (tank.x < 0 || tank.x > this.boardWidth - 1 || 
            tank.y < 0 || tank.y > this.boardHeight - 1 ||
            this.checkWallCollision(tank.x, tank.y)) {
          // 如果即将碰撞，随机改变方向
          tank.direction = this.getRandomDirection();
        }
      });
    },
    
    // 移动子弹
    moveBullets(deltaTime) {
      const moveDistance = this.bulletSpeed * deltaTime;
      
      this.bullets = this.bullets.filter(bullet => {
        // 根据方向移动子弹
        switch (bullet.direction) {
          case 'up':
            bullet.y -= moveDistance;
            break;
          case 'down':
            bullet.y += moveDistance;
            break;
          case 'left':
            bullet.x -= moveDistance;
            break;
          case 'right':
            bullet.x += moveDistance;
            break;
        }
        
        // 如果子弹超出边界，移除它
        if (bullet.x < 0 || bullet.x > this.boardWidth || 
            bullet.y < 0 || bullet.y > this.boardHeight) {
          return false;
        }
        
        return true;
      });
    },
    
    // 检测碰撞
    checkCollisions() {
      // 检测子弹与墙壁的碰撞
      this.bullets = this.bullets.filter(bullet => {
        const bulletX = Math.floor(bullet.x);
        const bulletY = Math.floor(bullet.y);
        
        // 检查子弹是否击中墙壁
        const hitWall = this.walls.findIndex(wall => 
          Math.abs(wall.x - bulletX) < 0.5 && Math.abs(wall.y - bulletY) < 0.5
        );
        
        if (hitWall !== -1) {
          // 移除被击中的墙壁
          this.walls.splice(hitWall, 1);
          return false; // 移除子弹
        }
        
        return true;
      });
      
      // 检测子弹与坦克的碰撞
      this.bullets = this.bullets.filter(bullet => {
        // 检查子弹是否击中玩家坦克
        if (bullet.owner !== 'player' && this.playerTank &&
            Math.abs(bullet.x - this.playerTank.x) < 0.5 && 
            Math.abs(bullet.y - this.playerTank.y) < 0.5) {
          this.playerLives--;
          
          if (this.playerLives <= 0) {
            this.endGame();
          } else {
            // 重置玩家坦克位置
            this.playerTank.x = Math.floor(this.boardWidth / 2);
            this.playerTank.y = this.boardHeight - 2;
          }
          
          return false; // 移除子弹
        }
        
        // 检查子弹是否击中敌方坦克
        const hitEnemyIndex = this.enemyTanks.findIndex(tank => 
          bullet.owner === 'player' && 
          Math.abs(bullet.x - tank.x) < 0.5 && 
          Math.abs(bullet.y - tank.y) < 0.5
        );
        
        if (hitEnemyIndex !== -1) {
          // 移除被击中的敌方坦克
          this.enemyTanks.splice(hitEnemyIndex, 1);
          this.score += 10;
          this.killCount++;
          return false; // 移除子弹
        }
        
        return true;
      });
    },
    
    // 敌方坦克AI
    updateEnemyAI(deltaTime) {
      this.enemyTanks.forEach(tank => {
        // 随机改变方向
        if (Math.random() < 0.01) {
          tank.direction = this.getRandomDirection();
        }
        
        // 随机发射子弹
        if (Math.random() < 0.02 && tank.canFire) {
          tank.canFire = false;
          this.fireBullet(tank, 'enemy');
          setTimeout(() => {
            tank.canFire = true;
          }, 1000); // 冷却时间
        }
      });
    },
    
    // 发射子弹
    fireBullet(tank, owner) {
      let bulletX = tank.x;
      let bulletY = tank.y;
      
      // 根据坦克方向调整子弹初始位置
      switch (tank.direction) {
        case 'up':
          bulletY -= 0.5;
          break;
        case 'down':
          bulletY += 0.5;
          break;
        case 'left':
          bulletX -= 0.5;
          break;
        case 'right':
          bulletX += 0.5;
          break;
      }
      
      this.bullets.push({
        x: bulletX,
        y: bulletY,
        direction: tank.direction,
        owner: owner
      });
    },
    
    // 生成敌方坦克
    spawnEnemies(count = this.maxEnemies) {
      for (let i = 0; i < count; i++) {
        if (this.enemyTanks.length >= this.maxEnemies) break;
        
        // 随机生成敌方坦克位置
        const x = Math.floor(Math.random() * (this.boardWidth - 2)) + 1;
        
        this.enemyTanks.push({
          x: x,
          y: 1,
          direction: 'down',
          width: 1,
          height: 1,
          canFire: true
        });
      }
    },
    
    // 初始化墙壁
    initWalls() {
      this.walls = [];
      
      // 生成边界墙
      for (let i = 0; i < this.boardWidth; i++) {
        // 上边界
        if (i < 3 || i > this.boardWidth - 4) {
          this.walls.push({ x: i, y: 0 });
        }
        
        // 下边界
        if (i < this.boardWidth / 2 - 2 || i > this.boardWidth / 2 + 1) {
          this.walls.push({ x: i, y: this.boardHeight - 1 });
        }
      }
      
      for (let i = 0; i < this.boardHeight; i++) {
        // 左边界
        if (i > 2) {
          this.walls.push({ x: 0, y: i });
        }
        
        // 右边界
        if (i > 2) {
          this.walls.push({ x: this.boardWidth - 1, y: i });
        }
      }
      
      // 生成随机障碍物
      const obstacleCount = Math.floor(this.boardWidth * this.boardHeight * 0.1);
      for (let i = 0; i < obstacleCount; i++) {
        const x = Math.floor(Math.random() * (this.boardWidth - 2)) + 1;
        const y = Math.floor(Math.random() * (this.boardHeight - 4)) + 2;
        
        // 确保障碍物不会生成在玩家坦克周围和边界
        if (Math.abs(x - this.boardWidth / 2) > 1 || Math.abs(y - (this.boardHeight - 2)) > 1) {
          this.walls.push({ x, y });
        }
      }
    },
    
    // 检查墙壁碰撞
    checkWallCollision(x, y) {
      const roundedX = Math.floor(x);
      const roundedY = Math.floor(y);
      
      return this.walls.some(wall => 
        wall.x === roundedX && wall.y === roundedY
      );
    },
    
    // 获取随机方向
    getRandomDirection() {
      const directions = ['up', 'down', 'left', 'right'];
      return directions[Math.floor(Math.random() * directions.length)];
    },
    
    // 结束游戏
    endGame() {
      if (this.gameStarted) {
        this.gameStarted = false;
        this.gameOver = true;
        cancelAnimationFrame(this.gameLoop);
        
        // 保存游戏记录到排行榜
        this.saveGameRecord();
      }
    },
    
    // 保存游戏记录
    async saveGameRecord() {
      try {
        const gameTime = Math.floor((performance.now() - this.gameStartTime) / 1000);
        await gameApi.saveGameRecord('tank', {
          score: this.score,
          kills: this.killCount || 0,
          level: this.level || 1,
          mode: 'classic',
          duration: gameTime,
          completed: this.gameOver && this.score > 0,
          date: new Date().toISOString().split('T')[0]
        });
        console.log('坦克大战游戏记录保存成功');
      } catch (error) {
        console.error('保存游戏记录失败:', error);
      }
    },
    
    // 处理键盘按下
    handleKeydown(e) {
      // 如果游戏未开始或已暂停，忽略键盘输入
      if (!this.gameStarted || this.gamePaused) return;
      
      switch (e.key) {
        // 上方向
        case 'ArrowUp':
        case 'w':
        case 'W':
          this.keys.up = true;
          break;
        // 下方向
        case 'ArrowDown':
        case 's':
        case 'S':
          this.keys.down = true;
          break;
        // 左方向
        case 'ArrowLeft':
        case 'a':
        case 'A':
          this.keys.left = true;
          break;
        // 右方向
        case 'ArrowRight':
        case 'd':
        case 'D':
          this.keys.right = true;
          break;
        // 发射
        case ' ':
          this.keys.fire = true;
          break;
        // 暂停游戏
        case 'p':
        case 'P':
          if (this.gamePaused) {
            this.resumeGame();
          } else {
            this.pauseGame();
          }
          break;
      }
      
      // 防止方向键滚动页面
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', ' '].includes(e.key)) {
        e.preventDefault();
      }
    },
    
    // 处理键盘抬起
    handleKeyup(e) {
      switch (e.key) {
        case 'ArrowUp':
        case 'w':
        case 'W':
          this.keys.up = false;
          break;
        case 'ArrowDown':
        case 's':
        case 'S':
          this.keys.down = false;
          break;
        case 'ArrowLeft':
        case 'a':
        case 'A':
          this.keys.left = false;
          break;
        case 'ArrowRight':
        case 'd':
        case 'D':
          this.keys.right = false;
          break;
        case ' ':
          this.keys.fire = false;
          break;
      }
    },
    
    // 获取元素的定位样式
    getPositionStyle(x, y, direction) {
      const rotation = {
        'up': 'rotate(0deg)',
        'right': 'rotate(90deg)',
        'down': 'rotate(180deg)',
        'left': 'rotate(270deg)'
      };
      
      return {
        left: x * this.gridSize + 'px',
        top: y * this.gridSize + 'px',
        transform: rotation[direction]
      };
    }
  },
  // 组件卸载时清除游戏循环
  beforeUnmount() {
    if (this.gameLoop) {
      cancelAnimationFrame(this.gameLoop);
    }
    
    // 移除键盘事件监听
    window.removeEventListener('keydown', this.handleKeydown);
    window.removeEventListener('keyup', this.handleKeyup);
  },
  // 组件挂载完成
  mounted() {
    // 添加键盘事件监听
    window.addEventListener('keydown', this.handleKeydown);
    window.addEventListener('keyup', this.handleKeyup);
  }
}
</script>

<style scoped>
.tank-game {
  display: flex;
  flex-direction: column;
  align-items: center;
  font-family: Arial, sans-serif;
  margin: 20px auto;
  max-width: 800px;
}

.game-info {
  text-align: center;
  margin-bottom: 20px;
  width: 100%;
  max-width: 400px;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.score, .lives {
  font-size: 1.2rem;
  font-weight: bold;
  margin: 5px 0;
}

.control-buttons {
  margin: 10px 0;
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

button {
  border: none;
  padding: 10px 16px;
  text-align: center;
  text-decoration: none;
  font-size: 16px;
  cursor: pointer;
  border-radius: 4px;
  transition: background-color 0.3s;
  height: 40px;
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
}

.main-btn {
  background-color: #4caf50;
  color: white;
}

.main-btn:hover {
  background-color: #45a049;
}

.return-btn {
  background-color: #f44336;
  color: white;
  margin-top: 5px;
}

.return-btn:hover {
  background-color: #d32f2f;
}

.game-over {
  color: red;
  font-size: 1.5rem;
  font-weight: bold;
  margin: 10px 0;
}

.game-board {
  position: relative;
  width: calc(var(--grid-size) * var(--board-width));
  height: calc(var(--grid-size) * var(--board-height));
  background-color: #eee;
  border: 2px solid #333;
  overflow: hidden;
  outline: none;
  --grid-size: 30px; /* 对应 this.gridSize */
  --board-width: 20; /* 对应 this.boardWidth */
  --board-height: 15; /* 对应 this.boardHeight */
}

.tank {
  position: absolute;
  width: 30px;
  height: 30px;
  background-size: contain;
  background-repeat: no-repeat;
  background-position: center;
  z-index: 10;
}

.player-tank {
  background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23388e3c"><path d="M12,2L4,9V22H20V9L12,2M15,16H13V18H11V16H9V14H11V12H13V14H15V16Z"/></svg>');
}

.enemy-tank {
  background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23d32f2f"><path d="M12,2L4,9V22H20V9L12,2M15,16H9V14H15V16Z"/></svg>');
}

.bullet {
  position: absolute;
  width: 6px;
  height: 6px;
  background-color: #333;
  border-radius: 50%;
  z-index: 5;
  transform: translate(-50%, -50%);
}

.wall {
  position: absolute;
  background-color: #795548;
  z-index: 2;
}

.instructions {
  margin-top: 20px;
  text-align: center;
}

.instructions h3 {
  margin-bottom: 5px;
}

.instructions p {
  color: #666;
}
</style> 