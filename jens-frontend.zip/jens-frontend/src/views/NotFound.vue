<template>
  <div class="not-found-container">
    <div class="not-found-content">
      <div class="error-code">404</div>
      <h2>页面未找到</h2>
      <p>抱歉，您访问的页面不存在或已被移除</p>
      <div class="astronaut-container">
        <img src="/images/astronaut.svg" alt="太空人" class="astronaut-image" />
      </div>
      <el-button type="primary" @click="goHome" class="home-button">
        <i class="el-icon-back"></i> 返回首页
      </el-button>
    </div>
  </div>
</template>

<script>
import { useRouter } from 'vue-router'

export default {
  name: 'NotFound',
  setup() {
    const router = useRouter()
    
    const goHome = () => {
      router.push('/')
    }
    
    return {
      goHome
    }
  }
}
</script>

<style scoped>
.not-found-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: calc(100vh - 80px);
  background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
  padding: 20px;
  overflow: hidden;
  position: relative;
}

.not-found-container::before {
  content: '';
  position: absolute;
  width: 100%;
  height: 100%;
  background-image: url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M11 18c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm48 25c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm-43-7c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm63 31c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM34 90c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zm56-76c1.657 0 3-1.343 3-3s-1.343-3-3-3-3 1.343-3 3 1.343 3 3 3zM12 86c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm28-65c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm23-11c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-6 60c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm29 22c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zM32 63c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm57-13c2.76 0 5-2.24 5-5s-2.24-5-5-5-5 2.24-5 5 2.24 5 5 5zm-9-21c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM60 91c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM35 41c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2zM12 60c1.105 0 2-.895 2-2s-.895-2-2-2-2 .895-2 2 .895 2 2 2z' fill='%236a11cb' fill-opacity='0.03' fill-rule='evenodd'/%3E%3C/svg%3E");
  z-index: 1;
}

.not-found-content {
  text-align: center;
  padding: 50px;
  background-color: white;
  border-radius: 20px;
  box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
  max-width: 500px;
  width: 100%;
  z-index: 2;
  position: relative;
}

.error-code {
  font-size: 140px;
  font-weight: 800;
  margin: 0;
  background: linear-gradient(90deg, #6a11cb, #2575fc);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  line-height: 1;
  text-shadow: 0 2px 10px rgba(106, 17, 203, 0.2);
  animation: float 4s ease-in-out infinite;
}

h2 {
  font-size: 32px;
  margin: 10px 0 20px;
  color: #303133;
  font-weight: 600;
}

p {
  font-size: 18px;
  margin-bottom: 30px;
  color: #606266;
  line-height: 1.6;
}

.astronaut-container {
  height: 180px;
  margin: 30px 0;
  position: relative;
  display: flex;
  justify-content: center;
}

.astronaut-image {
  height: 100%;
  animation: astronautFloat 10s ease-in-out infinite;
}

.home-button {
  padding: 12px 30px;
  font-size: 16px;
  border-radius: 30px;
  background: linear-gradient(90deg, #6a11cb, #2575fc);
  border: none;
  box-shadow: 0 5px 15px rgba(37, 117, 252, 0.2);
  transition: all 0.3s ease;
}

.home-button:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(37, 117, 252, 0.3);
}

@keyframes float {
  0%, 100% {
    transform: translateY(0px);
  }
  50% {
    transform: translateY(-20px);
  }
}

@keyframes astronautFloat {
  0%, 100% {
    transform: translateY(0px) rotate(5deg);
  }
  50% {
    transform: translateY(-20px) rotate(-5deg);
  }
}

@media (max-width: 576px) {
  .error-code {
    font-size: 100px;
  }
  
  h2 {
    font-size: 24px;
  }
  
  .astronaut-container {
    height: 140px;
  }
  
  .not-found-content {
    padding: 30px;
  }
}
</style> 