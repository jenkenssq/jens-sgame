<template>
  <div class="home">
    <div class="featured-games">
      <h2 class="section-title">热门游戏</h2>
      <el-row :gutter="24">
        <el-col :xs="24" :sm="12" :md="6" v-for="game in featuredGames" :key="game.id">
          <el-card shadow="hover" class="game-card">
            <div class="game-image" :style="{ backgroundImage: `url(${game.image})` }">
              <div class="game-overlay">
                <el-button type="primary" @click="goToGame(game.route)" class="play-button">
                  开始游戏
                </el-button>
              </div>
            </div>
            <div class="game-info">
              <h3>{{ game.name }}</h3>
              <p>{{ game.description }}</p>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Home',
  data() {
    return {
      featuredGames: [
        {
          id: 1,
          name: '推箱子',
          description: '经典益智游戏，考验你的空间思维能力',
          image: '/images/sokoban.svg',
          route: '/games/sokoban'
        },
        {
          id: 2,
          name: '俄罗斯方块',
          description: '风靡全球的俄罗斯方块，挑战你的反应能力',
          image: '/images/tetris.svg',
          route: '/games/tetris'
        },
        {
          id: 3,
          name: '贪吃蛇',
          description: '控制小蛇吃食物，不断成长',
          image: '/images/snake.svg',
          route: '/games/snake'
        },
        {
          id: 4,
          name: '坦克大战',
          description: '经典坦克射击游戏，保卫基地',
          image: '/images/tank.svg',
          route: '/games/tank'
        }
      ]
    }
  },
  methods: {
    goToGameLobby() {
      this.$router.push('/games')
    },
    goToGame(route) {
      this.$router.push(route)
    }
  }
}
</script>

<style scoped>
.home {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.section-title {
  font-size: 2.2rem;
  margin-bottom: 30px;
  text-align: center;
  font-weight: 600;
  position: relative;
  color: #333;
}

.section-title:after {
  content: '';
  position: absolute;
  width: 60px;
  height: 4px;
  background: #2575fc;
  bottom: -10px;
  left: 50%;
  transform: translateX(-50%);
  border-radius: 2px;
}

.featured-games {
  margin-bottom: 60px;
}

.game-card {
  margin-bottom: 30px;
  transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
  border: none;
  overflow: hidden;
  height: 100%;
}

.game-card:hover {
  transform: translateY(-10px);
  box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
}

.game-image {
  height: 200px;
  background-size: cover;
  background-position: center;
  position: relative;
  overflow: hidden;
  border-radius: 8px 8px 0 0;
}

.game-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  opacity: 0;
  transition: all 0.3s ease;
}

.game-card:hover .game-overlay {
  opacity: 1;
}

.play-button {
  padding: 10px 25px;
  font-weight: 600;
}

.game-info {
  padding: 20px;
}

.game-card h3 {
  font-size: 1.3rem;
  margin-bottom: 10px;
  color: #303133;
}

.game-card p {
  margin-bottom: 15px;
  color: #606266;
  line-height: 1.5;
}

@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

@keyframes fadeInDown {
  from {
    opacity: 0;
    transform: translateY(-30px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
</style> 