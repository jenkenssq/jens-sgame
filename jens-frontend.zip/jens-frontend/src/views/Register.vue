<template>
  <div class="register-page">
    <div class="register-container">
      <div class="register-form-container">
        <div class="form-header">
          <h2>用户注册</h2>
          <p>创建您的游戏账户</p>
        </div>
        
        <el-form :model="registerForm" :rules="rules" ref="registerFormRef" class="register-form">
          <el-form-item prop="username">
            <el-input 
              v-model="registerForm.username" 
              placeholder="用户名" 
              prefix-icon="el-icon-user"
              size="large">
            </el-input>
          </el-form-item>
          
          <el-form-item prop="email">
            <el-input 
              v-model="registerForm.email" 
              placeholder="邮箱" 
              prefix-icon="el-icon-message"
              size="large">
            </el-input>
          </el-form-item>
          
          <el-form-item prop="password">
            <el-input 
              v-model="registerForm.password" 
              type="password" 
              placeholder="密码" 
              prefix-icon="el-icon-lock" 
              show-password
              size="large">
            </el-input>
          </el-form-item>
          
          <el-form-item prop="confirmPassword">
            <el-input 
              v-model="registerForm.confirmPassword" 
              type="password" 
              placeholder="确认密码" 
              prefix-icon="el-icon-lock" 
              show-password
              size="large">
            </el-input>
          </el-form-item>
          
          <el-form-item prop="agreement" class="agreement-item">
            <el-checkbox v-model="registerForm.agreement">
              我已阅读并同意<a href="#" class="link">用户协议</a>和<a href="#" class="link">隐私政策</a>
            </el-checkbox>
          </el-form-item>
          
          <el-button 
            type="primary" 
            @click="handleRegister" 
            :loading="loading" 
            class="register-button">
            注册
          </el-button>
          
          <div class="register-footer">
            <p>已有账号？<router-link to="/login" class="login-link">立即登录</router-link></p>
          </div>
        </el-form>
      </div>
      
      <div class="register-banner">
        <div class="banner-content">
          <h2>加入此游戏社区</h2>
          <p>创建账户后，您可以保存游戏进度，参与排行榜竞争，与其他玩家互动！</p>
          <div class="features">
            <div class="feature-item">
              <div class="feature-icon">
                <i class="el-icon-trophy"></i>
              </div>
              <div class="feature-text">
                <h3>排行榜竞争</h3>
                <p>挑战全球玩家，争夺排名</p>
              </div>
            </div>
            <div class="feature-item">
              <div class="feature-icon">
                <i class="el-icon-medal"></i>
              </div>
              <div class="feature-text">
                <h3>成就系统</h3>
                <p>解锁特殊成就，展示游戏技巧</p>
              </div>
            </div>
            <div class="feature-item">
              <div class="feature-icon">
                <i class="el-icon-data-line"></i>
              </div>
              <div class="feature-text">
                <h3>游戏记录</h3>
                <p>查看详细的游戏历史和进度</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, reactive } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import userApi from '../api/user'

export default {
  name: 'Register',
  setup() {
    const router = useRouter()
    const registerFormRef = ref(null)
    const loading = ref(false)
    
    const registerForm = reactive({
      username: '',
      email: '',
      password: '',
      confirmPassword: '',
      agreement: false
    })
    
    // 自定义校验规则：确认密码
    const validatePass2 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请再次输入密码'))
      } else if (value !== registerForm.password) {
        callback(new Error('两次输入密码不一致'))
      } else {
        callback()
      }
    }

    // 自定义校验规则：同意协议
    const validateAgreement = (rule, value, callback) => {
      if (!value) {
        callback(new Error('请阅读并同意用户协议和隐私政策'))
      } else {
        callback()
      }
    }
    
    const rules = {
      username: [
        { required: true, message: '请输入用户名', trigger: 'blur' },
        { min: 3, max: 20, message: '用户名长度应为3-20个字符', trigger: 'blur' }
      ],
      email: [
        { required: true, message: '请输入邮箱', trigger: 'blur' },
        { type: 'email', message: '请输入正确的邮箱格式', trigger: 'blur' }
      ],
      password: [
        { required: true, message: '请输入密码', trigger: 'blur' },
        { min: 6, max: 20, message: '密码长度应为6-20个字符', trigger: 'blur' }
      ],
      confirmPassword: [
        { required: true, message: '请再次输入密码', trigger: 'blur' },
        { validator: validatePass2, trigger: 'blur' }
      ],
      agreement: [
        { validator: validateAgreement, trigger: 'change' }
      ]
    }
    
    const handleRegister = () => {
      registerFormRef.value.validate(async (valid) => {
        if (valid) {
          try {
            loading.value = true
            // 提取注册所需数据
            const { username, email, password } = registerForm
            await userApi.register({ username, email, password })
            
            ElMessage({
              type: 'success',
              message: '注册成功！请登录'
            })
            
            // 注册成功后跳转到登录页
            router.push('/login')
          } catch (error) {
            ElMessage({
              type: 'error',
              message: error.response?.data?.message || '注册失败，请稍后再试'
            })
          } finally {
            loading.value = false
          }
        }
      })
    }
    
    return {
      registerForm,
      registerFormRef,
      rules,
      loading,
      handleRegister
    }
  }
}
</script>

<style scoped>
.register-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #f5f7fa;
  padding: 20px;
}

.register-container {
  width: 100%;
  max-width: 1000px;
  display: flex;
  flex-direction: row-reverse;
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  background-color: #fff;
  min-height: 600px;
}

.register-form-container {
  flex: 1;
  padding: 50px 40px;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

.form-header {
  text-align: center;
  margin-bottom: 30px;
}

.form-header h2 {
  font-size: 1.8rem;
  color: #303133;
  margin-bottom: 10px;
  font-weight: 600;
}

.form-header p {
  color: #909399;
  font-size: 1rem;
}

.register-form {
  max-width: 380px;
  margin: 0 auto;
  width: 100%;
}

:deep(.el-input__inner) {
  height: 50px;
  font-size: 1rem;
}

.agreement-item {
  margin-bottom: 20px;
}

.link {
  color: #2575fc;
  text-decoration: none;
}

.link:hover {
  text-decoration: underline;
}

.register-button {
  width: 100%;
  height: 50px;
  font-size: 1.1rem;
  font-weight: 500;
  border-radius: 8px;
  background: linear-gradient(90deg, #6a11cb, #2575fc);
  border: none;
  margin-bottom: 20px;
  transition: all 0.3s ease;
}

.register-button:hover {
  opacity: 0.9;
  transform: translateY(-2px);
  box-shadow: 0 7px 14px rgba(37, 117, 252, 0.2);
}

.register-footer {
  text-align: center;
  margin-top: 20px;
  font-size: 1rem;
  color: #606266;
}

.login-link {
  color: #2575fc;
  font-weight: 600;
  text-decoration: none;
}

.login-link:hover {
  text-decoration: underline;
}

.register-banner {
  flex: 1;
  background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
  color: white;
  padding: 40px;
  display: flex;
  align-items: center;
  position: relative;
  overflow: hidden;
}

.register-banner::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: url('../assets/pattern.svg') repeat;
  opacity: 0.1;
}

.banner-content {
  position: relative;
  z-index: 2;
}

.banner-content h2 {
  font-size: 2.2rem;
  margin-bottom: 20px;
  font-weight: 700;
}

.banner-content > p {
  font-size: 1.1rem;
  margin-bottom: 40px;
  opacity: 0.9;
  line-height: 1.6;
}

.features {
  display: flex;
  flex-direction: column;
  gap: 25px;
}

.feature-item {
  display: flex;
  align-items: center;
}

.feature-icon {
  width: 50px;
  height: 50px;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 15px;
}

.feature-icon i {
  font-size: 24px;
}

.feature-text h3 {
  font-size: 1.2rem;
  margin-bottom: 5px;
  font-weight: 600;
}

.feature-text p {
  font-size: 0.9rem;
  opacity: 0.9;
}

@media (max-width: 768px) {
  .register-container {
    flex-direction: column-reverse;
  }
  
  .register-banner {
    padding: 30px 20px;
  }
  
  .register-form-container {
    padding: 30px 20px;
  }
  
  .features {
    gap: 15px;
  }
}
</style> 