import { createRouter, createWebHistory } from 'vue-router'
import authService from '../utils/auth'

// 页面组件将按需导入
const Home = () => import('../views/Home.vue')
const GameLobby = () => import('../views/GameLobby.vue')
const Leaderboard = () => import('../views/Leaderboard.vue')
const Login = () => import('../views/Login.vue')
const Register = () => import('../views/Register.vue')
const Profile = () => import('../views/Profile.vue')
const NotFound = () => import('../views/NotFound.vue')

// 游戏组件
const Sokoban = () => import('../views/games/Sokoban.vue')
const Tetris = () => import('../views/games/Tetris.vue')
const Snake = () => import('../views/games/Snake.vue')
const Tank = () => import('../views/games/Tank.vue')

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/games',
    name: 'GameLobby',
    component: GameLobby
  },
  {
    path: '/leaderboard',
    name: 'Leaderboard',
    component: Leaderboard
  },
  {
    path: '/login',
    name: 'Login',
    component: Login
  },
  {
    path: '/register',
    name: 'Register',
    component: Register
  },
  {
    path: '/profile',
    name: 'Profile',
    component: Profile,
    meta: { requiresAuth: true }
  },
  // 游戏路由
  {
    path: '/games/sokoban',
    name: 'Sokoban',
    component: Sokoban
  },
  {
    path: '/games/tetris',
    name: 'Tetris',
    component: Tetris
  },
  {
    path: '/games/snake',
    name: 'Snake',
    component: Snake
  },
  {
    path: '/games/tank',
    name: 'Tank',
    component: Tank
  },
  // 404页面
  {
    path: '/:pathMatch(.*)*',
    name: 'NotFound',
    component: NotFound
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

// 路由守卫
router.beforeEach(async (to, from, next) => {
  console.log(`路由跳转: 从 ${from.path} 到 ${to.path}`)
  const requiresAuth = to.matched.some(record => record.meta.requiresAuth)
  
  // 如果路由需要认证
  if (requiresAuth) {
    console.log(`路由 ${to.path} 需要认证`)
    // 先检查Store中是否已有token
    const token = localStorage.getItem('token')
    if (token) {
      console.log('本地存储中存在token，尝试验证...')
      // 检查认证状态
      try {
        const isAuthenticated = await authService.checkAuth()
        if (isAuthenticated) {
          console.log('认证成功，允许访问')
          next()
        } else {
          console.log('Token验证失败，重定向到登录页')
          next({ 
            path: '/login', 
            query: { redirect: to.fullPath }
          })
        }
      } catch (error) {
        console.error('认证检查出错:', error)
        next({ 
          path: '/login', 
          query: { redirect: to.fullPath }
        })
      }
    } else {
      console.log('本地无token，重定向到登录页')
      next({ 
        path: '/login', 
        query: { redirect: to.fullPath }
      })
    }
  } else {
    // 不需要认证的路由直接通过
    next()
  }
})

export default router 