import http from '../utils/http'

export default {
  // 用户登录
  login(credentials) {
    return http.post('auth/login', credentials)
      .then(response => {
        // 确保返回完整的响应数据
        return {
          access_token: response.access_token,
          user: response.user,
          message: response.message
        }
      })
  },
  
  // 用户注册
  register(userData) {
    return http.post('auth/register', userData)
  },
  
  // 获取用户信息
  getUserInfo() {
    return http.get('users/profile')
  },
  
  // 更新用户信息
  updateUserInfo(userData) {
    // 确保明确指定每个字段，使用后端期望的确切字段名
    const updatePayload = {
      username: userData.username,
      email: userData.email,
      gender: userData.gender
    }
    
    console.log('[API] 发送用户信息更新请求:', JSON.stringify(updatePayload, null, 2))
    
    return http.put('users/profile', updatePayload)
      .then(response => {
        // 确保返回完整的响应数据，特别是用户信息
        console.log('[API] 用户信息更新成功，响应数据:', JSON.stringify(response, null, 2))
        return response
      })
      .catch(error => {
        console.error('[API] 用户信息更新失败:', error.response || error)
        throw error
      })
  },
  
  // 上传用户头像
  uploadAvatar(formData) {
    return http.post('users/avatar', formData, {
      headers: {
        'X-Requested-With': 'XMLHttpRequest'
      }
    })
    .then(response => {
      console.log('[API] 头像上传成功:', response)
      return response
    })
    .catch(error => {
      console.error('[API] 头像上传失败:', error.response || error)
      throw error
    })
  },
  
  // 修改密码
  changePassword(passwordData) {
    return http.put('users/profile', {
      password: passwordData.newPassword,
      old_password: passwordData.oldPassword
    })
  }
} 