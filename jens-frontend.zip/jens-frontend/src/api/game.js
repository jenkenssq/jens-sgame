import http from '../utils/http'

export default {
  // 获取游戏列表 - 修改为获取所有游戏类型
  getGameList() {
    // 因为后端没有此路由，临时返回固定的游戏类型列表
    return Promise.resolve({
      games: [
        { id: 'sokoban', name: '推箱子', icon: 'box' },
        { id: 'tetris', name: '俄罗斯方块', icon: 'tetris' },
        { id: 'snake', name: '贪吃蛇', icon: 'snake' },
        { id: 'tank', name: '坦克大战', icon: 'tank' }
      ]
    })
  },
  
  // 获取特定游戏信息 - 修改为通过前端提供固定数据
  getGameInfo(gameId) {
    // 因为后端没有此路由，临时返回固定的游戏信息
    const gameInfo = {
      sokoban: { id: 'sokoban', name: '推箱子', description: '经典的推箱子游戏', icon: 'box' },
      tetris: { id: 'tetris', name: '俄罗斯方块', description: '经典的俄罗斯方块游戏', icon: 'tetris' },
      snake: { id: 'snake', name: '贪吃蛇', description: '经典的贪吃蛇游戏', icon: 'snake' },
      tank: { id: 'tank', name: '坦克大战', description: '经典的坦克大战游戏', icon: 'tank' }
    }
    return Promise.resolve(gameInfo[gameId] || null)
  },
  
  // 保存游戏记录
  saveGameRecord(gameType, gameData) {
    return http.post('games/records', {
      game_type: gameType,
      ...gameData
    })
  },
  
  // 获取游戏排行榜
  getLeaderboard(gameType, limit = 10, filterType = 'score') {
    console.log(`获取排行榜数据: ${gameType}, 过滤条件: ${filterType}, 限制: ${limit}`)
    return http.get(`games/leaderboard/${gameType}?limit=${limit}&filter=${filterType}`)
  },
  
  // 获取用户游戏记录
  getUserGameRecords(gameType) {
    if (gameType) {
    return http.get(`games/records?game_type=${gameType}`)
    } else {
      // 获取所有游戏记录
      return http.get('games/records')
    }
  },
  
  // 保存游戏设置
  saveGameSettings(gameType, settings) {
    return http.put(`games/settings/${gameType}`, settings)
  },
  
  // 获取游戏设置
  getGameSettings(gameType) {
    return http.get(`games/settings/${gameType}`)
  },
  
  // 保存游戏进度
  saveGameProgress(gameType, progressData) {
    return http.put(`games/progress/${gameType}`, progressData)
  },
  
  // 获取游戏进度
  getGameProgress(gameType) {
    return http.get(`games/progress/${gameType}`)
  },
  
  // 删除游戏进度
  deleteGameProgress(gameType) {
    return http.delete(`games/progress/${gameType}`)
  }
} 