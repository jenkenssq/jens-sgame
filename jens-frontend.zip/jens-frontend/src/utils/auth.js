// 用户认证相关工具函数
import http from './http'
import store from '../store'
import router from '../router'

// Token存储键名
const TOKEN_KEY = 'token'
const USER_KEY = 'user'

export default {
  // 获取token
  getToken() {
    return localStorage.getItem(TOKEN_KEY)
  },
  
  // 保存token和用户信息
  setToken(token, user) {
    localStorage.setItem(TOKEN_KEY, token)
    localStorage.setItem(USER_KEY, JSON.stringify(user))
    
    // 更新store中的状态
    store.commit('SET_TOKEN', token)
    store.commit('SET_USER', user)
  },
  
  // 清除认证信息
  clearAuth() {
    localStorage.removeItem(TOKEN_KEY)
    localStorage.removeItem(USER_KEY)
    
    // 清除store中的状态
    store.commit('SET_TOKEN', null)
    store.commit('SET_USER', null)
  },
  
  // 检查是否已认证
  isAuthenticated() {
    return !!this.getToken()
  },
  
  // 获取当前用户
  getCurrentUser() {
    const userStr = localStorage.getItem(USER_KEY)
    return userStr ? JSON.parse(userStr) : null
  },
  
  // 验证认证状态
  async checkAuth() {
    if (!this.isAuthenticated()) {
      console.log('本地无token，认证检查失败')
      return false
    }
    
    try {
      console.log('开始验证token有效性...')
      // 发送请求验证token有效性
      const res = await http.get('auth/check')
      console.log('token验证成功，用户信息:', res.user)
      // 更新用户信息
      store.commit('SET_USER', res.user)
      return true
    } catch (error) {
      console.error('token验证失败:', error)
      // Token无效，清除认证信息
      this.clearAuth()
      return false
    }
  },
  
  // 处理登录
  async handleLogin(credentials) {
    try {
      const res = await http.post('auth/login', credentials)
      this.setToken(res.access_token, res.user)
      return res
    } catch (error) {
      throw error
    }
  },
  
  // 处理注册
  async handleRegister(userData) {
    try {
      const res = await http.post('auth/register', userData)
      this.setToken(res.access_token, res.user)
      return res
    } catch (error) {
      throw error
    }
  },
  
  // 处理登出
  async handleLogout() {
    try {
      await http.post('auth/logout')
    } catch (error) {
      console.error('登出错误:', error)
    } finally {
      this.clearAuth()
      router.push('/login')
    }
  }
} 