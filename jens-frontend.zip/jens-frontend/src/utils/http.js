import axios from 'axios'
import store from '../store'
import router from '../router'

// 创建axios实例
const http = axios.create({
  baseURL: process.env.VUE_APP_API_URL || 'http://localhost:5000/api',
  timeout: 30000, // 增加超时时间到30秒，处理大型请求
  maxContentLength: 10 * 1024 * 1024, // 设置最大请求体大小为10MB
  withCredentials: false // 默认不发送凭据
})

// 请求拦截器
http.interceptors.request.use(
  config => {
    // 添加token到请求头
    const token = store.state.token
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
      console.log(`发送请求: ${config.method.toUpperCase()} ${config.url}，已附加认证Token`)
    } else {
      console.log(`发送请求: ${config.method.toUpperCase()} ${config.url}，无认证Token`)
    }
    
    // 确保PUT和POST请求的Content-Type正确，但不覆盖已设置的Content-Type
    if ((config.method === 'put' || config.method === 'post') && !config.headers['Content-Type']) {
      config.headers['Content-Type'] = 'application/json'
    }
    
    // 如果是文件上传，不要转换FormData对象
    if (config.data instanceof FormData) {
      console.log(`[HTTP] 检测到FormData请求，正在处理文件上传: ${config.url}`)
      // 对于FormData，不要修改Content-Type，让浏览器自动设置，包含boundary
      delete config.headers['Content-Type'];
    } else if (config.method === 'put' || config.method === 'post') {
      // 调试日志，记录请求体内容
      console.log(`[HTTP] ${config.method.toUpperCase()} 请求体:`, JSON.stringify(config.data, null, 2))
    }
    
    // 记录大型请求的大小
    if (config.data && typeof config.data === 'object' && !(config.data instanceof FormData)) {
      const size = JSON.stringify(config.data).length
      if (size > 100 * 1024) { // 如果请求大于100KB，记录日志
        console.warn(`警告: 发送大型请求 (${Math.round(size / 1024)}KB) 到 ${config.url}`)
      }
    }
    
    return config
  },
  error => {
    console.error('请求错误:', error)
    return Promise.reject(error)
  }
)

// 响应拦截器
http.interceptors.response.use(
  response => {
    console.log(`接收响应: ${response.config.url}`, response.data)
    return response.data
  },
  error => {
    // 处理错误响应
    if (error.response) {
      // 服务器返回错误
      console.error(`API响应错误 ${error.response.status}:`, error.response.data)
      
      // 尝试提取错误信息
      let errorMessage = '服务器错误'
      try {
        if (error.response.data && error.response.data.error) {
          errorMessage = error.response.data.error
        } else if (error.response.data && error.response.data.message) {
          errorMessage = error.response.data.message
        } else if (typeof error.response.data === 'string' && error.response.data.trim()) {
          // 如果是HTML错误页面，提取简短信息
          if (error.response.data.includes('<!doctype html>') || error.response.data.includes('<html>')) {
            errorMessage = '服务器内部错误，请联系管理员'
          } else {
            errorMessage = error.response.data.substring(0, 100) // 截取前100个字符
          }
        }
      } catch (e) {
        console.error('解析错误响应失败:', e)
      }
      
      // 根据状态码处理
      switch (error.response.status) {
        case 401:
          // 未授权，清除token并跳转到登录页
          console.warn('未授权访问，清除认证信息')
          store.dispatch('logout')
          router.push('/login')
          break
        case 403:
          // 权限不足
          console.warn('权限不足，跳转到禁止访问页面')
          router.push('/forbidden')
          break
        case 404:
          // 资源不存在
          console.warn('请求的资源不存在')
          router.push('/not-found')
          break
        case 500:
          // 服务器内部错误
          console.error('服务器内部错误:', errorMessage)
          break
        default:
          console.error('API请求错误:', errorMessage)
      }
      
      // 将错误信息附加到错误对象上
      error.message = errorMessage
    } else if (error.request) {
      // 请求已发出，但未收到响应
      console.error('没有收到响应:', error.request)
      error.message = '服务器无响应，请检查网络连接'
    } else {
      // 请求未发出或网络错误
      console.error('网络错误:', error.message)
    }
    return Promise.reject(error)
  }
)

export default http 