<!-- 游戏渲染组件 -->
<template>
  <div class="game-canvas-container">
    <canvas 
      ref="gameCanvas" 
      :width="width" 
      :height="height" 
      @mousemove="onMouseMove"
      @click="onClick">
    </canvas>
  </div>
</template>

<script>
export default {
  name: 'GameCanvas',
  props: {
    // 画布宽度
    width: {
      type: Number,
      default: 400
    },
    // 画布高度
    height: {
      type: Number,
      default: 400
    },
    // 渲染函数
    renderFunction: {
      type: Function,
      required: true
    },
    // 鼠标移动处理函数
    onMouseMoveHandler: {
      type: Function,
      default: null
    },
    // 点击处理函数
    onClickHandler: {
      type: Function,
      default: null
    },
    // 是否使用双缓冲
    useDoubleBuffering: {
      type: Boolean,
      default: true
    },
    // 是否使用离屏渲染
    useOffscreenCanvas: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      canvas: null,
      ctx: null,
      offscreenCanvas: null,
      offscreenCtx: null,
      frameId: null,
      lastFrameTime: 0,
      fps: 0,
      renderCount: 0,
      needsRender: true
    }
  },
  mounted() {
    this.initCanvas()
    this.startRenderLoop()
    
    // 监听窗口大小变化，以适应不同设备
    window.addEventListener('resize', this.handleResize)
  },
  beforeUnmount() {
    this.stopRenderLoop()
    window.removeEventListener('resize', this.handleResize)
  },
  methods: {
    // 初始化画布
    initCanvas() {
      this.canvas = this.$refs.gameCanvas
      this.ctx = this.canvas.getContext('2d')
      
      // 如果使用离屏渲染，创建离屏画布
      if (this.useOffscreenCanvas) {
        // 使用OffscreenCanvas API如果浏览器支持
        if (typeof OffscreenCanvas !== 'undefined') {
          this.offscreenCanvas = new OffscreenCanvas(this.width, this.height)
        } else {
          // 降级方案：创建普通canvas作为离屏缓冲区
          this.offscreenCanvas = document.createElement('canvas')
          this.offscreenCanvas.width = this.width
          this.offscreenCanvas.height = this.height
        }
        this.offscreenCtx = this.offscreenCanvas.getContext('2d')
      }
      
      this.needsRender = true
    },
    
    // 渲染循环
    startRenderLoop() {
      const renderFrame = (timestamp) => {
        // 计算FPS
        if (this.lastFrameTime) {
          this.fps = 1000 / (timestamp - this.lastFrameTime)
        }
        this.lastFrameTime = timestamp
        
        // 只有在需要时才重绘
        if (this.needsRender) {
          this.render()
          this.renderCount++
          this.needsRender = false
        }
        
        this.frameId = requestAnimationFrame(renderFrame)
      }
      
      this.frameId = requestAnimationFrame(renderFrame)
    },
    
    // 停止渲染循环
    stopRenderLoop() {
      if (this.frameId) {
        cancelAnimationFrame(this.frameId)
        this.frameId = null
      }
    },
    
    // 渲染方法
    render() {
      if (this.useOffscreenCanvas) {
        // 在离屏Canvas上绘制
        this.renderFunction(this.offscreenCtx, this.offscreenCanvas.width, this.offscreenCanvas.height)
        
        // 将离屏Canvas的内容复制到主Canvas
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height)
        this.ctx.drawImage(this.offscreenCanvas, 0, 0)
      } else {
        // 直接在主Canvas上绘制
        this.renderFunction(this.ctx, this.canvas.width, this.canvas.height)
      }
    },
    
    // 请求重新渲染
    requestRender() {
      this.needsRender = true
    },
    
    // 处理窗口大小变化
    handleResize() {
      // 如果需要响应式大小，可以在这里调整canvas尺寸
      this.requestRender()
    },
    
    // 鼠标移动事件处理
    onMouseMove(event) {
      if (this.onMouseMoveHandler) {
        const rect = this.canvas.getBoundingClientRect()
        const x = event.clientX - rect.left
        const y = event.clientY - rect.top
        this.onMouseMoveHandler(x, y, event)
        this.requestRender()
      }
    },
    
    // 点击事件处理
    onClick(event) {
      if (this.onClickHandler) {
        const rect = this.canvas.getBoundingClientRect()
        const x = event.clientX - rect.left
        const y = event.clientY - rect.top
        this.onClickHandler(x, y, event)
        this.requestRender()
      }
    },
    
    // 获取渲染性能数据
    getPerformanceStats() {
      return {
        fps: Math.round(this.fps),
        renderCount: this.renderCount
      }
    }
  }
}
</script>

<style scoped>
.game-canvas-container {
  position: relative;
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}

canvas {
  max-width: 100%;
  max-height: 100%;
  display: block;
  background-color: #f0f0f0;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}
</style> 