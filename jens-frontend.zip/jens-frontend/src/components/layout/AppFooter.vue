<template>
  <div class="app-footer">
    <p>&copy; {{ currentYear }} JENS游戏合集 | 基于Flask+Vue+MySQL开发</p>
  </div>
</template>

<script>
export default {
  name: 'AppFooter',
  computed: {
    currentYear() {
      return new Date().getFullYear()
    }
  }
}
</script>

<style scoped>
.app-footer {
  background-color: #545c64;
  color: #fff;
  text-align: center;
  padding: 15px 0;
}
</style> 