<template>
  <div class="app-header">
    <div class="header-container">
      <!-- 导航菜单部分 -->
      <div class="nav-section">
        <div class="logo">JENS游戏合集</div>
        <router-link to="/" class="nav-link" :class="{ active: activeIndex === '/' }">首页</router-link>
        <router-link to="/games" class="nav-link" :class="{ active: activeIndex === '/games' }">游戏大厅</router-link>
        <router-link to="/leaderboard" class="nav-link" :class="{ active: activeIndex === '/leaderboard' }">排行榜</router-link>
      </div>
      
      <!-- 身份验证按钮部分 -->
      <div class="auth-buttons">
        <template v-if="isLoggedIn">
          <button class="profile-btn" @click="goToProfile">个人中心</button>
          <button class="logout-btn" @click="logout">退出</button>
        </template>
        <template v-else>
          <button class="login-btn" @click="goToLogin">登录</button>
          <button class="register-btn" @click="goToRegister">注册</button>
        </template>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
  name: 'AppHeader',
  data() {
    return {
      activeIndex: '/',
    }
  },
  computed: {
    ...mapGetters(['isLoggedIn', 'currentUser'])
  },
  created() {
    this.activeIndex = this.$route.path
  },
  watch: {
    $route(to) {
      this.activeIndex = to.path
    }
  },
  methods: {
    goToLogin() {
      this.$router.push('/login')
    },
    goToRegister() {
      this.$router.push('/register')
    },
    logout() {
      this.$store.dispatch('logout')
      this.$router.push('/')
    },
    goToProfile() {
      this.$router.push('/profile')
    }
  }
}
</script>

<style scoped>
.app-header {
  background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
  position: relative;
  z-index: 100;
  padding: 0 15px;
}

.header-container {
  max-width: 1200px;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
  align-items: center;
  height: 70px;
}

.nav-section {
  display: flex;
  align-items: center;
}

.logo {
  color: #fff;
  font-size: 20px;
  font-weight: 700;
  margin-right: 20px;
  letter-spacing: 0.5px;
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
}

.nav-link {
  color: #fff;
  text-decoration: none;
  font-size: 16px;
  font-weight: 500;
  letter-spacing: 0.5px;
  padding: 0 20px;
  height: 70px;
  line-height: 70px;
  position: relative;
  transition: all 0.3s ease;
}

.nav-link:hover {
  background-color: rgba(255, 255, 255, 0.15);
  transform: translateY(-2px);
}

.nav-link.active {
  background-color: rgba(255, 255, 255, 0.1);
  font-weight: 600;
}

.nav-link.active:after {
  content: '';
  position: absolute;
  bottom: 10px;
  left: 50%;
  transform: translateX(-50%);
  width: 20px;
  height: 3px;
  background-color: #ffffff;
  border-radius: 2px;
}

.auth-buttons {
  display: flex;
  align-items: center;
}

.login-btn, .register-btn, .profile-btn, .logout-btn {
  border-radius: 20px;
  margin: 0 5px;
  font-weight: 600;
  transition: all 0.3s ease;
  height: 36px;
  padding: 0 20px;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
  border: none;
  cursor: pointer;
}

.login-btn {
  background-color: transparent;
  border: 1.5px solid #ffffff;
  color: #ffffff;
}

.register-btn {
  margin-right: 5px;
  background-color: #ffffff;
  border: 1.5px solid #ffffff;
  color: #6a11cb;
}

.profile-btn, .logout-btn {
  background-color: transparent;
  border: 1.5px solid rgba(255, 255, 255, 0.4);
  color: #ffffff;
}

.login-btn:hover, .profile-btn:hover, .logout-btn:hover {
  background-color: rgba(255, 255, 255, 0.2);
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
}

.register-btn:hover {
  background-color: rgba(255, 255, 255, 0.9);
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
}

/* 响应式调整 */
@media (max-width: 768px) {
  .nav-link {
    padding: 0 12px;
    font-size: 14px;
  }
  
  .login-btn, .register-btn, .profile-btn, .logout-btn {
    padding: 0 15px;
  }
}

@media (max-width: 576px) {
  .nav-link {
    padding: 0 8px;
    font-size: 13px;
  }
  
  .login-btn, .register-btn, .profile-btn, .logout-btn {
    padding: 0 10px;
    font-size: 13px;
  }
}
</style> 