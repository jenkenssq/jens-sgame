<!-- 游戏基础组件 -->
<template>
  <div class="game-container">
    <!-- 加载中提示 -->
    <div v-if="loading" class="game-loading">
      <div class="spinner"></div>
      <p>加载中...</p>
    </div>
    
    <!-- 错误提示 -->
    <div v-if="error" class="game-error">
      <div class="error-icon">!</div>
      <p>{{ error }}</p>
      <button @click="resetError" class="btn btn-primary">重试</button>
    </div>
    
    <!-- 游戏内容插槽 -->
    <slot v-if="!loading && !error"></slot>
    
    <!-- 游戏控制区域 -->
    <div v-if="!loading && !error" class="game-controls">
      <slot name="controls"></slot>
      
      <!-- 默认控制按钮 -->
      <button v-if="canSave" @click="saveGame" class="btn btn-primary">
        保存游戏
      </button>
      <button v-if="canReset" @click="confirmReset" class="btn btn-danger">
        重置游戏
      </button>
    </div>
  </div>
</template>

<script>
import { mapActions } from 'vuex'
import authService from '../utils/auth'

export default {
  name: 'GameBase',
  props: {
    // 游戏类型
    gameType: {
      type: String,
      required: true,
      validator: value => ['sokoban', 'tetris', 'tank', 'snake'].includes(value)
    },
    // 当前游戏状态
    gameState: {
      type: Object,
      default: () => ({})
    },
    // 当前关卡
    level: {
      type: Number,
      default: 1
    },
    // 是否可以保存
    canSave: {
      type: Boolean,
      default: true
    },
    // 是否可以重置
    canReset: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      loading: false,
      error: null,
      localGameState: null
    }
  },
  computed: {
    // 是否已登录
    isLoggedIn() {
      return authService.isAuthenticated()
    },
    // 当前用户
    currentUser() {
      return authService.getCurrentUser()
    }
  },
  methods: {
    ...mapActions([
      'saveGameProgress',
      'loadGameProgress',
      'saveGameRecord',
      'saveGameSettings'
    ]),
    
    // 重置错误状态
    resetError() {
      this.error = null
      this.init()
    },
    
    // 初始化游戏
    async init() {
      this.loading = true
      this.error = null
      
      try {
        // 如果已登录，尝试加载保存的游戏进度
        if (this.isLoggedIn) {
          await this.loadSavedGame()
        }
        
        // 初始化完成后发出事件
        this.$emit('game-initialized')
      } catch (error) {
        console.error('游戏初始化失败:', error)
        this.error = '游戏初始化失败，请刷新页面重试'
      } finally {
        this.loading = false
      }
    },
    
    // 加载保存的游戏
    async loadSavedGame() {
      try {
        const progress = await this.loadGameProgress(this.gameType)
        
        if (progress && progress.game_state) {
          // 发出加载游戏事件
          this.$emit('load-game', {
            gameState: progress.game_state,
            level: progress.level
          })
          return true
        }
      } catch (error) {
        console.warn('加载游戏进度失败:', error)
        // 非致命错误，继续初始化
      }
      return false
    },
    
    // 保存游戏
    async saveGame() {
      if (!this.isLoggedIn) {
        this.$router.push('/login?redirect=' + this.$route.fullPath)
        return
      }
      
      this.loading = true
      
      try {
        // 发出保存前事件，获取最新游戏状态
        this.$emit('before-save')
        
        // 保存游戏进度
        await this.saveGameProgress({
          gameType: this.gameType,
          level: this.level,
          gameState: this.gameState
        })
        
        // 发出保存成功事件
        this.$emit('save-success')
      } catch (error) {
        console.error('保存游戏失败:', error)
        this.error = '保存游戏失败，请重试'
        
        // 发出保存失败事件
        this.$emit('save-error', error)
      } finally {
        this.loading = false
      }
    },
    
    // 确认重置游戏
    confirmReset() {
      if (confirm('确定要重置游戏吗？当前进度将丢失！')) {
        this.resetGame()
      }
    },
    
    // 重置游戏
    resetGame() {
      // 发出重置事件
      this.$emit('reset-game')
    },
    
    // 保存游戏记录（得分等）
    async saveRecord(recordData) {
      if (!this.isLoggedIn) {
        return false
      }
      
      try {
        await this.saveGameRecord({
          gameType: this.gameType,
          gameData: recordData
        })
        return true
      } catch (error) {
        console.error('保存游戏记录失败:', error)
        return false
      }
    },
    
    // 保存游戏设置
    async saveSettings(settings) {
      if (!this.isLoggedIn) {
        return false
      }
      
      try {
        await this.saveGameSettings({
          gameType: this.gameType,
          settings
        })
        return true
      } catch (error) {
        console.error('保存游戏设置失败:', error)
        return false
      }
    }
  },
  created() {
    this.init()
  }
}
</script>

<style scoped>
.game-container {
  position: relative;
  width: 100%;
  height: 100%;
  min-height: 400px;
  display: flex;
  flex-direction: column;
}

.game-loading {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background-color: rgba(0, 0, 0, 0.7);
  color: white;
  z-index: 10;
}

.spinner {
  width: 50px;
  height: 50px;
  border: 5px solid rgba(255, 255, 255, 0.3);
  border-radius: 50%;
  border-top-color: white;
  animation: spin 1s ease-in-out infinite;
  margin-bottom: 20px;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

.game-error {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background-color: rgba(220, 53, 69, 0.9);
  color: white;
  z-index: 10;
  padding: 20px;
  text-align: center;
}

.error-icon {
  font-size: 48px;
  font-weight: bold;
  width: 70px;
  height: 70px;
  border-radius: 50%;
  border: 3px solid white;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 20px;
}

.game-controls {
  margin-top: 20px;
  display: flex;
  justify-content: center;
  gap: 10px;
}

.btn {
  padding: 8px 16px;
  border-radius: 4px;
  font-weight: bold;
  cursor: pointer;
  border: none;
  transition: all 0.2s;
}

.btn-primary {
  background-color: #007bff;
  color: white;
}

.btn-primary:hover {
  background-color: #0069d9;
}

.btn-danger {
  background-color: #dc3545;
  color: white;
}

.btn-danger:hover {
  background-color: #c82333;
}
</style> 