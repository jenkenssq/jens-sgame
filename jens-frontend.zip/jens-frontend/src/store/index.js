import { createStore } from 'vuex'
import gameAPI from '../api/game'

export default createStore({
  state: {
    user: JSON.parse(localStorage.getItem('user')) || null,
    token: localStorage.getItem('token') || null,
    gameSettings: {},
    gameProgress: {},
    loading: false,
    error: null
  },
  getters: {
    isLoggedIn: state => !!state.token,
    currentUser: state => state.user,
    getGameSettings: state => (gameType) => state.gameSettings[gameType] || {},
    getGameProgress: state => (gameType) => state.gameProgress[gameType] || null,
    isLoading: state => state.loading,
    hasError: state => state.error
  },
  mutations: {
    SET_TOKEN(state, token) {
      state.token = token
    },
    SET_USER(state, user) {
      if (user) {
        // 确保用户对象包含所有必要字段
        const updatedUser = {
          ...(state.user || {}),  // 保留现有用户信息
          ...user,  // 覆盖更新的字段
          // 确保username和email字段一定会更新
          username: user.username || (state.user ? state.user.username : ''),
          email: user.email || (state.user ? state.user.email : '')
        }
        
        state.user = updatedUser
        localStorage.setItem('user', JSON.stringify(updatedUser))
        console.log('[Store] 用户信息已更新:', updatedUser)
      } else {
        state.user = null
        localStorage.removeItem('user')
        console.log('[Store] 用户信息已清除')
      }
    },
    SET_GAME_SETTINGS(state, { gameType, settings }) {
      state.gameSettings = {
        ...state.gameSettings,
        [gameType]: settings
      }
    },
    SET_GAME_PROGRESS(state, { gameType, progress }) {
      state.gameProgress = {
        ...state.gameProgress,
        [gameType]: progress
      }
    },
    SET_LOADING(state, status) {
      state.loading = status
    },
    SET_ERROR(state, error) {
      state.error = error
    },
    CLEAR_ERROR(state) {
      state.error = null
    }
  },
  actions: {
    // 登录
    login({ commit }, { token, user }) {
      // 存储到Vuex状态
      commit('SET_TOKEN', token)
      commit('SET_USER', user)
      
      // 存储到本地存储以便持久化
      localStorage.setItem('token', token)
      localStorage.setItem('user', JSON.stringify(user))
      
      // 确保状态已更新
      console.log('Vuex状态已更新:', { token, user })
    },
    
    // 登出
    logout({ commit }) {
      // 清除Vuex状态
      commit('SET_TOKEN', null)
      commit('SET_USER', null)
      
      // 清除本地存储
      localStorage.removeItem('token')
      localStorage.removeItem('user')
      
      console.log('用户已登出，状态已清除')
    },
    
    // 加载游戏设置
    async loadGameSettings({ commit }, gameType) {
      commit('SET_LOADING', true)
      commit('CLEAR_ERROR')
      
      try {
        const settings = await gameAPI.getGameSettings(gameType)
        commit('SET_GAME_SETTINGS', { gameType, settings: settings.settings })
        return settings
      } catch (error) {
        commit('SET_ERROR', `加载游戏设置失败: ${error.message}`)
        console.error('加载游戏设置失败:', error)
        throw error
      } finally {
        commit('SET_LOADING', false)
      }
    },
    
    // 保存游戏设置
    async saveGameSettings({ commit }, { gameType, settings }) {
      commit('SET_LOADING', true)
      commit('CLEAR_ERROR')
      
      try {
        await gameAPI.saveGameSettings(gameType, { settings })
        commit('SET_GAME_SETTINGS', { gameType, settings })
        return settings
      } catch (error) {
        commit('SET_ERROR', `保存游戏设置失败: ${error.message}`)
        console.error('保存游戏设置失败:', error)
        throw error
      } finally {
        commit('SET_LOADING', false)
      }
    },
    
    // 加载游戏进度
    async loadGameProgress({ commit }, gameType) {
      commit('SET_LOADING', true)
      commit('CLEAR_ERROR')
      
      try {
        const progress = await gameAPI.getGameProgress(gameType)
        commit('SET_GAME_PROGRESS', { gameType, progress: progress.game_state })
        return progress
      } catch (error) {
        commit('SET_ERROR', `加载游戏进度失败: ${error.message}`)
        console.error('加载游戏进度失败:', error)
        // 非致命错误，不抛出
        return null
      } finally {
        commit('SET_LOADING', false)
      }
    },
    
    // 保存游戏进度
    async saveGameProgress({ commit }, { gameType, level, gameState }) {
      commit('SET_LOADING', true)
      commit('CLEAR_ERROR')
      
      try {
        const data = { level, game_state: gameState }
        await gameAPI.saveGameProgress(gameType, data)
        commit('SET_GAME_PROGRESS', { gameType, progress: gameState })
        return data
      } catch (error) {
        commit('SET_ERROR', `保存游戏进度失败: ${error.message}`)
        console.error('保存游戏进度失败:', error)
        throw error
      } finally {
        commit('SET_LOADING', false)
      }
    },
    
    // 保存游戏记录
    async saveGameRecord({ commit }, { gameType, gameData }) {
      commit('SET_LOADING', true)
      commit('CLEAR_ERROR')
      
      try {
        const result = await gameAPI.saveGameRecord(gameType, gameData)
        return result
      } catch (error) {
        commit('SET_ERROR', `保存游戏记录失败: ${error.message}`)
        console.error('保存游戏记录失败:', error)
        throw error
      } finally {
        commit('SET_LOADING', false)
      }
    }
  },
  modules: {
    // 可以按需添加模块
  }
}) 