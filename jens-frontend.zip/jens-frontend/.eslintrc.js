module.exports = {
  root: true,
  env: {
    node: true,
    browser: true
  },
  extends: [
    'plugin:vue/vue3-essential',
    'eslint:recommended'
  ],
  parserOptions: {
    parser: '@babel/eslint-parser',
    ecmaVersion: 2020,
    requireConfigFile: false
  },
  rules: {
    'no-console': process.env.NODE_ENV === 'production' ? 'warn' : 'off',
    'no-debugger': process.env.NODE_ENV === 'production' ? 'warn' : 'off',
    // 放宽某些规则以避免过多警告
    'vue/no-unused-components': 'warn',
    'no-unused-vars': 'warn',
    'vue/multi-word-component-names': 'warn',
    'no-useless-catch': 'off', // 禁用无用的try/catch检查
    'vue/no-use-v-if-with-v-for': 'off' // 禁用v-if与v-for一起使用的检查
  }
}