# JENS游戏合集 API参考文档

该文档描述了JENS游戏合集后端提供的所有API接口。

## 基本信息

- 基础URL: `http://localhost:5000/api`
- 所有POST和PUT请求都应该发送JSON格式的请求体
- 认证使用JWT令牌，应在请求头中设置`Authorization: Bearer <token>`
- 所有响应都是JSON格式

## 认证API

### 注册用户

- **URL**: `/auth/register`
- **方法**: `POST`
- **描述**: 注册新用户
- **请求体**:
  ```json
  {
    "username": "用户名",
    "password": "密码",
    "email": "邮箱（可选）"
  }
  ```
- **成功响应 (201)**:
  ```json
  {
    "message": "注册成功",
    "access_token": "JWT令牌",
    "user": {
      "id": 1,
      "username": "用户名",
      "email": "邮箱",
      "avatar": null,
      "created_at": "2025-05-18 10:00:00",
      "last_login": null,
      "is_active": true
    }
  }
  ```
- **错误响应**:
  - `400`: 无效请求数据或缺少必填字段
  - `409`: 用户名或邮箱已被使用

### 用户登录

- **URL**: `/auth/login`
- **方法**: `POST`
- **描述**: 用户登录并获取令牌
- **请求体**:
  ```json
  {
    "username": "用户名",
    "password": "密码"
  }
  ```
- **成功响应 (200)**:
  ```json
  {
    "message": "登录成功",
    "access_token": "JWT令牌",
    "user": {
      "id": 1,
      "username": "用户名",
      "email": "邮箱",
      "avatar": null,
      "created_at": "2025-05-18 10:00:00",
      "last_login": "2025-05-18 10:30:00",
      "is_active": true
    }
  }
  ```
- **错误响应**:
  - `400`: 无效请求数据或缺少必填字段
  - `401`: 用户名或密码错误
  - `403`: 账号已禁用

### 用户登出

- **URL**: `/auth/logout`
- **方法**: `POST`
- **描述**: 用户登出（客户端应删除JWT令牌）
- **需要认证**: 是
- **成功响应 (200)**:
  ```json
  {
    "message": "成功登出"
  }
  ```

### 检查认证状态

- **URL**: `/auth/check`
- **方法**: `GET`
- **描述**: 检查JWT令牌是否有效
- **需要认证**: 是
- **成功响应 (200)**:
  ```json
  {
    "message": "已认证",
    "user": {
      "id": 1,
      "username": "用户名",
      "email": "邮箱",
      "avatar": null,
      "created_at": "2025-05-18 10:00:00",
      "last_login": "2025-05-18 10:30:00",
      "is_active": true
    }
  }
  ```
- **错误响应**:
  - `401`: 未认证（无效令牌）
  - `403`: 账号已禁用
  - `404`: 用户不存在

## 用户API

### 获取用户信息

- **URL**: `/users/profile`
- **方法**: `GET`
- **描述**: 获取当前用户信息
- **需要认证**: 是
- **成功响应 (200)**:
  ```json
  {
    "id": 1,
    "username": "用户名",
    "email": "邮箱",
    "avatar": null,
    "created_at": "2025-05-18 10:00:00",
    "last_login": "2025-05-18 10:30:00",
    "is_active": true
  }
  ```
- **错误响应**:
  - `401`: 未认证
  - `404`: 用户不存在

### 更新用户信息

- **URL**: `/users/profile`
- **方法**: `PUT`
- **描述**: 更新当前用户信息
- **需要认证**: 是
- **请求体**:
  ```json
  {
    "email": "新邮箱",
    "avatar": "头像URL",
    "password": "新密码",
    "old_password": "旧密码"
  }
  ```
  注：更新密码时需同时提供old_password和password
- **成功响应 (200)**:
  ```json
  {
    "message": "用户信息更新成功",
    "user": {
      "id": 1,
      "username": "用户名",
      "email": "新邮箱",
      "avatar": "头像URL",
      "created_at": "2025-05-18 10:00:00",
      "last_login": "2025-05-18 10:30:00",
      "is_active": true
    }
  }
  ```
- **错误响应**:
  - `400`: 旧密码错误
  - `401`: 未认证
  - `404`: 用户不存在
  - `409`: 邮箱已被使用

### 删除用户账号

- **URL**: `/users/profile`
- **方法**: `DELETE`
- **描述**: 删除当前用户账号
- **需要认证**: 是
- **成功响应 (200)**:
  ```json
  {
    "message": "账号已删除"
  }
  ```
- **错误响应**:
  - `401`: 未认证
  - `404`: 用户不存在

## 游戏API

### 获取游戏记录

- **URL**: `/games/records`
- **方法**: `GET`
- **描述**: 获取当前用户的游戏记录
- **需要认证**: 是
- **查询参数**:
  - `game_type`: 游戏类型 (可选，sokoban/tetris/tank/snake)
  - `limit`: 返回记录的最大数量 (可选，默认10)
- **成功响应 (200)**:
  ```json
  [
    {
      "id": 1,
      "user_id": 1,
      "game_type": "tetris",
      "score": 1000,
      "level": 10,
      "duration": 300,
      "completed": true,
      "created_at": "2025-05-18 12:00:00"
    },
    {
      "id": 2,
      "user_id": 1,
      "game_type": "snake",
      "score": 500,
      "level": 5,
      "duration": 180,
      "completed": false,
      "created_at": "2025-05-18 13:00:00"
    }
  ]
  ```

### 保存游戏记录

- **URL**: `/games/records`
- **方法**: `POST`
- **描述**: 保存游戏记录
- **需要认证**: 是
- **请求体**:
  ```json
  {
    "game_type": "tetris",
    "score": 1500,
    "level": 15,
    "duration": 450,
    "completed": true
  }
  ```
  注：game_type和score字段是必填的
- **成功响应 (201)**:
  ```json
  {
    "message": "游戏记录保存成功",
    "record": {
      "id": 3,
      "user_id": 1,
      "game_type": "tetris",
      "score": 1500,
      "level": 15,
      "duration": 450,
      "completed": true,
      "created_at": "2025-05-18 14:00:00"
    }
  }
  ```
- **错误响应**:
  - `400`: 无效请求数据或缺少必填字段
  - `401`: 未认证

### 获取游戏设置

- **URL**: `/games/settings/{game_type}`
- **方法**: `GET`
- **描述**: 获取用户的游戏设置
- **需要认证**: 是
- **URL参数**:
  - `game_type`: 游戏类型 (sokoban/tetris/tank/snake)
- **成功响应 (200)**:
  ```json
  {
    "settings": {
      "soundEnabled": true,
      "musicEnabled": false,
      "difficulty": "medium"
    }
  }
  ```
  注：如果没有设置，返回空对象 `{"settings": {}}`
- **错误响应**:
  - `400`: 无效的游戏类型
  - `401`: 未认证

### 更新游戏设置

- **URL**: `/games/settings/{game_type}`
- **方法**: `PUT`
- **描述**: 更新用户的游戏设置
- **需要认证**: 是
- **URL参数**:
  - `game_type`: 游戏类型 (sokoban/tetris/tank/snake)
- **请求体**:
  任意JSON对象，例如：
  ```json
  {
    "soundEnabled": true,
    "musicEnabled": false,
    "difficulty": "hard"
  }
  ```
- **成功响应 (200)**:
  ```json
  {
    "message": "游戏设置已更新",
    "settings": {
      "soundEnabled": true,
      "musicEnabled": false,
      "difficulty": "hard"
    }
  }
  ```
- **错误响应**:
  - `400`: 无效的游戏类型或请求数据
  - `401`: 未认证

### 获取游戏进度

- **URL**: `/games/progress/{game_type}`
- **方法**: `GET`
- **描述**: 获取用户的游戏进度
- **需要认证**: 是
- **URL参数**:
  - `game_type`: 游戏类型 (sokoban/tetris/tank/snake)
- **成功响应 (200)**:
  ```json
  {
    "level": 5,
    "game_state": {
      "player": {"x": 3, "y": 2},
      "boxes": [{"x": 4, "y": 3}, {"x": 5, "y": 6}],
      "completed": false
    }
  }
  ```
  注：如果没有进度，返回 `{"level": 1, "game_state": null}`
- **错误响应**:
  - `400`: 无效的游戏类型
  - `401`: 未认证

### 更新游戏进度

- **URL**: `/games/progress/{game_type}`
- **方法**: `PUT`
- **描述**: 更新用户的游戏进度
- **需要认证**: 是
- **URL参数**:
  - `game_type`: 游戏类型 (sokoban/tetris/tank/snake)
- **请求体**:
  ```json
  {
    "level": 5,
    "game_state": {
      "player": {"x": 3, "y": 2},
      "boxes": [{"x": 4, "y": 3}, {"x": 5, "y": 6}],
      "completed": false
    }
  }
  ```
  注：level和game_state字段都是可选的
- **成功响应 (200)**:
  ```json
  {
    "message": "游戏进度已更新",
    "level": 5,
    "game_state": {
      "player": {"x": 3, "y": 2},
      "boxes": [{"x": 4, "y": 3}, {"x": 5, "y": 6}],
      "completed": false
    }
  }
  ```
- **错误响应**:
  - `400`: 无效的游戏类型或请求数据
  - `401`: 未认证

### 获取排行榜

- **URL**: `/games/leaderboard/{game_type}`
- **方法**: `GET`
- **描述**: 获取游戏排行榜
- **URL参数**:
  - `game_type`: 游戏类型 (sokoban/tetris/tank/snake)
- **查询参数**:
  - `limit`: 返回记录的最大数量 (可选，默认10)
- **成功响应 (200)**:
  ```json
  [
    {
      "id": 5,
      "user_id": 2,
      "game_type": "tetris",
      "score": 5000,
      "level": 20,
      "duration": 600,
      "completed": true,
      "created_at": "2025-05-18 11:00:00",
      "username": "user1"
    },
    {
      "id": 3,
      "user_id": 1,
      "game_type": "tetris",
      "score": 1500,
      "level": 15,
      "duration": 450,
      "completed": true,
      "created_at": "2025-05-18 14:00:00",
      "username": "user2"
    }
  ]
  ```
- **错误响应**:
  - `400`: 无效的游戏类型
</rewritten_file> 