"""
JENS游戏服务器启动脚本
"""
import os
from dotenv import load_dotenv
from app import create_app

# 加载环境变量
load_dotenv()

# 创建应用实例
app = create_app()

if __name__ == '__main__':
    # 运行应用
    app.run(
        debug=os.environ.get('FLASK_ENV') == 'development',
        host=os.environ.get('FLASK_HOST', '0.0.0.0'),
        port=int(os.environ.get('FLASK_PORT', 5000))
    ) 