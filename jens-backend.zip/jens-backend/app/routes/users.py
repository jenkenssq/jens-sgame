"""用户信息API路由"""
from flask import Blueprint, request, jsonify, current_app, url_for, send_from_directory
from flask_jwt_extended import jwt_required, get_jwt_identity
from .. import db
from ..models import User
from werkzeug.security import generate_password_hash
from werkzeug.utils import secure_filename
import traceback
import os
import uuid
from datetime import datetime

# 创建蓝图
bp = Blueprint('users', __name__, url_prefix='/api/users')

# 允许的图片扩展名
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

def allowed_file(filename):
    """检查文件扩展名是否允许"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@bp.route('/profile', methods=['GET'])
@jwt_required()
def get_profile():
    """获取当前用户信息"""
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({'error': '用户不存在'}), 404
    
    return jsonify(user.to_dict()), 200

@bp.route('/avatar', methods=['POST'])
@jwt_required()
def upload_avatar():
    """上传用户头像"""
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({'error': '用户不存在'}), 404
    
    # 检查请求中是否有文件
    if 'avatar' not in request.files:
        current_app.logger.warning("请求中没有文件部分")
        return jsonify({'error': '没有提供文件'}), 400
    
    file = request.files['avatar']
    
    # 如果用户没有选择文件
    if file.filename == '':
        current_app.logger.warning("没有选择文件")
        return jsonify({'error': '没有选择文件'}), 400
    
    # 检查文件类型
    if file and allowed_file(file.filename):
        try:
            # 创建一个安全的文件名
            filename = secure_filename(file.filename)
            # 生成唯一文件名：用户ID_时间戳_文件名
            unique_filename = f"{user_id}_{uuid.uuid4().hex}_{filename}"
            
            # 确保上传目录存在
            avatar_dir = os.path.join(current_app.root_path, 'static', 'uploads', 'avatars')
            if not os.path.exists(avatar_dir):
                os.makedirs(avatar_dir)
            
            # 保存文件
            file_path = os.path.join(avatar_dir, unique_filename)
            file.save(file_path)
            
            # 生成可访问的URL
            avatar_url = url_for('static', filename=f'uploads/avatars/{unique_filename}', _external=True)
            
            # 更新用户头像URL
            user.avatar = avatar_url
            db.session.commit()
            
            current_app.logger.info(f"用户 {user_id} 上传了新头像: {avatar_url}")
            
            return jsonify({
                'message': '头像上传成功',
                'avatarUrl': avatar_url
            }), 200
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"头像上传错误: {str(e)}")
            current_app.logger.error(traceback.format_exc())
            return jsonify({'error': f'上传失败: {str(e)}'}), 500
    else:
        return jsonify({'error': '不支持的文件类型'}), 400

@bp.route('/profile', methods=['PUT'])
@jwt_required()
def update_profile():
    """更新用户信息"""
    user_id = get_jwt_identity()
    current_app.logger.info(f"处理用户ID: {user_id} 的更新请求")
    
    # 获取请求数据并记录
    data = request.get_json()
    current_app.logger.info(f"接收到的请求数据: {data}")
    
    if not data:
        current_app.logger.warning(f"用户ID: {user_id} 发送了无效的请求数据")
        return jsonify({'error': '无效的请求数据'}), 400
    
    # 显式获取用户
    user = User.query.get(user_id)
    if not user:
        current_app.logger.warning(f"找不到ID为 {user_id} 的用户")
        return jsonify({'error': '用户不存在'}), 404
    
    # 记录更新前的信息
    current_app.logger.info(f"更新前用户信息 - ID: {user.id}, 用户名: {user.username}, 邮箱: {user.email}")
    
    # 处理用户名更新
    if 'username' in data and data['username']:
        new_username = data['username']
        current_app.logger.info(f"尝试将用户名从 '{user.username}' 更新为 '{new_username}'")
        
        # 检查是否与当前用户名相同
        if new_username == user.username:
            current_app.logger.info("用户名未变化，无需更新")
        else:
            # 检查是否被其他用户使用
            existing_user = User.query.filter_by(username=new_username).first()
            if existing_user and existing_user.id != user.id:
                current_app.logger.warning(f"用户名 '{new_username}' 已被其他用户使用")
                return jsonify({'error': '用户名已被使用'}), 409
            
            # 更新用户名
            old_username = user.username
            user.username = new_username
            current_app.logger.info(f"用户名从 '{old_username}' 更新为 '{new_username}'")
    
    # 处理邮箱更新
    if 'email' in data and data['email']:
        new_email = data['email']
        if new_email != user.email:
            # 检查邮箱是否被使用
            existing_user = User.query.filter_by(email=new_email).first()
            if existing_user and existing_user.id != user.id:
                current_app.logger.warning(f"邮箱 '{new_email}' 已被其他用户使用")
                return jsonify({'error': '邮箱已被使用'}), 409
            
            old_email = user.email
            user.email = new_email
            current_app.logger.info(f"邮箱从 '{old_email}' 更新为 '{new_email}'")
    
    # 处理其他字段
    if 'avatar' in data:
        user.avatar = data['avatar']
        current_app.logger.info(f"更新了头像")
    
    if 'gender' in data:
        old_gender = user.gender
        user.gender = data['gender']
        current_app.logger.info(f"性别从 '{old_gender}' 更新为 '{data['gender']}'")
    
    # 密码更新
    if 'password' in data and 'old_password' in data:
        if not user.check_password(data['old_password']):
            current_app.logger.warning(f"用户ID: {user_id} 提供了错误的当前密码")
            return jsonify({'error': '当前密码错误'}), 400
        
        user.password = data['password']
        current_app.logger.info(f"用户ID: {user_id} 的密码已更新")
    
    # 保存更改
    try:
        # 添加SQL语句日志
        if current_app.debug:
            current_app.logger.debug(f"执行的SQL: {str(db.session.new)} {str(db.session.dirty)}")
        
        # 强制刷新会话中的对象
        db.session.flush()
        
        # 提交事务
        db.session.commit()
        
        # 验证更新
        db.session.refresh(user)
        current_app.logger.info(f"用户信息更新成功")
        current_app.logger.info(f"更新后用户信息 - ID: {user.id}, 用户名: {user.username}, 邮箱: {user.email}")
        
        # 返回更新后的用户信息
        return jsonify({
            'message': '用户信息更新成功',
            'user': user.to_dict()
        }), 200
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"数据库更新失败: {str(e)}")
        current_app.logger.error(traceback.format_exc())
        return jsonify({'error': f'数据库错误: {str(e)}'}), 500

@bp.route('/profile', methods=['DELETE'])
@jwt_required()
def delete_profile():
    """删除用户账号"""
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({'error': '用户不存在'}), 404
    
    # 删除用户
    db.session.delete(user)
    db.session.commit()
    
    return jsonify({'message': '账号已删除'}), 200 