"""游戏相关API路由"""
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from datetime import datetime
from .. import db
from ..models import GameRecord, GameSetting, GameProgress, User

# 创建蓝图
bp = Blueprint('games', __name__, url_prefix='/api/games')

# 游戏类型列表
GAME_TYPES = ['sokoban', 'tetris', 'tank', 'snake']

@bp.route('/records', methods=['GET'])
@jwt_required()
def get_records():
    """获取当前用户的游戏记录"""
    user_id = get_jwt_identity()
    
    # 获取查询参数
    game_type = request.args.get('game_type')
    limit = request.args.get('limit', default=10, type=int)
    
    query = GameRecord.query.filter_by(user_id=user_id)
    
    # 如果指定了游戏类型，则过滤
    if game_type and game_type in GAME_TYPES:
        query = query.filter_by(game_type=game_type)
    
    # 按时间倒序排列，限制返回数量
    records = query.order_by(GameRecord.created_at.desc()).limit(limit).all()
    
    return jsonify([record.to_dict() for record in records]), 200

@bp.route('/records', methods=['POST'])
@jwt_required()
def create_record():
    """保存游戏记录"""
    user_id = get_jwt_identity()
    
    data = request.get_json()
    if not data:
        return jsonify({'error': '无效的请求数据'}), 400
    
    # 验证必填字段
    required_fields = ['game_type', 'score']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'缺少必填字段: {field}'}), 400
    
    # 验证游戏类型
    game_type = data['game_type']
    if game_type not in GAME_TYPES:
        return jsonify({'error': '无效的游戏类型'}), 400
    
    # 创建记录
    record = GameRecord(
        user_id=user_id,
        game_type=game_type,
        score=data['score'],
        level=data.get('level'),
        duration=data.get('duration'),
        completed=data.get('completed', False)
    )
    
    # 根据游戏类型保存特定字段
    if game_type == 'sokoban':
        record.steps = data.get('steps')
    elif game_type == 'snake':
        record.length = data.get('length')
    elif game_type == 'tank':
        record.kills = data.get('kills')
        record.mode = data.get('mode')
    elif game_type == 'tetris':
        record.lines = data.get('lines')
    
    # 调试输出
    print(f"保存游戏记录: {data}")
    
    db.session.add(record)
    db.session.commit()
    
    return jsonify({
        'message': '游戏记录保存成功',
        'record': record.to_dict()
    }), 201

@bp.route('/settings/<game_type>', methods=['GET'])
@jwt_required()
def get_settings(game_type):
    """获取用户游戏设置"""
    if game_type not in GAME_TYPES:
        return jsonify({'error': '无效的游戏类型'}), 400
    
    user_id = get_jwt_identity()
    setting = GameSetting.get_user_settings(user_id, game_type)
    
    if not setting:
        return jsonify({'settings': {}}), 200
    
    return jsonify({'settings': setting.settings}), 200

@bp.route('/settings/<game_type>', methods=['PUT'])
@jwt_required()
def update_settings(game_type):
    """更新用户游戏设置"""
    if game_type not in GAME_TYPES:
        return jsonify({'error': '无效的游戏类型'}), 400
    
    user_id = get_jwt_identity()
    data = request.get_json()
    
    if not data or not isinstance(data, dict):
        return jsonify({'error': '无效的请求数据'}), 400
    
    # 查找现有设置或创建新设置
    setting = GameSetting.get_user_settings(user_id, game_type)
    if setting:
        setting.settings = data
    else:
        setting = GameSetting(
            user_id=user_id,
            game_type=game_type,
            settings=data
        )
        db.session.add(setting)
    
    db.session.commit()
    
    return jsonify({
        'message': '游戏设置已更新',
        'settings': setting.settings
    }), 200

@bp.route('/progress/<game_type>', methods=['GET'])
@jwt_required()
def get_progress(game_type):
    """获取用户游戏进度"""
    if game_type not in GAME_TYPES:
        return jsonify({'error': '无效的游戏类型'}), 400
    
    user_id = get_jwt_identity()
    progress = GameProgress.get_user_progress(user_id, game_type)
    
    if not progress:
        return jsonify({
            'level': 1,
            'game_state': None
        }), 200
    
    return jsonify({
        'level': progress.level,
        'game_state': progress.game_state
    }), 200

@bp.route('/progress/<game_type>', methods=['PUT'])
@jwt_required()
def update_progress(game_type):
    """更新用户游戏进度"""
    if game_type not in GAME_TYPES:
        return jsonify({'error': '无效的游戏类型'}), 400
    
    user_id = get_jwt_identity()
    data = request.get_json()
    
    if not data:
        return jsonify({'error': '无效的请求数据'}), 400
    
    # 查找现有进度或创建新进度
    progress = GameProgress.get_user_progress(user_id, game_type)
    if progress:
        if 'level' in data:
            progress.level = data['level']
        if 'game_state' in data:
            progress.game_state = data['game_state']
    else:
        progress = GameProgress(
            user_id=user_id,
            game_type=game_type,
            level=data.get('level', 1),
            game_state=data.get('game_state')
        )
        db.session.add(progress)
    
    db.session.commit()
    
    return jsonify({
        'message': '游戏进度已更新',
        'level': progress.level,
        'game_state': progress.game_state
    }), 200

@bp.route('/leaderboard/<game_type>', methods=['GET'])
def get_leaderboard(game_type):
    """获取游戏排行榜"""
    try:
        # 检查游戏类型是否有效
        if game_type not in GAME_TYPES:
            return jsonify({'error': '无效的游戏类型'}), 400
        
        # 获取查询参数
        limit = request.args.get('limit', default=10, type=int)
        filter_type = request.args.get('filter', default='score')
        
        print(f"请求排行榜 - 游戏类型: {game_type}, 过滤条件: {filter_type}, 限制: {limit}")
        
        # 根据过滤类型选择排序字段
        if game_type == 'sokoban':
            # 推箱子游戏支持按关卡、步数和时间排序
            if filter_type == 'level':
                order_field = GameRecord.level.desc()
            elif filter_type == 'steps':
                order_field = GameRecord.steps.asc()
            elif filter_type == 'time':
                order_field = GameRecord.duration.asc()
            else:
                order_field = GameRecord.score.desc()
        elif game_type == 'tetris':
            # 俄罗斯方块支持按分数、消除行数和等级排序
            if filter_type == 'lines':
                order_field = GameRecord.lines.desc()
            elif filter_type == 'level':
                order_field = GameRecord.level.desc()
            else:
                order_field = GameRecord.score.desc()
        elif game_type == 'snake':
            # 贪吃蛇支持按分数、长度和生存时间排序
            if filter_type == 'length':
                order_field = GameRecord.length.desc()
            elif filter_type == 'time':
                order_field = GameRecord.duration.desc()
            else:
                order_field = GameRecord.score.desc()
        elif game_type == 'tank':
            # 坦克大战支持按分数、击杀数和关卡排序
            if filter_type == 'kills':
                order_field = GameRecord.kills.desc()
            elif filter_type == 'level':
                order_field = GameRecord.level.desc()
            else:
                order_field = GameRecord.score.desc()
        else:
            # 默认按分数排序
            order_field = GameRecord.score.desc()
        
        # 获取排行榜记录
        records = db.session.query(
            GameRecord, User.username
        ).join(
            User, GameRecord.user_id == User.id
        ).filter(
            GameRecord.game_type == game_type
        ).order_by(
            order_field
        ).limit(limit).all()
        
        # 构建响应数据
        result = []
        for record, username in records:
            try:
                record_dict = record.to_dict()
                record_dict['username'] = username
                result.append(record_dict)
            except Exception as e:
                # 如果处理某条记录出错，跳过该记录
                print(f"处理记录时出错 (ID: {record.id}): {e}")
                continue
        
        print(f"排行榜数据: 找到 {len(result)} 条记录")
        
        # 添加更详细的日志
        print(f"排行榜详情: 游戏类型={game_type}, 过滤条件={filter_type}, 找到记录数={len(result)}")
        
        # 在记录中确保包含game_type字段
        for record in result:
            if 'game_type' not in record:
                record['game_type'] = game_type
        
        return jsonify({
            'records': result,
            'total': len(result),
            'game_type': game_type,  # 在响应中添加游戏类型
            'filter_type': filter_type  # 在响应中添加过滤条件
        }), 200
    
    except Exception as e:
        import traceback
        error_message = traceback.format_exc()
        print(f"获取排行榜时出错: {error_message}")
        
        # 返回错误响应
        return jsonify({
            'error': '获取排行榜数据失败',
            'message': str(e)
        }), 500

# 游戏进度API
@bp.route('/user/progress/<game_type>', methods=['GET'])
@jwt_required()
def get_user_progress(game_type):
    """获取用户游戏进度
    
    Args:
        game_type: 游戏类型
    """
    # 验证游戏类型
    if game_type not in ['sokoban', 'tetris', 'tank', 'snake']:
        return jsonify({'error': '不支持的游戏类型'}), 400
    
    # 获取当前用户ID
    user_id = get_jwt_identity()
    
    # 查询用户游戏进度
    progress = GameProgress.get_user_progress(user_id, game_type)
    
    if not progress:
        return jsonify({'message': '未找到游戏进度', 'game_type': game_type}), 404
    
    # 返回进度数据
    return jsonify(progress.to_dict()), 200

@bp.route('/user/progress/<game_type>', methods=['POST'])
@jwt_required()
def save_user_progress(game_type):
    """保存用户游戏进度
    
    Args:
        game_type: 游戏类型
    """
    # 验证游戏类型
    if game_type not in ['sokoban', 'tetris', 'tank', 'snake']:
        return jsonify({'error': '不支持的游戏类型'}), 400
    
    # 获取JSON数据
    data = request.get_json()
    if not data:
        return jsonify({'error': '无效的请求数据'}), 400
    
    # 提取数据
    level = data.get('level', 1)
    game_state = data.get('game_state')
    
    if not game_state:
        return jsonify({'error': '游戏状态不能为空'}), 400
    
    # 获取当前用户ID
    user_id = get_jwt_identity()
    
    # 查询是否已有进度记录
    progress = GameProgress.get_user_progress(user_id, game_type)
    
    if progress:
        # 更新现有进度
        progress.level = level
        progress.game_state = game_state
        progress.updated_at = datetime.utcnow()
    else:
        # 创建新进度记录
        progress = GameProgress(
            user_id=user_id,
            game_type=game_type,
            level=level,
            game_state=game_state
        )
        db.session.add(progress)
    
    # 保存更改
    db.session.commit()
    
    # 返回成功响应
    return jsonify({
        'message': '游戏进度已保存',
        'progress': progress.to_dict()
    }), 200

@bp.route('/user/progress/<game_type>', methods=['DELETE'])
@jwt_required()
def delete_user_progress(game_type):
    """删除用户游戏进度
    
    Args:
        game_type: 游戏类型
    """
    # 验证游戏类型
    if game_type not in ['sokoban', 'tetris', 'tank', 'snake']:
        return jsonify({'error': '不支持的游戏类型'}), 400
    
    # 获取当前用户ID
    user_id = get_jwt_identity()
    
    # 查询用户游戏进度
    progress = GameProgress.get_user_progress(user_id, game_type)
    
    if not progress:
        return jsonify({'message': '未找到游戏进度'}), 404
    
    # 删除进度记录
    db.session.delete(progress)
    db.session.commit()
    
    # 返回成功响应
    return jsonify({'message': '游戏进度已删除'}), 200 