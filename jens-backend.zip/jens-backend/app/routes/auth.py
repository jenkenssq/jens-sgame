"""用户认证API路由"""
from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
from werkzeug.security import generate_password_hash
from datetime import timedelta
from .. import db
from ..models import User
from ..services.auth_service import validate_credentials, is_username_taken, is_email_taken

# 创建蓝图
bp = Blueprint('auth', __name__, url_prefix='/api/auth')

@bp.route('/register', methods=['POST'])
def register():
    """用户注册API"""
    # 获取JSON数据
    data = request.get_json()
    if not data:
        return jsonify({'error': '无效的请求数据'}), 400
    
    # 提取数据
    username = data.get('username')
    password = data.get('password')
    email = data.get('email')
    
    # 验证必填字段
    if not username or not password:
        return jsonify({'error': '用户名和密码是必填项'}), 400
    
    # 检查用户名是否已存在
    if is_username_taken(username):
        return jsonify({'error': '用户名已被使用'}), 409
    
    # 检查邮箱是否已存在
    if email and is_email_taken(email):
        return jsonify({'error': '邮箱已被使用'}), 409
    
    # 创建新用户
    user = User(
        username=username,
        email=email,
    )
    user.password = password  # 使用setter方法自动哈希密码
    
    # 保存用户
    db.session.add(user)
    db.session.commit()
    
    # 生成JWT令牌
    access_token = create_access_token(
        identity=user.id,
        expires_delta=timedelta(hours=24)
    )
    
    # 返回成功响应
    return jsonify({
        'message': '注册成功',
        'access_token': access_token,
        'user': user.to_dict()
    }), 201

@bp.route('/login', methods=['POST'])
def login():
    """用户登录API"""
    # 获取JSON数据
    data = request.get_json()
    if not data:
        return jsonify({'error': '无效的请求数据'}), 400
    
    # 提取数据
    username = data.get('username')
    password = data.get('password')
    
    # 验证必填字段
    if not username or not password:
        return jsonify({'error': '用户名和密码是必填项'}), 400
    
    # 验证用户凭据
    user = validate_credentials(username, password)
    if not user:
        return jsonify({'error': '用户名或密码错误'}), 401
    
    # 检查用户是否激活
    if not user.is_active:
        return jsonify({'error': '账号已禁用'}), 403
    
    # 更新最后登录时间
    user.update_last_login()
    
    # 生成JWT令牌
    access_token = create_access_token(
        identity=user.id,
        expires_delta=timedelta(hours=24)
    )
    
    # 返回成功响应
    return jsonify({
        'message': '登录成功',
        'access_token': access_token,
        'user': user.to_dict()
    }), 200

@bp.route('/logout', methods=['POST'])
@jwt_required()
def logout():
    """用户登出API
    
    注意：JWT令牌本身无法在服务器端使其失效
    客户端应该删除本地存储的令牌
    """
    return jsonify({'message': '成功登出'}), 200

@bp.route('/check', methods=['GET'])
@jwt_required()
def check_auth():
    """检查用户认证状态"""
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({'error': '用户不存在'}), 404
    
    if not user.is_active:
        return jsonify({'error': '账号已禁用'}), 403
    
    return jsonify({
        'message': '已认证',
        'user': user.to_dict()
    }), 200 