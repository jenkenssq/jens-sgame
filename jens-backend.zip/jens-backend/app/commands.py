import click
from flask.cli import with_appcontext
from . import db

def init_app(app):
    """在Flask应用中注册命令"""
    app.cli.add_command(init_db_command)
    app.cli.add_command(create_admin_command)

@click.command('init-db')
@with_appcontext
def init_db_command():
    """初始化数据库表结构"""
    # 确保模型已被导入
    from .models import User, GameRecord, GameSetting, GameProgress
    
    # 创建所有表
    db.create_all()
    click.echo('已初始化数据库。')

@click.command('create-admin')
@with_appcontext
def create_admin_command():
    """创建管理员用户"""
    from .models import User
    
    # 检查用户是否已存在
    admin = User.query.filter_by(username='admin').first()
    if admin:
        click.echo('管理员用户已存在，跳过创建。')
        return
    
    # 创建新管理员用户
    admin = User(
        username='admin',
        email='admin@example.com',
        is_active=True
    )
    admin.password = '123456'  # 这里使用setter方法会自动哈希密码
    
    # 保存到数据库
    db.session.add(admin)
    db.session.commit()
    
    click.echo('管理员用户创建成功。用户名: admin, 密码: 123456') 