from flask import Flask
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager
import os
import logging
from logging.handlers import RotatingFileHandler
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

# 初始化数据库
db = SQLAlchemy()

# 创建应用函数
def create_app(test_config=None):
    # 创建Flask应用
    app = Flask(__name__, instance_relative_config=True)
    
    # 配置应用
    app.config.from_mapping(
        SECRET_KEY=os.environ.get('SECRET_KEY', 'dev'),
        SQLALCHEMY_DATABASE_URI=os.environ.get('DATABASE_URI', 'mysql+pymysql://root:root@localhost/jens_sgame'),
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
        JWT_SECRET_KEY=os.environ.get('JWT_SECRET_KEY', 'jwt-secret-key')
    )
    
    if test_config is None:
        # 如果不是测试，加载实例配置
        app.config.from_pyfile('config.py', silent=True)
    else:
        # 处理测试配置
        if test_config == 'testing':
            # 如果传入字符串'testing'，使用内存数据库进行测试
            app.config.from_mapping({
                'TESTING': True,
                'SQLALCHEMY_DATABASE_URI': 'sqlite:///:memory:',
                'SECRET_KEY': 'test-key',
                'JWT_SECRET_KEY': 'test-jwt-key'
            })
        else:
            # 加载传入的测试配置
            app.config.from_mapping(test_config)
    
    # 确保实例文件夹存在
    try:
        os.makedirs(app.instance_path)
    except OSError:
        pass
    
    # 设置日志
    configure_logging(app)
    
    # 初始化扩展
    db.init_app(app)
    
    # 配置CORS，允许文件上传相关的请求头和方法
    CORS(app, resources={r"/api/*": {
        "origins": ["http://localhost:8080", "http://127.0.0.1:8080"],
        "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        "allow_headers": ["Content-Type", "Authorization", "X-Requested-With"]
    }})
    
    JWTManager(app)
    
    # 导入模型以确保db.create_all()能找到它们
    from .models import User, GameRecord, GameSetting, GameProgress
    
    # 简单主页路由
    @app.route('/')
    def index():
        return {'message': 'Welcome to JENS Game API!'}
    
    # 注册蓝图
    from .routes import auth, games, users
    app.register_blueprint(auth.bp)
    app.register_blueprint(games.bp)
    app.register_blueprint(users.bp)
    
    # 注册命令
    from . import commands
    commands.init_app(app)
    
    return app

def configure_logging(app):
    """配置应用程序日志"""
    
    # 确保日志目录存在
    logs_dir = os.path.join(app.instance_path, 'logs')
    os.makedirs(logs_dir, exist_ok=True)
    
    # 设置文件处理器
    log_file_path = os.path.join(logs_dir, 'app.log')
    file_handler = RotatingFileHandler(log_file_path, maxBytes=10485760, backupCount=10)
    file_handler.setFormatter(logging.Formatter(
        '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
    ))
    file_handler.setLevel(logging.INFO)
    
    # 添加到应用
    app.logger.addHandler(file_handler)
    app.logger.setLevel(logging.INFO)
    
    # 启动消息
    app.logger.info('JENS Game API 启动')
    
    # 设置SQLAlchemy日志
    if app.debug:
        logging.getLogger('sqlalchemy.engine').setLevel(logging.INFO)
        
    return app 