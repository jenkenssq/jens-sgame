"""游戏进度模型文件"""
from datetime import datetime
from .. import db

class GameProgress(db.Model):
    """游戏进度表模型"""
    __tablename__ = 'game_progress'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    game_type = db.Column(db.Enum('sokoban', 'tetris', 'tank', 'snake'), nullable=False)
    level = db.Column(db.Integer, nullable=False, default=1)
    game_state = db.Column(db.JSON)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        """将对象转换为字典"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'game_type': self.game_type,
            'level': self.level,
            'game_state': self.game_state,
            'updated_at': self.updated_at.strftime('%Y-%m-%d %H:%M:%S') if self.updated_at else None
        }
    
    @classmethod
    def get_user_progress(cls, user_id, game_type):
        """获取用户某游戏的进度"""
        return cls.query.filter_by(
            user_id=user_id, game_type=game_type).first()
    
    def __repr__(self):
        """对象表示"""
        return f'<GameProgress {self.game_type} Level:{self.level}>' 