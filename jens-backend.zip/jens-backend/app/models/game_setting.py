"""游戏设置模型文件"""
from .. import db

class GameSetting(db.Model):
    """游戏设置表模型"""
    __tablename__ = 'game_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    game_type = db.Column(db.Enum('sokoban', 'tetris', 'tank', 'snake'), nullable=False)
    settings = db.Column(db.JSON, nullable=False)
    
    def to_dict(self):
        """将对象转换为字典"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'game_type': self.game_type,
            'settings': self.settings
        }
    
    @classmethod
    def get_user_settings(cls, user_id, game_type):
        """获取用户某游戏的设置"""
        return cls.query.filter_by(
            user_id=user_id, game_type=game_type).first()
    
    def __repr__(self):
        """对象表示"""
        return f'<GameSetting {self.game_type}>' 