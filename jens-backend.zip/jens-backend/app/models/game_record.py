"""游戏记录模型文件"""
from datetime import datetime
from .. import db

class GameRecord(db.Model):
    """游戏记录表模型"""
    __tablename__ = 'game_records'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    game_type = db.Column(db.Enum('sokoban', 'tetris', 'tank', 'snake'), nullable=False)
    score = db.Column(db.Integer, nullable=False)
    level = db.Column(db.Integer)
    duration = db.Column(db.Integer)  # 游戏时长(秒)
    completed = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # 推箱子游戏特有字段
    steps = db.Column(db.Integer)  # 步数
    
    # 贪吃蛇游戏特有字段
    length = db.Column(db.Integer)  # 蛇长度
    
    # 坦克大战特有字段
    kills = db.Column(db.Integer)  # 击杀数
    mode = db.Column(db.String(50))  # 游戏模式
    
    # 俄罗斯方块特有字段
    lines = db.Column(db.Integer)  # 消除行数
    
    def to_dict(self):
        """将对象转换为字典"""
        data = {
            'id': self.id,
            'user_id': self.user_id,
            'game_type': self.game_type,
            'score': self.score,
            'level': self.level,
            'duration': self.duration,
            'completed': self.completed,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else None,
            'date': self.created_at.strftime('%Y-%m-%d') if self.created_at else None
        }
        
        # 根据游戏类型添加特定字段 (使用安全访问，避免属性错误)
        if self.game_type == 'sokoban':
            # 尝试安全地访问steps属性
            try:
                data['steps'] = self.steps
            except (AttributeError, Exception):
                data['steps'] = None
        elif self.game_type == 'snake':
            # 尝试安全地访问length属性
            try:
                data['length'] = self.length
                data['time'] = self.duration
            except (AttributeError, Exception):
                data['length'] = None
                data['time'] = self.duration
        elif self.game_type == 'tank':
            # 尝试安全地访问kills和mode属性
            try:
                data['kills'] = self.kills
                data['mode'] = self.mode
            except (AttributeError, Exception):
                data['kills'] = None
                data['mode'] = 'classic'  # 默认模式
        elif self.game_type == 'tetris':
            # 尝试安全地访问lines属性
            try:
                data['lines'] = self.lines
            except (AttributeError, Exception):
                data['lines'] = None
            
        return data
    
    @classmethod
    def get_top_scores(cls, game_type, limit=10):
        """获取某游戏的最高分"""
        return cls.query.filter_by(game_type=game_type)\
            .order_by(cls.score.desc())\
            .limit(limit).all()
    
    def __repr__(self):
        """对象表示"""
        return f'<GameRecord {self.game_type} {self.score}>' 