"""模型包初始化文件"""
from .user import User
from .game_record import GameRecord
from .game_setting import GameSetting
from .game_progress import GameProgress

__all__ = [
    'User', 
    'GameRecord', 
    'GameSetting', 
    'GameProgress'
] 