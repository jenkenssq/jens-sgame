"""用户模型文件"""
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from .. import db

class User(db.Model):
    """用户表模型"""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(100), unique=True)
    avatar = db.Column(db.String(255))
    gender = db.Column(db.String(10))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    is_active = db.Column(db.Boolean, default=True)
    
    # 关系
    game_records = db.relationship('GameRecord', backref='user', lazy=True, cascade="all, delete-orphan")
    game_settings = db.relationship('GameSetting', backref='user', lazy=True, cascade="all, delete-orphan")
    game_progresses = db.relationship('GameProgress', backref='user', lazy=True, cascade="all, delete-orphan")
    
    @property
    def password(self):
        """密码是不可读属性"""
        raise AttributeError('密码不可读')
        
    @password.setter
    def password(self, password):
        """设置密码哈希值"""
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        """验证密码"""
        return check_password_hash(self.password_hash, password)
    
    def update_last_login(self):
        """更新最后登录时间"""
        self.last_login = datetime.utcnow()
        db.session.commit()
        
    def to_dict(self):
        """将对象转换为字典"""
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'avatar': self.avatar,
            'gender': self.gender,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else None,
            'last_login': self.last_login.strftime('%Y-%m-%d %H:%M:%S') if self.last_login else None,
            'is_active': self.is_active
        }
    
    def __repr__(self):
        """对象表示"""
        return f'<User {self.username}>' 