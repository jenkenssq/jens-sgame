"""用户相关服务"""
from typing import Dict, Any, Optional, List
from ..models import User
from .. import db

def get_user_by_id(user_id: int) -> Optional[User]:
    """通过ID获取用户
    
    Args:
        user_id: 用户ID
        
    Returns:
        找到的用户对象，如果不存在返回None
    """
    return User.query.get(user_id)

def get_user_by_username(username: str) -> Optional[User]:
    """通过用户名获取用户
    
    Args:
        username: 用户名
        
    Returns:
        找到的用户对象，如果不存在返回None
    """
    return User.query.filter_by(username=username).first()

def create_user(username: str, password: str, email: str = None) -> User:
    """创建新用户
    
    Args:
        username: 用户名
        password: 密码
        email: 邮箱（可选）
        
    Returns:
        创建的用户对象
    """
    user = User(username=username, email=email)
    user.password = password
    
    db.session.add(user)
    db.session.commit()
    
    return user

def update_user(user: User, data: Dict[str, Any]) -> User:
    """更新用户信息
    
    Args:
        user: 要更新的用户对象
        data: 包含要更新字段的字典
        
    Returns:
        更新后的用户对象
    """
    # 可更新的字段
    allowed_fields = ['username', 'email', 'avatar', 'gender']
    
    for field in allowed_fields:
        if field in data:
            setattr(user, field, data[field])
    
    db.session.commit()
    return user

def change_password(user: User, new_password: str) -> bool:
    """修改用户密码
    
    Args:
        user: 用户对象
        new_password: 新密码
        
    Returns:
        操作是否成功
    """
    user.password = new_password
    db.session.commit()
    return True

def delete_user(user: User) -> bool:
    """删除用户
    
    Args:
        user: 要删除的用户对象
        
    Returns:
        操作是否成功
    """
    db.session.delete(user)
    db.session.commit()
    return True 