"""用户认证相关服务"""
from ..models import User

def validate_credentials(username: str, password: str) -> User:
    """验证用户凭据
    
    Args:
        username: 用户名
        password: 密码
        
    Returns:
        如果凭据有效，返回用户对象，否则返回None
    """
    # 尝试通过用户名查找用户
    user = User.query.filter_by(username=username).first()
    
    # 如果用户不存在或密码不匹配，返回None
    if not user or not user.check_password(password):
        return None
        
    return user

def is_username_taken(username: str) -> bool:
    """检查用户名是否已被使用
    
    Args:
        username: 要检查的用户名
        
    Returns:
        如果用户名已被使用，返回True，否则返回False
    """
    return User.query.filter_by(username=username).first() is not None

def is_email_taken(email: str) -> bool:
    """检查邮箱是否已被使用
    
    Args:
        email: 要检查的邮箱
        
    Returns:
        如果邮箱已被使用，返回True，否则返回False
    """
    return User.query.filter_by(email=email).first() is not None 