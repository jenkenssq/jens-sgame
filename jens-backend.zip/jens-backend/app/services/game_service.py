"""游戏相关服务"""
from typing import Dict, Any, Optional, List, Tuple
from datetime import datetime
from ..models import GameRecord, GameSetting, GameProgress, User
from .. import db

def get_user_game_records(user_id: int, game_type: str = None, limit: int = 10) -> List[GameRecord]:
    """获取用户的游戏记录
    
    Args:
        user_id: 用户ID
        game_type: 游戏类型（可选）
        limit: 返回记录的最大数量
        
    Returns:
        游戏记录列表
    """
    query = GameRecord.query.filter_by(user_id=user_id)
    
    if game_type:
        query = query.filter_by(game_type=game_type)
        
    return query.order_by(GameRecord.created_at.desc()).limit(limit).all()

def create_game_record(user_id: int, game_type: str, score: int, level: int = None, 
                      duration: int = None, completed: bool = False) -> GameRecord:
    """创建游戏记录
    
    Args:
        user_id: 用户ID
        game_type: 游戏类型
        score: 分数
        level: 关卡（可选）
        duration: 持续时间（秒，可选）
        completed: 是否完成（可选）
        
    Returns:
        创建的游戏记录对象
    """
    record = GameRecord(
        user_id=user_id,
        game_type=game_type,
        score=score,
        level=level,
        duration=duration,
        completed=completed,
        created_at=datetime.utcnow()
    )
    
    db.session.add(record)
    db.session.commit()
    
    return record

def get_user_game_settings(user_id: int, game_type: str) -> Dict[str, Any]:
    """获取用户游戏设置
    
    Args:
        user_id: 用户ID
        game_type: 游戏类型
        
    Returns:
        设置字典，如果没有设置返回空字典
    """
    setting = GameSetting.query.filter_by(user_id=user_id, game_type=game_type).first()
    return setting.settings if setting else {}

def update_user_game_settings(user_id: int, game_type: str, settings: Dict[str, Any]) -> GameSetting:
    """更新用户游戏设置
    
    Args:
        user_id: 用户ID
        game_type: 游戏类型
        settings: 设置字典
        
    Returns:
        更新后的游戏设置对象
    """
    setting = GameSetting.query.filter_by(user_id=user_id, game_type=game_type).first()
    
    if not setting:
        setting = GameSetting(user_id=user_id, game_type=game_type, settings={})
        db.session.add(setting)
    
    setting.settings = settings
    db.session.commit()
    
    return setting

def get_user_game_progress(user_id: int, game_type: str) -> Optional[GameProgress]:
    """获取用户游戏进度
    
    Args:
        user_id: 用户ID
        game_type: 游戏类型
        
    Returns:
        游戏进度对象，如果不存在返回None
    """
    return GameProgress.query.filter_by(user_id=user_id, game_type=game_type).first()

def update_user_game_progress(user_id: int, game_type: str, level: int = None, 
                             game_state: Dict[str, Any] = None) -> GameProgress:
    """更新用户游戏进度
    
    Args:
        user_id: 用户ID
        game_type: 游戏类型
        level: 关卡（可选）
        game_state: 游戏状态（可选）
        
    Returns:
        更新后的游戏进度对象
    """
    progress = GameProgress.query.filter_by(user_id=user_id, game_type=game_type).first()
    
    if not progress:
        progress = GameProgress(
            user_id=user_id,
            game_type=game_type,
            level=level or 1,
            game_state=game_state
        )
        db.session.add(progress)
    else:
        if level is not None:
            progress.level = level
        if game_state is not None:
            progress.game_state = game_state
    
    db.session.commit()
    
    return progress

def get_leaderboard(game_type: str, limit: int = 10) -> List[Tuple[GameRecord, str]]:
    """获取游戏排行榜
    
    Args:
        game_type: 游戏类型
        limit: 返回记录的最大数量
        
    Returns:
        (游戏记录, 用户名)元组的列表
    """
    return db.session.query(
        GameRecord, User.username
    ).join(
        User, GameRecord.user_id == User.id
    ).filter(
        GameRecord.game_type == game_type
    ).order_by(
        GameRecord.score.desc()
    ).limit(limit).all()

def get_user_highest_score(user_id: int, game_type: str) -> int:
    """获取用户在特定游戏的最高分
    
    Args:
        user_id: 用户ID
        game_type: 游戏类型
        
    Returns:
        最高分，如果没有记录返回0
    """
    record = GameRecord.query.filter_by(
        user_id=user_id, 
        game_type=game_type
    ).order_by(GameRecord.score.desc()).first()
    
    return record.score if record else 0

def get_user_play_count(user_id: int, game_type: str) -> int:
    """获取用户玩某游戏的次数
    
    Args:
        user_id: 用户ID
        game_type: 游戏类型
        
    Returns:
        游戏次数
    """
    return GameRecord.query.filter_by(user_id=user_id, game_type=game_type).count() 