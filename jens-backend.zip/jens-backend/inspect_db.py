#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
检查数据库结构和数据
"""

from app import create_app, db
from app.models.game_record import GameRecord
from app.models.user import User
import sys

def inspect_database():
    """检查数据库表结构和数据"""
    # 创建应用实例和上下文
    app = create_app()
    
    with app.app_context():
        # 检查GameRecord表结构
        print("\n=== GameRecord表结构 ===")
        columns = [column.name for column in GameRecord.__table__.columns]
        print(f"列名: {columns}")
        
        # 检查是否有游戏记录
        records_count = GameRecord.query.count()
        print(f"\n总游戏记录数: {records_count}")
        
        # 按游戏类型统计记录数
        for game_type in ['sokoban', 'tetris', 'tank', 'snake']:
            count = GameRecord.query.filter_by(game_type=game_type).count()
            print(f"{game_type} 游戏记录数: {count}")
        
        # 尝试查询推箱子游戏排行榜
        print("\n=== 推箱子游戏排行榜测试 ===")
        try:
            # 按关卡排序
            sokoban_by_level = db.session.query(
                GameRecord, User.username
            ).join(
                User, GameRecord.user_id == User.id
            ).filter(
                GameRecord.game_type == 'sokoban'
            ).filter(
                GameRecord.level != None  # 确保level不为空
            ).order_by(
                GameRecord.level.desc()
            ).limit(5).all()
            
            print(f"按关卡排序 - 找到 {len(sokoban_by_level)} 条记录")
            for record, username in sokoban_by_level:
                level = record.level or '未知'
                print(f"用户: {username}, 关卡: {level}, 分数: {record.score}")
            
            # 检查record.to_dict()方法
            if sokoban_by_level:
                record, _ = sokoban_by_level[0]
                print("\n记录数据结构:")
                record_dict = record.to_dict()
                for key, value in record_dict.items():
                    print(f"{key}: {value}")
        
        except Exception as e:
            import traceback
            print(f"查询推箱子排行榜时出错: {e}")
            print(traceback.format_exc())
        
        # 如果命令行参数包含"fix"，则添加缺失的列
        if len(sys.argv) > 1 and sys.argv[1] == 'fix':
            try:
                print("\n=== 修复数据库表结构 ===")
                # 获取数据库连接
                conn = db.engine.connect()
                
                # 检查列是否存在并添加缺失的列
                for column, data_type, comment in [
                    ('steps', 'INT', '推箱子游戏步数'),
                    ('length', 'INT', '贪吃蛇长度'),
                    ('kills', 'INT', '坦克大战击杀数'),
                    ('mode', 'VARCHAR(50)', '游戏模式'),
                    ('lines', 'INT', '俄罗斯方块消除行数')
                ]:
                    # 检查列是否存在
                    inspector = db.inspect(db.engine)
                    columns = [col['name'] for col in inspector.get_columns('game_records')]
                    
                    if column not in columns:
                        print(f"添加列: {column}")
                        conn.execute(f"ALTER TABLE game_records ADD COLUMN {column} {data_type} NULL COMMENT '{comment}'")
                    else:
                        print(f"列已存在: {column}")
                
                print("表结构修复完成")
            
            except Exception as e:
                import traceback
                print(f"修复表结构时出错: {e}")
                print(traceback.format_exc())

if __name__ == '__main__':
    inspect_database() 